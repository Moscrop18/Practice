/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access  */
/* eslint-disable sonarjs/cognitive-complexity  */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { codeList181and182 } from '@features/edit-declaration/edit-declaration.constants';
import {
  AdditionalInformation,
  AdditionalSupplyChainActor,
  PreviousDocument,
  SealIdentifier,
  SupportingDocument,
  TransportEquipment,
  Weight
} from '@features/edit-declaration/models/consignment-gen-info';
import { validateAutoCompleteSelection } from '@features/edit-declaration/validation-functions/auto-complete-validation-functions';
import { Action, combineReducers } from '@ngrx/store';
import { consignmentItemFormDirtyAction } from '@shared/feature-store/common-store/actions/common.actions';
import {
  addArrayControl,
  createFormGroupState,
  disable,
  enable,
  formGroupReducer,
  FormGroupState,
  markAsPristine,
  markAsTouched,
  markAsUntouched,
  removeArrayControl,
  setValue,
  updateArray,
  updateArrayWithFilter,
  updateGroup,
  validate
} from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';

import {
  AdditionalReferences,
  Commodity,
  CommodityCode,
  ConsignmentItemInfoFormValue,
  Packaging
} from '../../../models/consignment-item-form-value';
import * as actions from '../actions/con-item-info.actions';
import { validateCusCodeSelection } from '../actions/con-item-info.actions';

export interface State {
  conItemInfo: {
    formState: FormGroupState<ConsignmentItemInfoFormValue>;
  };
}
export const FORM_ID_DECLARATION_INFO = 'conItemInfo';
export const INITIAL_DECLARATION_FORM_STATE = createFormGroupState<ConsignmentItemInfoFormValue>(
  FORM_ID_DECLARATION_INFO,
  {
    commodity: {
      descriptionOfGoods: '',
      cusCode: ''
    },
    commodityCode: {
      harmonizedSystemSubHeadingCode: '',
      combinedNomenclatureCode: ''
    },
    packaging: [
      {
        typeOfPackages: '',
        numberOfPackages: '',
        shippingMarks: ''
      }
    ],
    weight: {
      weight: null
    },
    previousDocument: {
      type: '',
      referenceNumber: ''
    },
    transportEquipments: [],
    supportingDocuments: [],
    additionalInformations: [],
    additionalReferences: [],
    additionalSupplyChainActors: []
  }
);
const validateAndUpdateForm = updateGroup<ConsignmentItemInfoFormValue>({
  commodity: (commodity) => {
    return updateGroup<Commodity>(commodity, {
      descriptionOfGoods: validate(required)
    });
  },
  weight: (weight) => {
    return updateGroup<Weight>(weight, {
      weight: validate([required, validateGreaterThan(0)])
    });
  },
  packaging: (s, p) => {
    return updateArray<Packaging>(
      s,
      updateGroup<Packaging>({
        numberOfPackages: validate([required])
      })
    );
  },
  additionalSupplyChainActors: (s, p) => {
    return updateArray<AdditionalSupplyChainActor>(
      s,
      updateGroup<AdditionalSupplyChainActor>({
        identificationNumber: validate([required]),
        role: validate([required])
      })
    );
  },
  additionalInformations: (s, p) => {
    return updateArray<AdditionalInformation>(
      s,
      updateGroup<AdditionalInformation>({})
    );
  },
  transportEquipments: (te, parent) => {
    return updateArray<TransportEquipment>(
      te,
      updateGroup<TransportEquipment>({
        containerIdentificationNumber: validate([required, validateFormat(11)]),
        containerPackedStatus: validate(required),
        numberOfSeals: validate([validateGreaterThan(0)]),
        seal: (si, p) => {
          if (
            p.controls.numberOfSeals.value === null ||
            p.controls.numberOfSeals.value.toString() === ''
          ) {
            if (si.isEnabled) {
              si = markAsUntouched(si);
              return disable(si);
            }
          } else {
            if (si.isDisabled) {
              si = markAsUntouched(si);
              return enable(si);
            }
          }
          return updateArray<SealIdentifier>(
            si,
            updateGroup<SealIdentifier>({
              identifier: validate([required])
            })
          );
        }
      })
    );
  },
  previousDocument: (state, parentState) => {
    return updateGroup<PreviousDocument>(state, {
      type: validate(required),
      referenceNumber: validate([required])
    });
  }
});

export function formStateReducer(
  s = INITIAL_DECLARATION_FORM_STATE,
  a: any = {}
) {
  s = formGroupReducer(s, a);
  if (a.type === consignmentItemFormDirtyAction.type) return markAsPristine(s);
  else if (a.type === actions.dispatchConsItemTouchAction.type)
    return markAsTouched(s);
  if (a.type !== actions.updateConsignmentItemForm.type) {
    if (a.type === actions.AddItemsAction.type) {
      return Object.assign({}, INITIAL_DECLARATION_FORM_STATE);
    } else if (a.type === actions.resetItemForm.type) {
      return INITIAL_DECLARATION_FORM_STATE;
    } else if (a.type === actions.ValidateHSSFailedActionItem.type) {
      return updateGroup<ConsignmentItemInfoFormValue>({
        commodityCode: (commodityCode, v) => {
          return updateGroup<CommodityCode>(commodityCode, {
            harmonizedSystemSubHeadingCode: validate([
              required,
              validateHSS(true)
            ])
          });
        }
      })(s);
    } else if (a.type === actions.ValidateHSSSuccessActionItem.type) {
      return updateGroup<ConsignmentItemInfoFormValue>({
        commodityCode: (commodityCode, v) => {
          return updateGroup<CommodityCode>(commodityCode, {
            harmonizedSystemSubHeadingCode: validate([
              required,
              validateHSS(false)
            ])
          });
        }
      })(s);
    } else if (a.type === actions.ValidateCNNFailedActionItem.type) {
      return updateGroup<ConsignmentItemInfoFormValue>({
        commodityCode: (commodityCode, v) => {
          return updateGroup<CommodityCode>(commodityCode, {
            combinedNomenclatureCode: validate([validateCNN(true)])
          });
        }
      })(s);
    } else if (a.type === actions.ValidateCNNSuccessActionItem.type) {
      return updateGroup<ConsignmentItemInfoFormValue>({
        commodityCode: (commodityCode, v) => {
          return updateGroup<CommodityCode>(commodityCode, {
            combinedNomenclatureCode: validate([validateCNN(false)])
          });
        }
      })(s);
    }
    switch (a.type) {
      case actions.AddPreviousDocumentGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          previousDocument: (group) => {
            const newValue = { ...group.value, [a.name]: a.value };
            return setValue(group, newValue);
          }
        })(s);
      case actions.RemovePreviousDocumentGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          previousDocument: (previousDocument) => {
            const newValue = { ...previousDocument.value };
            delete newValue[a.element];
            return setValue(previousDocument, newValue);
          }
        })(s);
      case actions.DisablePreviousDocumentItemAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          previousDocument: (p) => {
            return disable(p);
          }
        })(s);
      case actions.AddAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            const updatedArray = additionalReferences;
            return addArrayControl(updatedArray, {
              type: '',
              referenceNumber: ''
            });
          }
        })(s);
      case actions.RemoveAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            const updatedArray = additionalReferences;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemovePackagingGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          packaging: (packaging) => {
            const updatedArray = packaging;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.AddPackagingGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          packaging: (packaging) => {
            const updatedArray = packaging;
            if (
              codeList181and182.includes(
                packaging.value[0].typeOfPackages?.split('-')[0].trim()
              )
            )
              return addArrayControl(updatedArray, {
                typeOfPackages: ''
              });
            else
              return addArrayControl(updatedArray, {
                typeOfPackages: '',
                numberOfPackages: '',
                shippingMarks: ''
              });
          }
        })(s);
      case actions.RemoveAllAdditionalReferencesGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalReferences: (additionalReferences) => {
            return setValue(additionalReferences, []);
          }
        })(s);
      case actions.AddSupportingDocumentsGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            const updatedArray = supportingDocuments;
            return addArrayControl(updatedArray, {
              type: '',
              referenceNumber: ''
            });
          }
        })(s);
      case actions.RemoveSupportingDocumentsGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            const updatedArray = supportingDocuments;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemoveSupportingDocumentsAllGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          supportingDocuments: (supportingDocuments) => {
            return setValue(supportingDocuments, []);
          }
        })(s);

      case actions.AddAdditionalInformationGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            const updatedArray = additionalInformations;
            return addArrayControl(updatedArray, { text: '', code: '' });
          }
        })(s);
      case actions.RemoveAdditionalInformationGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            const updatedArray = additionalInformations;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemoveAdditionalInformationsAllGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalInformations: (additionalInformations) => {
            return setValue(additionalInformations, []);
          }
        })(s);
      case actions.AddAdditionalSupplyChainActorGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            const updatedArray = additionalSupplyChainActors;
            return addArrayControl(updatedArray, {
              identificationNumber: '',
              name: '',
              role: ''
            });
          }
        })(s);
      case actions.RemoveAdditionalSupplyChainActorGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            const updatedArray = additionalSupplyChainActors;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemoveAdditionalSupplyChainActorAllGroupElementActionItem
        .type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalSupplyChainActors: (additionalSupplyChainActors) => {
            return setValue(additionalSupplyChainActors, []);
          }
        })(s);
      case actions.AddTransportEquipmentGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            const updatedArray = transportEquipments;
            return addArrayControl(updatedArray, {
              containerIdentificationNumber: '',
              containerPackedStatus: '',
              numberOfSeals: null,
              seal: [
                {
                  identifier: ''
                }
              ]
            });
          }
        })(s);
      case actions.RemoveTransportEquipmentGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            const updatedArray = transportEquipments;
            return removeArrayControl(updatedArray, a.index);
          }
        })(s);
      case actions.RemoveTransportEquipmentAllGroupElementActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (transportEquipments) => {
            return setValue(transportEquipments, []);
          }
        })(s);
      case actions.RemoveCommodityCodeGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          commodityCode: (commodityCode) => {
            return setValue(commodityCode, {});
          }
        })(s);
      case actions.AddCommodityCodeGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          commodityCode: (commodityCode) => {
            const newValue = {
              harmonizedSystemSubHeadingCode: '',
              combinedNomenclatureCode: ''
            };
            return setValue(commodityCode, newValue);
          }
        })(s);
      case actions.RemoveWeightGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          weight: (weight) => {
            return setValue(weight, {});
          }
        })(s);
      case actions.AddWeightGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          weight: (weight) => {
            const newValue = { weight: null };
            return setValue(weight, newValue);
          }
        })(s);
      case actions.DisableSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (tes, p) => {
            const lastIndex = tes.controls.length - 1;
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === lastIndex,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  return disable(sealIdentifiers);
                }
              })
            )(tes);
          }
        })(s);
      case actions.AddSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (tes, p) => {
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === a.index,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  const updatedArray = sealIdentifiers;
                  return addArrayControl(updatedArray, { identifier: '' });
                }
              })
            )(tes);
          }
        })(s);
      case actions.ValidateEORIFailedActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalSupplyChainActors: (sc, p) => {
            return updateArray<AdditionalSupplyChainActor>(
              sc,
              updateGroup<AdditionalSupplyChainActor>({
                identificationNumber: validate(validateEORI(a.isValid))
              }),
              updateGroup<AdditionalSupplyChainActor>({
                name: (name) => {
                  name = setValue<string>(name, '');
                  return name;
                }
              })
            );
          }
        })(s);

      case actions.FetchNameByEORISuccessActionItem.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          additionalSupplyChainActors: (asca, p) => {
            return updateArrayWithFilter<AdditionalSupplyChainActor>(
              (asc, idx) => idx === a.index,
              updateGroup<AdditionalSupplyChainActor>({
                name: (name) => {
                  name = setValue<string>(name, a.name);
                  return name;
                }
              })
            )(asca);
          }
        })(s);

      case actions.ValidatePackagingAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          packaging: (tes, p) => {
            return updateArray<Packaging>((pack) => {
              const newValue = { ...pack.value };
              if (
                codeList181and182.includes(
                  tes.value[0]?.typeOfPackages?.split('-')[0].trim()
                )
              ) {
                delete newValue.numberOfPackages;
                delete newValue.shippingMarks;
              } else {
                newValue.numberOfPackages = pack.value.numberOfPackages;
                newValue.shippingMarks = pack.value.shippingMarks;
              }
              return setValue(pack, newValue);
            })(tes);
          }
        })(s);
      case actions.RemoveSealIdentifierGroupElementAction.type:
        return updateGroup<ConsignmentItemInfoFormValue>({
          transportEquipments: (tes, p) => {
            return updateArrayWithFilter<TransportEquipment>(
              (te, idx) => idx === a.index,
              updateGroup<TransportEquipment>({
                seal: (sealIdentifiers) => {
                  const updatedArray = sealIdentifiers;
                  return removeArrayControl(
                    updatedArray,
                    a.sealIdentifierIndex
                  );
                }
              })
            )(tes);
          }
        })(s);
      default:
        return getAdditionalAction(a, s);
    }
  } else {
    return createFormGroupState<ConsignmentItemInfoFormValue>(
      FORM_ID_DECLARATION_INFO,
      a.data
    );
  }
}
function getAdditionalAction(a, s) {
  switch (a.type) {
    case validateCusCodeSelection.type:
      return updateGroup<ConsignmentItemInfoFormValue>({
        commodity: (commodity) => {
          return updateGroup<Commodity>({
            cusCode: validate(
              validateAutoCompleteSelection(a.selectedValue, a.autoCompleteList)
            )
          })(s.controls.commodity);
        }
      })(s);
    case actions.validateAdditionalReferences.type:
      return updateGroup<ConsignmentItemInfoFormValue>({
        additionalReferences: (additionalReferences) => {
          return updateArrayWithFilter<AdditionalReferences>(
            (subDiv, idx) => idx === a.index,
            updateGroup<AdditionalReferences>({
              type: validate([
                required,
                validateAutoCompleteSelection(
                  a.selectedValue,
                  a.autoCompleteList
                )
              ])
            })
          )(additionalReferences);
        }
      })(s);
    case actions.validateSupportingDocument.type:
      return updateGroup<ConsignmentItemInfoFormValue>({
        supportingDocuments: (supportingDocuments) => {
          return updateArrayWithFilter<SupportingDocument>(
            (subDiv, idx) => idx === a.index,
            updateGroup<SupportingDocument>({
              type: validate([
                required,
                validateAutoCompleteSelection(
                  a.selectedValue,
                  a.autoCompleteList
                )
              ])
            })
          )(supportingDocuments);
        }
      })(s);
    case actions.validatePackagingTypeAction.type:
      return updateGroup<ConsignmentItemInfoFormValue>({
        packaging: (packaging) => {
          return updateArrayWithFilter<Packaging>(
            (subDiv, idx) => idx === a.index,
            updateGroup<Packaging>({
              typeOfPackages: validate([
                required,
                validateAutoCompleteSelection(a.value, a.autoCompleteList)
              ]),
              numberOfPackages: validate([required])
            })
          )(packaging);
        }
      })(s);
    case actions.validateSupportingDocumentReferenceNumber.type:
      return updateGroup<ConsignmentItemInfoFormValue>({
        supportingDocuments: (supportingDocuments) => {
          return updateArrayWithFilter<SupportingDocument>(
            (subDiv, idx) => idx === a.index,
            updateGroup<SupportingDocument>({
              referenceNumber: validate([required])
            })
          )(supportingDocuments);
        }
      })(s);
    default:
      return s;
  }
}

export function validateEORI<T>(
  isvalid: boolean
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (value.toString() === '') {
      return {
        isReuired: true
      };
    }
    if (!isvalid) {
      return {
        isInvalidEORI: true
      };
    }
    return {};
  };
}
export function validateHSS<T>(
  isInvalid: boolean
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (isInvalid)
      return {
        isInvalidHSS: true
      };
    return {};
  };
}
export function validateCNN<T>(
  isInvalid: boolean
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (isInvalid)
      return {
        isInvalidCNN: true
      };
    return {};
  };
}
export interface MCInformationError {
  isMaxLengthExceeded?: boolean;
  isGreaterThan?: boolean;
  isInvalidReferenveNo?: boolean;
  isInvalidEORI?: boolean;
  isInvalidHSS?: boolean;
  isInvalidCNN?: boolean;
  isInvalidIdentifier?: boolean;
  isReuired?: boolean;
}
export function validateFormat<T>(
  size: number
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (value.toString().length === 0 || value.toString() === '') {
      return {};
    }
    if (value.toString().length < size) {
      return {
        isInvalidIdentifier: true
      };
    }
    const firstFourChar = value.toString().substring(0, 4);
    const lastSevenChar = value.toString().substring(4, 12);
    if (
      /^[A-Za-z]+$/.exec(firstFourChar) !== null &&
      /^[0-9]+$/.exec(lastSevenChar) !== null
    ) {
      return {};
    } else {
      return {
        isInvalidIdentifier: true
      };
    }
  };
}
export function validateGreaterThan<T>(
  size: number
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    if (
      value &&
      value !== null &&
      value.toString() !== '' &&
      parseInt(value.toString()) <= size
    ) {
      return {
        isGreaterThan: true
      };
    }
    return {};
  };
}

export function conItemInfoReducer(s: State['conItemInfo'], a: Action) {
  return reducers(s, a);
}

const reducers = combineReducers<State['conItemInfo'], any>({
  formState(s = INITIAL_DECLARATION_FORM_STATE, a: any = {}) {
    return validateAndUpdateForm(formStateReducer(s, a));
  }
});
