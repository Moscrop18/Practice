import { createAction, props } from '@ngrx/store';

import { ConsignmentItemInfoFormValue } from '../../../models/consignment-item-form-value';

export const AddPackagingGroupElementAction = createAction(
  'conItemInfo/ADD_PACKAGING'
);
export const RemovePackagingGroupElementAction = createAction(
  'conItemInfo/REMOVE_PACKAGING',
  props<{ index: number }>()
);
export const AddAdditionalReferencesGroupElementAction = createAction(
  'conItemInfo/ADD_ADDITIONAL_REF'
);
export const RemoveSealIdentifierGroupElementAction = createAction(
  'conItemInfo/REMOVE_SEAL_IDENTIFIER_GROUP_ELEMENT',
  props<{ index: number; sealIdentifierIndex: number }>()
);
export const RemoveAllAdditionalReferencesGroupElementAction = createAction(
  'conItemInfo/REMOVE_ALL_ADDITIONAL_REF'
);

export const RemoveAdditionalReferencesGroupElementAction = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_REF',
  props<{ index: number }>()
);

export const AddItemsAction = createAction('conItemInfo/ADD_ITEMS');
export const AddSupportingDocumentsGroupElementAction = createAction(
  'conItemInfo/CREATE_SUPPORTING_DOCUMENT_GROUP_ELEMENT'
);
export const RemoveSupportingDocumentsGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_SUPPORTING_DOCUMENT_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveSupportingDocumentsAllGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_SUPPORTING_DOCUMENT_ALL_GROUP_ELEMENT'
);
export const AddAdditionalInformationGroupElementActionItem = createAction(
  'conItemInfo/CREATE_ADDITIONAL_INFORMATION_GROUP_ELEMENTT'
);
export const RemoveAdditionalInformationGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_INFORMATION_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveAdditionalInformationsAllGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_INFORMATION_ALL_GROUP_ELEMENT'
);
export const AddAdditionalSupplyChainActorGroupElementActionItem = createAction(
  'conItemInfo/CREATE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_GROUP_ELEMENT'
);
export const RemoveAdditionalSupplyChainActorGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveAdditionalSupplyChainActorAllGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_SUPPLY_CHAIN_ACTOR_ALL_GROUP_ELEMENT'
);
export const AddTransportEquipmentGroupElementActionItem = createAction(
  'conItemInfo/CREATE_ADDITIONAL_TRANSPORT_EQUIPMENT_GROUP_ELEMENT'
);
export const RemoveTransportEquipmentGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_TRANSPORT_EQUIPMENT_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const RemoveTransportEquipmentAllGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_ADDITIONAL_TRANSPORT_EQUIPMENT_ALL_GROUP_ELEMENT'
);

export const AddPreviousDocumentGroupElementActionItem = createAction(
  'conItemInfo/ADD_PREVIOUS_DOCUMENT_GROUP_ELEMENT',
  props<{ name: string; value: string }>()
);
export const RemovePreviousDocumentGroupElementActionItem = createAction(
  'conItemInfo/REMOVE_PREVIOUS_DOCUMENT_GROUP_ELEMENT',
  props<{ element: string }>()
);

export const RemoveCommodityCodeGroupElementAction = createAction(
  'conItemInfo/REMOVE_COMMODITY_CODE_GROUP_ELEMENT'
);
export const AddCommodityCodeGroupElementAction = createAction(
  'conItemInfo/ADD_COMMODITY_CODE_GROUP_ELEMENT'
);
export const AddSealIdentifierGroupElementAction = createAction(
  'conItemInfo/CREATE_SEAL_IDENTIFIER_GROUP_ELEMENT',
  props<{ index: number }>()
);
export const DisableSealIdentifierGroupElementAction = createAction(
  'conItemInfo/DISABLE_SEAL_IDENTIFIER_GROUP_ELEMENT'
);

export const DisablePreviousDocumentItemAction = createAction(
  'conItemInfo/DISABLE_PREVIOUS_DOCUMENT_GROUP_ELEMENT'
);

export const RemoveWeightGroupElementAction = createAction(
  'conItemInfo/REMOVE_WEIGHT_GROUP_ELEMENT'
);
export const AddWeightGroupElementAction = createAction(
  'conItemInfo/ADD_WEIGHT_GROUP_ELEMENT'
);

export const RemoveItemsElementAction = createAction(
  'conItemInfo/REMOVE_ITEMS',
  props<{ index: number }>()
);
export const SetSubmittedValueAction = createAction(
  'conItemInfo/SET_SUBMITTED_VALUE',
  props<{ submittedValue: ConsignmentItemInfoFormValue }>()
);
export const updateConsignmentItemForm = createAction(
  'conItemInfo/UPDATE_CONSIGNMENT_ITEM_FORM',
  props<{ data: ConsignmentItemInfoFormValue }>()
);
export const dispatchConsItemTouchAction = createAction(
  'conItemInfo/ITEM_FORM_TOUCH_ACTION'
);
export const ValidateEORIActionItem = createAction(
  'conItemInfo/VALIDATE_EORI',
  props<{ eori: string; index: number }>()
);
export const ValidateHSSActionItem = createAction(
  'conItemInfo/VALIDATE_HSS',
  props<{ hssCode: string }>()
);
export const ValidateCNNActionItem = createAction(
  'conItemInfo/VALIDATE_CNN',
  props<{ cnnCode: string; hssCode: string }>()
);
export const ValidateEORIFailedActionItem = createAction(
  'conItemInfo/VALIDATE_EORI_FAILED',
  props<{ eori: string; isValid: boolean; index: number }>()
);
export const ValidateEORISuccessActionItem = createAction(
  'conItemInfo/VALIDATE_EORI_SUCCESS',
  props<{ eori: string; isValid: boolean; index: number }>()
);
export const ValidateHSSSuccessActionItem = createAction(
  'conItemInfo/VALIDATE_HSS_SUCCESS'
);
export const ValidateHSSFailedActionItem = createAction(
  'conItemInfo/VALIDATE_HSS_FAILED'
);
export const ValidateCNNSuccessActionItem = createAction(
  'conItemInfo/VALIDATE_CNN_SUCCESS'
);
export const ValidateCNNFailedActionItem = createAction(
  'conItemInfo/VALIDATE_CNN_FAILED'
);
export const FetchNameByEORISuccessActionItem = createAction(
  'conItemInfo/FETCH_NAME_BY_EORI_SUCCESS',
  props<{ name: string; index: number }>()
);
export const ValidatePackagingAction = createAction(
  'conItemInfo/VALIDATE_PACKAGING',
  props<{ packagingType: string; index: number }>()
);
export const validatePackagingTypeAction = createAction(
  'conItemInfo/Validate_PackagingType_Action',
  props<{ index: number; value: string; autoCompleteList: string[] }>()
);
export const validateCusCodeSelection = createAction(
  'generalInformation/VALIDATE_CUS_Code_SELECTION',
  props<{ selectedValue: string; autoCompleteList: string[] }>()
);
export const validateAdditionalReferences = createAction(
  'generalInformation/VALIDATE_Additional_References_SELECTION',
  props<{ index: number; selectedValue: string; autoCompleteList: string[] }>()
);
export const validateSupportingDocument = createAction(
  'generalInformation/VALIDATE_Supporting_Document_SELECTION',
  props<{ index: number; selectedValue: string; autoCompleteList: string[] }>()
);
export const validateSupportingDocumentReferenceNumber = createAction(
  'generalInformation/VALIDATE_Supporting_Document_Reference_Number',
  props<{ index: number }>()
);
export const resetItemForm = createAction('conItemInfo/Reset Item');
