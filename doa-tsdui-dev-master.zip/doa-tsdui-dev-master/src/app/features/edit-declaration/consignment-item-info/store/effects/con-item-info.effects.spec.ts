/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  HttpClient,
  HttpHandler,
  HttpHeaders,
  HttpResponse
} from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ROOT_REDUCERS, metaReducers } from '@core/root-store/root.reducer';
import { ConsignmentGenInfoFormValue } from '@features/edit-declaration/models';
import { ConsignmentItemInfoService } from '@features/edit-declaration/services/con-item-info.service';
import { provideMockActions } from '@ngrx/effects/testing';
import { StoreModule } from '@ngrx/store';
import { FormGroupState } from 'ngrx-forms';
import { of, ReplaySubject } from 'rxjs';

import {
  FetchNameByEORISuccessActionItem,
  ValidateCNNActionItem,
  ValidateEORIActionItem,
  ValidateHSSActionItem
} from '../actions/con-item-info.actions';

import { ConItemInfoEffects } from './con-item-info.effects';

export interface ConGenInfodState {
  conGenInfo: {
    formState: FormGroupState<ConsignmentGenInfoFormValue>;
  };
}
describe('conItemInfoEffect', () => {
  let actions: ReplaySubject<any>;
  let effects: ConItemInfoEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        })
      ],
      providers: [
        ConItemInfoEffects,
        provideMockActions(() => actions),
        HttpClient,
        ConsignmentItemInfoService,
        HttpHandler
      ]
    });

    effects = TestBed.get(ConItemInfoEffects);
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });

  it('should validate eori', () => {
    jest.spyOn(effects.httpService, 'get').mockImplementation(() =>
      of(
        new HttpResponse({
          status: 200,
          body: {
            'validEORINumbers': ['BE0214596464', 'BE0436501681']
          },
          headers: new HttpHeaders({
            etag: '1234'
          })
        })
      )
    );
    actions = new ReplaySubject(1);
    const validateInvalidEORIAction = {
      type: ValidateEORIActionItem.type,
      eori: 'invalideori',
      index: 0
    };
    actions.next(validateInvalidEORIAction);
    const validateValidEORIAction = {
      type: ValidateEORIActionItem.type,
      eori: 'BE0214596464',
      index: 0
    };
    actions.next(validateValidEORIAction);
    effects.validateEoriItems.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });
  it('should validate hss', () => {
    jest.spyOn(effects.httpService, 'get').mockImplementation(() =>
      of(
        new HttpResponse({
          status: 200,
          body: {
            'validCommodityCodes': ['29171100']
          },
          headers: new HttpHeaders({
            etag: '1234'
          })
        })
      )
    );
    actions = new ReplaySubject(1);
    const validateHSSAction = {
      type: ValidateHSSActionItem.type,
      hssCode: '29171100'
    };
    actions.next(validateHSSAction);
    effects.validateHssItems.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });

  it('should validate cnn', () => {
    jest.spyOn(effects.httpService, 'get').mockImplementation(() =>
      of(
        new HttpResponse({
          status: 200,
          body: {
            'validCommodityCodes': ['29171100']
          },
          headers: new HttpHeaders({
            etag: '1234'
          })
        })
      )
    );
    actions = new ReplaySubject(1);
    const validateCNNAction = {
      type: ValidateCNNActionItem.type,
      hssCode: '291711',
      cnnCOde: '00'
    };
    actions.next(validateCNNAction);
    effects.validateCnnItems.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });

  it('should fetch name by eori', () => {
    actions = new ReplaySubject(1);
    const fetchNameByEORIAction = {
      type: FetchNameByEORISuccessActionItem.type,
      name: 'samplename',
      index: 0
    };
    actions.next(fetchNameByEORIAction);
    effects.fetchEORINameItem.subscribe((name) => {
      expect(name).toBeDefined();
    });
  });
});
