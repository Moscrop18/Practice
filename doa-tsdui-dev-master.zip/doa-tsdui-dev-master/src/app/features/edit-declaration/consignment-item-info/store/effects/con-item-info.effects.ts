/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { ConsignmentItemInfoService } from '@features/edit-declaration/services/con-item-info.service';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CRSGateway } from '@shared/models/crs-gateway';
import { of } from 'rxjs';
import { catchError, concatMap, map, switchMap, tap } from 'rxjs/operators';

import * as actions from '../actions/con-item-info.actions';

@Injectable()
export class ConItemInfoEffects {
  validateEoriItems = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORIActionItem),
      concatMap((validateEORIActionItem) => {
        const isValidEoriNumberItem = false;
        return this.httpService
          .get<CRSGateway>('../../../../assets/crs-mock/crs.json')
          .pipe(
            map((data) => {
              if (data.validEORINumbers.includes(validateEORIActionItem.eori)) {
                return actions.ValidateEORISuccessActionItem({
                  eori: validateEORIActionItem.eori,
                  isValid: isValidEoriNumberItem,
                  index: validateEORIActionItem.index
                });
              } else {
                return actions.ValidateEORIFailedActionItem({
                  eori: validateEORIActionItem.eori,
                  isValid: isValidEoriNumberItem,
                  index: validateEORIActionItem.index
                });
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  validateHssItems = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateHSSActionItem),
      concatMap((validateHSSActionItem) => {
        const isValidEoriNumberItem = false;
        return this.httpService
          .get<CRSGateway>('../../../../assets/crs-mock/commodityCode.json')
          .pipe(
            map((data) => {
              const validCodes = data;
              if (
                validCodes.validCommodityCodes.filter((validCode) => {
                  return (
                    validCode.substring(0, 6) === validateHSSActionItem.hssCode
                  );
                }).length > 0
              ) {
                return actions.ValidateHSSSuccessActionItem();
              } else {
                return actions.ValidateHSSFailedActionItem();
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  validateCnnItems = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateCNNActionItem),
      concatMap((validateCNNActionItem) => {
        return this.httpService
          .get<CRSGateway>('../../../../assets/crs-mock/commodityCode.json')
          .pipe(
            map((data) => {
              if (
                data.validCommodityCodes.includes(
                  validateCNNActionItem.hssCode + validateCNNActionItem.cnnCode
                )
              ) {
                return actions.ValidateCNNSuccessActionItem();
              } else {
                return actions.ValidateCNNFailedActionItem();
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  fetchEORINameItem = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORISuccessActionItem),
      switchMap((validateEORISuccessActionItem) => {
        const isValidEoriNumberItem = false;
        return this.httpService
          .get('../../../../assets/crs-mock/eori-mock.json')
          .pipe(
            map((data) => {
              return actions.FetchNameByEORISuccessActionItem({
                name:
                  data[constants.VALID_EORI_NUMBERS][
                    validateEORISuccessActionItem.eori
                  ].name,
                index: validateEORISuccessActionItem.index
              });
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  filterPackaginglist$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(actions.ValidatePackagingAction),
        tap((action) => {
          if (action.index === 0) {
            this.consignmentItemInfoService.getRemainingPackagesCodeList(
              action.packagingType
            );
          }
        })
      ),
    { dispatch: false }
  );

  constructor(
    private actions$: Actions,
    public httpService: HttpClient,
    private consignmentItemInfoService: ConsignmentItemInfoService
  ) {}
}
