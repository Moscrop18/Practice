/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable sonarjs/no-duplicate-string */

import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormArrayState,
  formStateReducer,
  MarkAsTouchedAction,
  SetErrorsAction
} from 'ngrx-forms';

import { AdditionalReferences } from '../../../models/consignment-item-form-value';

import { AdditionalReferencesComponent } from './additional-references.component';

describe('PreviousDocumentComponent', () => {
  let component: AdditionalReferencesComponent;
  let fixture: ComponentFixture<AdditionalReferencesComponent>;
  let rootElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdditionalReferencesComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdditionalReferencesComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormArrayState<AdditionalReferences>(
      'additionalReferences',
      [{ type: '', referenceNumber: '' }]
    );
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should check the validity of type field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls[0].controls.type.id, {
        errors: {
          errorType: 'required'
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(
        updatedGroupViaAction.controls[0].controls.type.id
      )
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });
  it('Should call additionalReferencesCheckBoxClicked', () => {
    const checkBox = rootElement.query(By.css('.mat-checkbox-input'));
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    expect(checkBox.nativeElement.checked).toBeFalsy();
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    expect(checkBox.nativeElement.checked).toBeTruthy();
  });
  it('Should call addadditionalReferences', () => {
    const checkBox = rootElement.query(By.css('.mat-checkbox-input'));
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    const addSection = rootElement.query(By.css('.add-button'));
    addSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.addAdditionalReferences).toHaveBeenCalled());
  });
  it('Should call deleteAdditionalReferences', () => {
    const INITIAL_STATE = createFormArrayState<AdditionalReferences>(
      'additionalReferences',
      [
        { type: '', referenceNumber: '' },
        { type: '', referenceNumber: '' }
      ]
    );
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
    const checkBox = rootElement.query(By.css('.mat-checkbox-input'));
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    const removeSection = rootElement.query(By.css('#containerRemoveButton0'));
    removeSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() =>
        expect(component.deleteadditionalReferences).toHaveBeenCalled()
      );
  });

  it('Should check the validity of reference field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(
        component.formState.controls[0].controls.referenceNumber.id,
        {
          errors: {
            errorType: 'required'
          }
        }
      )
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(
        updatedGroupViaAction.controls[0].controls.referenceNumber.id
      )
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });
  it('should call deleteadditionalReferences', () => {
    const spy = jest.spyOn(component.removeAddrefElementAction, 'emit');
    component.deleteadditionalReferences(1);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call deleteadditionalReferences and checked false', () => {
    component.noOfAddRef = 2;
    component.deleteadditionalReferences(2);
    fixture.detectChanges();
    expect(component.checked).toBeFalsy();
  });
  it('should call filter with value', () => {
    component.CL380Codelist = [
      {
        'id': 1,
        'value': 'Y001',
        'label': 'Y001',
        'definition':
          'Wholly obtained in Lebanon and transported directly from that country to the Community.'
      },
      {
        'id': 2,
        'value': 'Y003',
        'label': 'Y003',
        'definition':
          'Wholly obtained in Tunisia and transported directly from that country to the Community.'
      }
    ];
    const INITIAL_STATE = createFormArrayState<AdditionalReferences>(
      'additionalReferences',
      [{ type: 'Y003', referenceNumber: '' }]
    );
    component.formState = INITIAL_STATE;
    component.filter(0);
    expect(component.fieldOption).toEqual([
      {
        'definition':
          'Wholly obtained in Tunisia and transported directly from that country to the Community.',
        'id': 2,
        'label': 'Y003',
        'value': 'Y003'
      }
    ]);
  });
  it('should call filter without value', () => {
    component.CL380Codelist = [
      {
        'id': 1,
        'value': 'Y001',
        'label': 'Y001',
        'definition':
          'Wholly obtained in Lebanon and transported directly from that country to the Community.'
      }
    ];
    const INITIAL_STATE = createFormArrayState<AdditionalReferences>(
      'additionalReferences',
      [{ type: '123', referenceNumber: '' }]
    );
    component.formState = INITIAL_STATE;
    component.filter(0);
    expect(component.fieldOption).toEqual([]);
  });
  it('Should test onAdditionalReferencesChange', () => {
    const spy = jest.spyOn(component.validateAdditionalReferencesEvent, 'emit');
    component.CL380Codelist = [
      {
        'id': 1,
        'value': 'Y001',
        'label': 'Y001',
        'definition':
          'Wholly obtained in Lebanon and transported directly from that country to the Community.'
      }
    ];
    const selectionValue =
      'Y001 - Wholly obtained in Lebanon and transported directly from that country to the Community.';
    component.onAdditionalReferencesChange(selectionValue, 0);
    expect(spy).toHaveBeenCalledWith({
      'codeList': [
        'Y001 - Wholly obtained in Lebanon and transported directly from that country to the Community.'
      ],
      'value':
        'Y001 - Wholly obtained in Lebanon and transported directly from that country to the Community.',
      'index': 0
    });
  });
});
