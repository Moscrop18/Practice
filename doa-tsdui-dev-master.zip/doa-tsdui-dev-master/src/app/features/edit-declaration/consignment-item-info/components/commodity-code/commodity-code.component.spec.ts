/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/unbound-method */
import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { ConfigService } from '@core/services/config/config.service';
import {
  CommodityCode,
  PreviousDocument
} from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormGroupState,
  formStateReducer,
  MarkAsTouchedAction,
  SetErrorsAction
} from 'ngrx-forms';

import { CommodityCodeComponent } from './commodity-code.component';

describe('CommodityCodeComponent', () => {
  let component: CommodityCodeComponent;
  let fixture: ComponentFixture<CommodityCodeComponent>;
  let rootElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CommodityCodeComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        HttpClientModule,
        TranslateModule.forRoot()
      ],
      providers: [ConfigService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommodityCodeComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<CommodityCode>('commodityCode', {
      harmonizedSystemSubHeadingCode: '',
      combinedNomenclatureCode: ''
    });
    component.formState = INITIAL_STATE;
    component.isCommodityCodeMandatory = false;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should check the validity of type field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(
        component.formState.controls.harmonizedSystemSubHeadingCode.id,
        {
          errors: {
            errorType: 'required'
          }
        }
      )
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(
        updatedGroupViaAction.controls.harmonizedSystemSubHeadingCode.id
      )
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('Should call commodityCodeCheckBoxClicked', () => {
    const checkBox = rootElement.query(By.css('.mat-checkbox-input'));
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    expect(checkBox.nativeElement.checked).toBeFalsy();
    checkBox.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    expect(checkBox.nativeElement.checked).toBeTruthy();
  });

  it('Should call Search button', () => {
    window.open = (): Window => {
      return null;
    };
    const addSection = rootElement.query(By.css('#searchButton'));
    addSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.searchClicked).toHaveBeenCalled());
  });
  it('should test hssCode', () => {
    const spy = jest.spyOn(component.hssChangeAction, 'emit');
    component.hssOnFocusOut('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test cnnCode', () => {
    const spy = jest.spyOn(component.cnnChangeAction, 'emit');
    component.cnnOnFocusOut('', '');
    expect(spy).toHaveBeenCalled();
  });
});
