/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable sonarjs/no-duplicate-string */ import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  Commodity,
  CommodityCode,
  Packaging,
  PreviousDocument
} from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormArrayState,
  formStateReducer,
  MarkAsTouchedAction,
  SetErrorsAction
} from 'ngrx-forms';

import { ConsignmentItemInfoService } from '../../../services/con-item-info.service';
import { conItemInfoReducer } from '../../store/reducers/con-item-info.reducer';

import { PackagingComponent } from './packaging.component';
describe('PackagingComponent', () => {
  let component: PackagingComponent;
  let fixture: ComponentFixture<PackagingComponent>;
  let rootElement: DebugElement;
  let facade: ConsignmentItemInfoService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PackagingComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        StoreModule.forRoot(conItemInfoReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        TranslateModule.forRoot()
      ],
      providers: [ConsignmentItemInfoService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PackagingComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormArrayState<Packaging>('packaging', [
      { typeOfPackages: '', numberOfPackages: null, shippingMarks: '' }
    ]);
    component.formState = INITIAL_STATE;
    component.CL017Codelist = [];
    rootElement = fixture.debugElement;
    facade = TestBed.inject(ConsignmentItemInfoService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should check the validity of type field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(
        component.formState.controls[0].controls.typeOfPackages.id,
        {
          errors: {
            errorType: 'br12'
          }
        }
      )
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(
        updatedGroupViaAction.controls[0].controls.typeOfPackages.id
      )
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });
  it('should call deletePackaging', () => {
    const spy = jest.spyOn(component.removePackagingElementAction, 'emit');
    component.deletePackaging(1);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('Should call addPackaging', () => {
    const addSection = rootElement.query(By.css('.add-button'));
    addSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.addPackaging).toHaveBeenCalled());
  });
  it('Should call deletePackaging', () => {
    const INITIAL_STATE = createFormArrayState<Packaging>('packaging', [
      { typeOfPackages: '', numberOfPackages: '', shippingMarks: '' },
      { typeOfPackages: '', numberOfPackages: '', shippingMarks: '' }
    ]);
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
    const removeSection = rootElement.query(By.css('#containerRemoveButton0'));
    removeSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.deletePackaging).toHaveBeenCalled());
  });

  it('Should call numberFocusOut', () => {
    const input = rootElement.query(By.css('#number'));
    input.nativeElement.dispatchEvent(
      new FocusEvent('focusout', { detail: 0 })
    );
    fixture.detectChanges();

    expect(component.isWeightMandatory).toBeFalsy();
  });
  it('Should call focus', () => {
    const input = rootElement.query(By.css('#shippingMarks'));
    input.nativeElement.dispatchEvent(new FocusEvent('focus', { detail: 0 }));
    fixture.detectChanges();
    expect(component.hintLength).toBeGreaterThanOrEqual(0);
  });

  it('Should call blur', () => {
    const input = rootElement.query(By.css('#shippingMarks'));
    input.nativeElement.dispatchEvent(new FocusEvent('blur', { detail: 0 }));
    fixture.detectChanges();
    expect(component.hintLength).toBeGreaterThanOrEqual(13);
  });

  it('Should call keyDown', () => {
    const input = rootElement.query(By.css('#number'));
    input.nativeElement.dispatchEvent(new FocusEvent('keydown', { detail: 0 }));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.numberOfSealKeyDown).toHaveBeenCalled());
  });

  it('Should test numberOnFocusOut', () => {
    component.numberOnFocusOut(0, 'VL', 0);
    expect(component.isWeightMandatory).toBeTruthy();

    component.numberOnFocusOut(0, 'aa', 0);
    expect(component.isWeightMandatory).toBeFalsy();
  });
  it('Should test filterPackagingType', () => {
    const INITIAL_STATE = createFormArrayState<Packaging>('packaging', [
      { typeOfPackages: 'A - Empty', numberOfPackages: '', shippingMarks: '' },
      { typeOfPackages: 'A - Empty', numberOfPackages: '', shippingMarks: '' }
    ]);
    component.formState = INITIAL_STATE;
    component.CL017Codelist = [
      {
        'id': 1,
        'value': 'A',
        'definition': 'A - Empty'
      },
      {
        'id': 2,
        'value': 'B',
        'definition': 'B - Not empty'
      }
    ];
    fixture.detectChanges();
    component.filterPackagingType(1);
    expect(component.packagingTypeList).toEqual([
      {
        'id': 1,
        'value': 'A',
        'definition': 'A - Empty'
      }
    ]);
  });
  it('Should test validatePackagingType', () => {
    component.CL017Codelist = [
      {
        'id': 1,
        'value': 'A',
        'definition': 'Empty'
      },
      {
        'id': 2,
        'value': 'B',
        'definition': 'Not empty'
      }
    ];
    const spy = jest.spyOn(component.validatePackagingTypeEvent, 'emit');
    component.validatePackagingType('A - Empty', 1);
    expect(spy).toHaveBeenCalledWith({
      index: 1,
      value: 'A - Empty',
      codeList: ['A - Empty', 'B - Not empty']
    });
  });
});
