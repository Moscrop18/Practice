/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output
} from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { codeListReducer } from '@core/gateways/codelist/store/reducer/code-list.reducer';
import { FormArrayState } from 'ngrx-forms';

import { Packaging } from '../../../models/consignment-item-form-value';
import { ConsignmentItemInfoService } from '../../../services/con-item-info.service';

@Component({
  selector: 'app-packaging',
  templateUrl: './packaging.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class PackagingComponent {
  @Input() formState: FormArrayState<Packaging>;
  @Input() CL017Codelist: Codelist[];
  constructor(public masterConItemService: ConsignmentItemInfoService) {}

  numberReqFor = ['VQ', 'VG', 'VL', 'VY', 'VR', 'VS', 'VO', 'NE', 'NF', 'NG'];
  @Output() removePackagingElementAction = new EventEmitter();
  @Output() addPackagingElementAction = new EventEmitter();
  @Output() packagingTypechangedWeight = new EventEmitter();
  @Output() packagingTypeChanged = new EventEmitter();
  @Output() validatePackagingTypeEvent = new EventEmitter();
  checked = false;
  hintLength = 13;
  isWeightMandatory = false;
  packagingTypeList: Codelist[];

  getOptionList(): void {
    if (this.formState.controls.length === 1)
      this.packagingTypeList = this.CL017Codelist;
    else {
      this.masterConItemService.packagingCodeList.subscribe(
        (codeList: Codelist[]) => (this.packagingTypeList = codeList)
      );
    }
  }
  changeHintLength() {
    this.hintLength = 0;
  }
  changeHint() {
    this.hintLength = 13;
  }
  typeChanged(value: string, i: number) {
    this.packagingTypeChanged.emit({ value: value, index: i });
  }
  deletePackaging(i: number) {
    this.removePackagingElementAction.emit(i);
    if (!i) {
      this.checked = false;
    }
  }
  trackByFn(index: number, item: any) {
    return index;
  }
  addPackaging() {
    this.addPackagingElementAction.emit();
  }

  numberOfSealKeyDown(e: KeyboardEvent) {
    const key = e.keyCode ? e.keyCode : e.which;
    if (
      !(
        [8, 9, 13, 27, 46, 110, 190].indexOf(key) !== -1 ||
        (key == 65 && (e.ctrlKey || e.metaKey)) ||
        (key >= 35 && key <= 40) ||
        (key >= 48 && key <= 57 && !(e.shiftKey || e.altKey)) ||
        (key >= 96 && key <= 105)
      )
    ) {
      e.preventDefault();
    }
  }

  numberOnFocusOut(number, type, i) {
    if (this.numberReqFor.includes(type) && (number == null || number == '')) {
      this.isWeightMandatory = true;
    } else {
      this.isWeightMandatory = false;
    }
    this.packagingTypechangedWeight.emit(this.isWeightMandatory);
  }

  filterPackagingType(i: number): void {
    this.packagingTypeList = this.CL017Codelist.filter(
      (option) =>
        option?.value
          ?.toLowerCase()
          .includes(
            this.formState.controls[
              i
            ].controls.typeOfPackages.value.toLowerCase()
          ) ||
        option?.definition
          ?.toLowerCase()
          .includes(
            this.formState.controls[
              i
            ].controls.typeOfPackages.value.toLowerCase()
          )
    );
  }
  validatePackagingType(selectedValue: string, i: number): void {
    this.typeChanged(selectedValue.split('-')[0].trim(), i);
    const resultArray: string[] = [];
    this.CL017Codelist.forEach((code) => {
      resultArray.push(code.value + ' - ' + code.definition);
    });
    this.validatePackagingTypeEvent.emit({
      index: i,
      value: selectedValue,
      codeList: resultArray
    });
  }
}
