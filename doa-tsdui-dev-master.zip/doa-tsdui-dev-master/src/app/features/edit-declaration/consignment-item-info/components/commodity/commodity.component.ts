/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { FormState, NgrxValueConverter, NgrxValueConverters } from 'ngrx-forms';

import { Commodity } from '../../../models/consignment-item-form-value';
// import { Item } from "../models/master-consignment/item";

@Component({
  selector: 'app-commodity',
  templateUrl: './commodity.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CommodityComponent {
  @Input() formState: FormState<Commodity>;
  @Input() CL016Codelist: Codelist[];
  @Output() validateCusCodeEvent = new EventEmitter<{
    value: string;
    codeList: string[];
  }>();
  fieldOption: Codelist[];
  hintLength = 20;
  getOptionList() {
    this.fieldOption = this.CL016Codelist;
  }
  filter() {
    this.fieldOption = this.CL016Codelist.filter(
      (option) =>
        option?.value
          ?.toLowerCase()
          .includes(this.formState.controls.cusCode.value.toLowerCase()) ||
        option?.definition
          ?.toLowerCase()
          .includes(this.formState.controls.cusCode.value.toLowerCase())
    );
  }
  changeHintLength() {
    this.hintLength = 0;
  }
  onCusCodeChange(event: any) {
    const resultArray: string[] = [];
    this.CL016Codelist.forEach((code) => {
      resultArray.push(code?.value + ' - ' + code?.definition);
    });
    this.validateCusCodeEvent.emit({
      value: event,
      codeList: resultArray
    });
  }
}
