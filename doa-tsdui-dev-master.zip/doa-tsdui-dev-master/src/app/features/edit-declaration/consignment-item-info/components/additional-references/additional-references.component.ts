/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output
} from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { FormArrayState } from 'ngrx-forms';

import { AdditionalReferences } from '../../../models/consignment-item-form-value';
// import { PRELODGED } from "./../../../../../shared/constant/create-declaration-constants";

@Component({
  selector: 'app-additional-references',
  templateUrl: './additional-references.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdditionalReferencesComponent {
  @Input() formState: FormArrayState<AdditionalReferences>;
  // @Input typeOfTsd: String;
  public CL213Codelist: any;
  @Output() addAddrefElementAction = new EventEmitter();
  @Output() removeAddrefElementAction = new EventEmitter<number>();
  @Output() removeAddrefAllElementAction = new EventEmitter();
  @Input() CL380Codelist: Codelist[];
  @Output() validateAdditionalReferencesEvent = new EventEmitter<any>();
  fieldOption: Codelist[];
  checked = false;
  noOfAddRef = 1;

  getOptionList() {
    this.fieldOption = this.CL380Codelist;
  }
  filter(index) {
    this.fieldOption = this.CL380Codelist.filter(
      (option) =>
        option?.value
          ?.toLowerCase()
          .includes(
            this.formState.controls[index].controls.type.value.toLowerCase()
          ) ||
        option?.definition
          ?.toLowerCase()
          .includes(
            this.formState.controls[index].controls.type.value.toLowerCase()
          )
    );
  }

  additionalReferencesCheckBoxClicked(clicked: boolean) {
    if (clicked) {
      this.addAdditionalReferences();
      this.checked = true;
    } else {
      this.removeAddrefAllElementAction.emit();
      this.checked = false;
      this.noOfAddRef = 0;
    }
  }

  deleteadditionalReferences(i: number) {
    this.noOfAddRef -= 1;
    this.removeAddrefElementAction.emit(i);

    if (this.noOfAddRef === 1) {
      this.checked = false;
    }
  }

  addAdditionalReferences() {
    this.noOfAddRef += 1;
    this.addAddrefElementAction.emit();
  }

  trackByFn(index: number, item: any) {
    return index;
  }
  onAdditionalReferencesChange(event: any, i: any) {
    const resultArray: string[] = [];
    this.CL380Codelist.forEach((code) => {
      resultArray.push(code?.value + ' - ' + code?.definition);
    });
    this.validateAdditionalReferencesEvent.emit({
      value: event,
      codeList: resultArray,
      index: i
    });
  }
}
