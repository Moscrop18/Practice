/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import {
  AdditionalReferences,
  Commodity,
  CommodityCode,
  PreviousDocument
} from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormArrayState,
  createFormGroupState,
  formStateReducer,
  MarkAsTouchedAction,
  SetErrorsAction
} from 'ngrx-forms';

import { CommodityComponent } from './commodity.component';

describe('CommodityComponent', () => {
  let component: CommodityComponent;
  let fixture: ComponentFixture<CommodityComponent>;
  let rootElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CommodityComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommodityComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<Commodity>('commodity', {
      descriptionOfGoods: '',
      cusCode: ''
    });
    component.formState = INITIAL_STATE;
    component.CL016Codelist = [
      {
        'id': 1,
        'value': '0021238-4',
        'label': '0021238-4',
        'definition': 'Oxalic acid in anhydrous form (CN 2917 11 00)'
      },
      {
        'id': 2,
        'value': '0023277-9',
        'label': '0023277-9',
        'definition': 'Dry sodium gluconate (CN 2918 16 00)'
      }
    ];
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should check the validity of type field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls.descriptionOfGoods.id, {
        errors: {
          errorType: 'required'
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(
        updatedGroupViaAction.controls.descriptionOfGoods.id
      )
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('Should call blur', () => {
    const input = rootElement.query(By.css('#description'));
    input.nativeElement.dispatchEvent(new FocusEvent('focus', { detail: 0 }));
    fixture.detectChanges();
    expect(component.hintLength).toBeGreaterThanOrEqual(0);
  });
  it('should call filter with value', () => {
    const INITIAL_STATE = createFormGroupState<Commodity>('commodity', {
      cusCode: '0023277-9',
      descriptionOfGoods: ''
    });
    component.formState = INITIAL_STATE;
    component.filter();
    expect(component.fieldOption).toEqual([
      {
        'id': 2,
        'value': '0023277-9',
        'label': '0023277-9',
        'definition': 'Dry sodium gluconate (CN 2918 16 00)'
      }
    ]);
  });
  it('should call filter without value', () => {
    const INITIAL_STATE = createFormGroupState<Commodity>('commodity', {
      cusCode: '1234',
      descriptionOfGoods: ''
    });
    component.formState = INITIAL_STATE;
    component.filter();
    expect(component.fieldOption).toEqual([]);
  });
  it('Should test onCusCodeChange', () => {
    const spy = jest.spyOn(component.validateCusCodeEvent, 'emit');

    const selectionValue = '0023277-9 - Dry sodium gluconate (CN 2918 16 00)';
    component.onCusCodeChange(selectionValue);
    expect(spy).toHaveBeenCalledWith({
      'codeList': [
        '0021238-4 - Oxalic acid in anhydrous form (CN 2917 11 00)',
        '0023277-9 - Dry sodium gluconate (CN 2918 16 00)'
      ],
      'value': selectionValue
    });
  });
});
