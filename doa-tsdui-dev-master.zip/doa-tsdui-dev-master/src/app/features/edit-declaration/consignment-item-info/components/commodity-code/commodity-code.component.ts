/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { ConfigService } from '@core/services/config/config.service';
import { FormState } from 'ngrx-forms';

import { CommodityCode } from '../../../models/consignment-item-form-value';

/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
@Component({
  selector: 'app-commodity-code',
  templateUrl: './commodity-code.component.html',
  styleUrls: ['./commodity-code.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CommodityCodeComponent {
  @Input() isCommodityCodeMandatory: boolean;
  @Input() formState: FormState<CommodityCode>;
  @Output() addCommodityCodeAction = new EventEmitter();
  @Output() removeCommodityCodeAction = new EventEmitter();
  @Output() hssChangeAction = new EventEmitter<string>();
  @Output() cnnChangeAction = new EventEmitter<{ hss: string; cnn: string }>();
  checked = true;
  constructor(private configService: ConfigService) {}

  commodityCodeCheckBoxClicked(clicked: boolean) {
    if (clicked) {
      this.checked = true;
      this.addCommodityCodeAction.emit();
    } else {
      this.checked = false;
      this.removeCommodityCodeAction.emit();
    }
  }

  searchClicked() {
    window.open(this.configService.getConfig().minfinUrl, '_blank');
  }
  hssOnFocusOut(hss): void {
    this.hssChangeAction.emit(hss.value);
  }
  cnnOnFocusOut(cnn, hss): void {
    this.cnnChangeAction.emit({ cnn: cnn.value, hss: hss.value });
  }
}
