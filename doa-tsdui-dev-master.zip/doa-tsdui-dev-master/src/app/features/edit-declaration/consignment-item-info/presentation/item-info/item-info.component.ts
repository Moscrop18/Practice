/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { FormGroupState } from 'ngrx-forms';

import {
  ConsignmentItemInfoFormValue,
  DeleteItem
} from '../../../models/consignment-item-form-value';

@Component({
  selector: 'app-item-info',
  templateUrl: './item-info.component.html',
  styleUrls: ['./item-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ItemInfoComponent {
  @Input() isCommodityCodeMandatory: boolean;
  @Input() typeOfTSD: string;
  @Input() isOnlyHouseConsignmentType: boolean;
  @Input() tsdVersion: number;
  @Input() CL709Codelist: Codelist[];
  @Input() consignmentType: string;
  @Input() CL213Codelist: Codelist[];
  @Input() CL017Codelist: Codelist[];
  @Input() CL016Codelist: Codelist[];
  @Input() CL380Codelist: Codelist[];
  @Input() CL704Codelist: Codelist[];
  @Input() CL214PreCodelist: Codelist[];
  @Input() CL214ComCodelist: Codelist[];
  @Input() formState: FormGroupState<ConsignmentItemInfoFormValue>;
  isWeightMandatory: any;
  @Input() itemNo: number;
  @Input() consNo: number;
  @Input() parentStepName: number;
  @Input() allowedSections: string[];
  @Output() addAddrefElementAction = new EventEmitter();
  @Output() hssChangeAction = new EventEmitter<string>();
  @Output() cnnChangeAction = new EventEmitter<{ cnn: string; hss: string }>();
  @Output() removeSealIdentifierGrpElementAction = new EventEmitter();
  @Output() removeAddrefElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeAddrefAllElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addPackagingElementAction = new EventEmitter();
  @Output() removePackagingElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addTranEquipGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeTranEquipGrpElementAction = new EventEmitter<{
    index: number;
  }>();
  @Output() removeTranEquipAllElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addAdditionalInfoGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeAdditionalInfoGrpElementAction = new EventEmitter<{
    index: number;
  }>();
  @Output() removeAdditionalInfoAllGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addPrevDocGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removePrevDocGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addSuppChainActorGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeSuppChainActorGrpElementAction = new EventEmitter<{
    index: number;
  }>();
  @Output() removeSuppChainActorAllGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addCommodityCodeAction = new EventEmitter();
  @Output() removeCommodityCodeAction = new EventEmitter();
  @Output() addSupDocGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() removeSupDocGrpElementAction = new EventEmitter<{
    index: number;
  }>();
  @Output() removeSupDocAllGrpElementAction = new EventEmitter<{
    element: string;
  }>();
  @Output() addSealIdentifierGrpElementAction = new EventEmitter<{
    index: number;
  }>();
  @Output() disableSealIdentifierGrpElementAction = new EventEmitter();
  @Output() addWeightAction = new EventEmitter();
  @Output() packagingTypeChangedAction = new EventEmitter();
  @Output() validatePackagingTypeAction = new EventEmitter();
  @Output() removeWeightAction = new EventEmitter();
  @Output() ifItem = true;
  @Output() eoriChangeAction = new EventEmitter<{
    event: { eori: string; index: number };
  }>();
  @Output() deleteItemAction = new EventEmitter<DeleteItem>();
  @Output() validateSupportingDocumentEvent = new EventEmitter<string>();
  @Output() validateCusCodeEvent = new EventEmitter<{
    value: string;
    codeList: string[];
  }>();
  @Output() validateAdditionalReferencesEvent = new EventEmitter<any>();
  @Output()
  validateSupportingDocumentReferenceNumberEvent = new EventEmitter<any>();

  addWeight() {
    this.addWeightAction.emit();
  }
  removeWeight() {
    this.removeWeightAction.emit();
  }
  removeAddrefAllElement(element: string) {
    this.removeAddrefAllElementAction.emit({
      element: element
    });
  }
  addAddrefElement() {
    this.addAddrefElementAction.emit();
  }
  removeAddrefElement(element: string) {
    this.removeAddrefElementAction.emit({
      element: element
    });
  }
  eoriChange(event: { eori: string; index: number }) {
    this.eoriChangeAction.emit({ event: event });
  }
  addPackaging() {
    this.addPackagingElementAction.emit();
  }
  removePackaging(element: string) {
    this.removePackagingElementAction.emit({
      element: element
    });
  }
  removeSealIdentifierGrpElement(e) {
    this.removeSealIdentifierGrpElementAction.emit(e);
  }
  removeTransEquipAllElement(element: string) {
    this.removeTranEquipAllElementAction.emit({
      element: element
    });
  }
  addTransEquipElement(element: string) {
    this.addTranEquipGrpElementAction.emit({
      element: element
    });
  }
  removeTransEquipElement(index: number) {
    this.removeTranEquipGrpElementAction.emit({
      index: index
    });
  }
  addSuppDocElement(element: string) {
    this.addSupDocGrpElementAction.emit({
      element: element
    });
  }
  removeSuppDocAllElement(element: string) {
    this.removeSupDocAllGrpElementAction.emit({
      element: element
    });
  }
  removeSuppDocElement(index: number) {
    this.removeSupDocGrpElementAction.emit({
      index: index
    });
  }
  addAddInfoElement(element: string) {
    this.addAdditionalInfoGrpElementAction.emit({
      element: element
    });
  }
  removeAddInfoElement(index: number) {
    this.removeAdditionalInfoGrpElementAction.emit({
      index: index
    });
  }

  removeAddInfoAllElement(element: string) {
    this.removeAdditionalInfoAllGrpElementAction.emit({
      element: element
    });
  }
  removeAddScaAllElement(element: string) {
    this.removeSuppChainActorAllGrpElementAction.emit({
      element: element
    });
  }
  removeAddScaElement(index: number) {
    this.removeSuppChainActorGrpElementAction.emit({
      index: index
    });
  }
  addAddScaElement(element: string) {
    this.addSuppChainActorGrpElementAction.emit({
      element: element
    });
  }
  addPrevDocGrpElement(element: string) {
    this.addPrevDocGrpElementAction.emit({
      element: element
    });
  }
  removePrevDocGrpElement(element: string) {
    this.removePrevDocGrpElementAction.emit({
      element: element
    });
  }
  addCommodityCode() {
    this.addCommodityCodeAction.emit();
  }
  removeCommodityCode() {
    this.removeCommodityCodeAction.emit();
  }
  addSealIdentifierGrpElement(index: number) {
    this.addSealIdentifierGrpElementAction.emit({
      index: index
    });
  }
  disableSealIdentifierGrpElement() {
    this.disableSealIdentifierGrpElementAction.emit();
  }
  itemDeleted(itemNumber: number) {
    this.deleteItemAction.emit({
      sequence: itemNumber,
      pSequence: this.consNo
    });
  }
  packagingTypechangedWeight(event) {
    this.isWeightMandatory = event;
  }

  packagingTypeChanged(event) {
    this.packagingTypeChangedAction.emit(event);
  }
  validatePackagingTypeEvent(event) {
    this.validatePackagingTypeAction.emit(event);
  }
  hssChangeActionEvent(event) {
    this.hssChangeAction.emit(event);
  }
  cnnChangeActionEvent(event) {
    this.cnnChangeAction.emit({ cnn: event.cnn, hss: event.hss });
  }
  validateSupportingDocument(event: any): void {
    this.validateSupportingDocumentEvent.emit(event);
  }
  validateCusCode(event: any): void {
    this.validateCusCodeEvent.emit(event);
  }
  validateAdditionalReferences(event: any): void {
    this.validateAdditionalReferencesEvent.emit(event);
  }
  validateSupportingDocumentReferenceNumber(event: any): void {
    this.validateSupportingDocumentReferenceNumberEvent.emit(event);
  }
}
