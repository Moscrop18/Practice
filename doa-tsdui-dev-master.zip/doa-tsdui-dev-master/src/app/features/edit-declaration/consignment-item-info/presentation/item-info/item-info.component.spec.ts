/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable sonarjs/no-duplicate-string */

import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import { ConsignmentItemInfoFormValue } from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { createFormGroupState } from 'ngrx-forms';

import { ConItemInfoEffects } from '../../store/effects/con-item-info.effects';
import { conItemInfoReducer } from '../../store/reducers/con-item-info.reducer';

import { ItemInfoComponent } from './item-info.component';

describe('GeneralInfoComponent', () => {
  cacheTestingModule();
  let component: ItemInfoComponent;
  let fixture: ComponentFixture<ItemInfoComponent>;
  let rootElement: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        EditDeclarationModule,
        RouterTestingModule,
        TranslateModule.forRoot(),
        StoreModule.forRoot(conItemInfoReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        EffectsModule.forRoot([
          CodeListEffects,
          ConItemInfoEffects,
          ConsInfoEffects
        ]),
        HttpClientModule
      ],
      providers: [ConfigService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemInfoComponent);
    component = fixture.componentInstance;
    component.allowedSections = [
      'PreviousDocument',
      'TransportEquipment',
      'SupportingDocument',
      'AdditionalInformation',
      'AddditionalSupplyChainActor'
    ];
    const INITIAL_STATE = createFormGroupState<ConsignmentItemInfoFormValue>(
      'conItemInfo',
      {
        commodity: {
          descriptionOfGoods: '',
          cusCode: ''
        },
        commodityCode: {
          harmonizedSystemSubHeadingCode: '',
          combinedNomenclatureCode: ''
        },
        packaging: [
          {
            typeOfPackages: '',
            numberOfPackages: '',
            shippingMarks: ''
          }
        ],
        weight: {
          weight: null
        },
        previousDocument: {
          type: '',
          referenceNumber: ''
        },
        transportEquipments: [],
        supportingDocuments: [],
        additionalInformations: [],
        additionalReferences: [],
        additionalSupplyChainActors: []
      }
    );
    component.formState = INITIAL_STATE;
    component.CL017Codelist = [];
    component.CL016Codelist = [];
    component.CL380Codelist = [];
    component.CL709Codelist = [];
    component.CL213Codelist = [];
    component.CL704Codelist = [];
    component.CL214PreCodelist = [];
    component.CL214ComCodelist = [];
    component.typeOfTSD = 'prelodged';
    component.consignmentType = 'house';
    component.ifItem = true;
    component.isCommodityCodeMandatory = true;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should call deleteItem button', () => {
    const deleteButton = rootElement.query(By.css('.delete-button'));
    deleteButton.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.itemDeleted).toHaveBeenCalled());
  });
  it('should test deleteItemAction', () => {
    const spy = jest.spyOn(component.deleteItemAction, 'emit');
    component.itemDeleted(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test disableSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(
      component.disableSealIdentifierGrpElementAction,
      'emit'
    );
    component.disableSealIdentifierGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(component.addSealIdentifierGrpElementAction, 'emit');
    component.addSealIdentifierGrpElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeCommodityCode', () => {
    const spy = jest.spyOn(component.removeCommodityCodeAction, 'emit');
    component.removeCommodityCode();
    expect(spy).toHaveBeenCalled();
  });
  it('should test addCommodityCode', () => {
    const spy = jest.spyOn(component.addCommodityCodeAction, 'emit');
    component.addCommodityCode();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removePrevDocGrpElement', () => {
    const spy = jest.spyOn(component.removePrevDocGrpElementAction, 'emit');
    component.removePrevDocGrpElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addPrevDocGrpElement', () => {
    const spy = jest.spyOn(component.addPrevDocGrpElementAction, 'emit');
    component.addPrevDocGrpElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addAddScaElement', () => {
    const spy = jest.spyOn(component.addSuppChainActorGrpElementAction, 'emit');
    component.addAddScaElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddScaElement', () => {
    const spy = jest.spyOn(
      component.removeSuppChainActorGrpElementAction,
      'emit'
    );
    component.removeAddScaElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddScaAllElement', () => {
    const spy = jest.spyOn(
      component.removeSuppChainActorAllGrpElementAction,
      'emit'
    );
    component.removeAddScaAllElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddInfoAllElement', () => {
    const spy = jest.spyOn(
      component.removeAdditionalInfoAllGrpElementAction,
      'emit'
    );
    component.removeAddInfoAllElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddInfoElement', () => {
    const spy = jest.spyOn(
      component.removeAdditionalInfoGrpElementAction,
      'emit'
    );
    component.removeAddInfoElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test addAddInfoElement', () => {
    const spy = jest.spyOn(component.addAdditionalInfoGrpElementAction, 'emit');
    component.addAddInfoElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSuppDocElement', () => {
    const spy = jest.spyOn(component.removeSupDocGrpElementAction, 'emit');
    component.removeSuppDocElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSuppDocAllElement', () => {
    const spy = jest.spyOn(component.removeSupDocAllGrpElementAction, 'emit');
    component.removeSuppDocAllElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addSuppDocElement', () => {
    const spy = jest.spyOn(component.addSupDocGrpElementAction, 'emit');
    component.addSuppDocElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeTransEquipElement', () => {
    const spy = jest.spyOn(component.removeTranEquipGrpElementAction, 'emit');
    component.removeTransEquipElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test addTransEquipElement', () => {
    const spy = jest.spyOn(component.addTranEquipGrpElementAction, 'emit');
    component.addTransEquipElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeTransEquipAllElement', () => {
    const spy = jest.spyOn(component.removeTranEquipAllElementAction, 'emit');
    component.removeTransEquipAllElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(
      component.removeSealIdentifierGrpElementAction,
      'emit'
    );
    component.removeSealIdentifierGrpElement(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test removePackaging', () => {
    const spy = jest.spyOn(component.removePackagingElementAction, 'emit');
    component.removePackaging('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addPackaging', () => {
    const spy = jest.spyOn(component.addPackagingElementAction, 'emit');
    component.addPackaging();
    expect(spy).toHaveBeenCalled();
  });
  it('should test eoriChange', () => {
    const spy = jest.spyOn(component.eoriChangeAction, 'emit');
    component.eoriChange({ eori: '', index: 2 });
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddrefElement', () => {
    const spy = jest.spyOn(component.removeAddrefElementAction, 'emit');
    component.removeAddrefElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addAddrefElement', () => {
    const spy = jest.spyOn(component.addAddrefElementAction, 'emit');
    component.addAddrefElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeAddrefAllElement', () => {
    const spy = jest.spyOn(component.removeAddrefAllElementAction, 'emit');
    component.removeAddrefAllElement('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addWeightAction', () => {
    const spy = jest.spyOn(component.addWeightAction, 'emit');
    component.addWeight();
    expect(spy).toHaveBeenCalled();
  });
  it('should test removeWeight', () => {
    const spy = jest.spyOn(component.removeWeightAction, 'emit');
    component.removeWeight();
    expect(spy).toHaveBeenCalled();
  });
  it('should test hssCode', () => {
    const spy = jest.spyOn(component.hssChangeAction, 'emit');
    component.hssChangeActionEvent('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test cnnCode', () => {
    const spy = jest.spyOn(component.cnnChangeAction, 'emit');
    component.cnnChangeActionEvent('');
    expect(spy).toHaveBeenCalled();
  });
});
