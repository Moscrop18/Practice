/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  OnInit,
  Output
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Codelist } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListState } from '@core/gateways/codelist/store/reducer/code-list.reducer';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import {
  ConsignmentInformation,
  ItemInformation
} from '@features/manage-declaration/models/consignment-information';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { FormGroupState } from 'ngrx-forms';
import { Observable, Subscription } from 'rxjs';

import {
  ConsignmentItemInfoFormValue,
  DeleteItem
} from '../../../models/consignment-item-form-value';
import { ConsignmentItemInfoService } from '../../../services/con-item-info.service';
import { EditDeclarationFacade } from '../../../services/edit-declaration.facade';

@Component({
  selector: 'app-order-specification-form',
  templateUrl: './con-item-info.component.html'
})
export class ConItemInfoComponent implements OnInit, OnDestroy {
  @Output()
  public CL709Codelist: Codelist[];
  public CL213Codelist: Codelist[];
  public CL704Codelist: Codelist[];
  public CL017Codelist: Codelist[];
  public CL016Codelist: Codelist[];
  public CL380Codelist: Codelist[];
  public CL214PreCodelist: Codelist[];
  public CL214ComCodelist: Codelist[];
  public typeOfTSD: string;
  public consignmentType: string;
  public ensReUse: boolean;
  public formState$: Observable<FormGroupState<ConsignmentItemInfoFormValue>>;
  consignmentInfo$: Observable<ConsignmentInformation>;
  consultGenInfodata$: Observable<ConsultGeneralInformation>;
  public loginForm: FormGroup;
  public itemNo: number;
  public consNo: number;
  public tsdId: number;
  public tsdVersion: number;
  public isOnlyHouseConsignmentType: boolean;
  isCommodityCodeMandatory = false;
  public allowedSections: string[];
  currentItem: ItemInformation;
  codeLists$: Observable<CodeListState>;
  declarationSubscription: Subscription;
  consignmentSubscription: Subscription;
  routeSubscription: Subscription;
  declarationData: ConsultGeneralInformation;
  itemInfo$: Observable<ItemInformation>;
  itemInfoSubscription: Subscription;

  constructor(
    private editDeclarationFacade: EditDeclarationFacade,
    private codelistService: CodeListService,
    private masterConGenItemService: ConsignmentItemInfoService,
    private ref: ChangeDetectorRef
  ) {
    this.codeLists$ = this.editDeclarationFacade.getCodeLists();
    this.consultGenInfodata$ = this.editDeclarationFacade.fetchGeneralInformationData();
    this.consignmentInfo$ = this.editDeclarationFacade.fetchConsInfo();
    this.itemInfo$ = this.editDeclarationFacade.fetchConsItemInfo();
    this.formState$ = this.masterConGenItemService.getFormState();
    this.handleDeclarationSubscription();
    this.handleConsignmentSubscription();
    this.handleItemSubscription();
  }
  ngOnDestroy(): void {
    this.declarationSubscription?.unsubscribe();
    this.consignmentSubscription?.unsubscribe();
    this.itemInfoSubscription?.unsubscribe();
    this.routeSubscription?.unsubscribe();
  }
  ngOnInit(): void {
    this.ref.detectChanges();
    this.routeSubscription = this.editDeclarationFacade.currentRouteParams.subscribe(
      (route) => {
        this.consNo = parseInt(route.queryParams.consNo);
        this.tsdId = parseInt(route.queryParams.tsdId);
        this.itemNo = parseInt(route.queryParams.itemNo);
        this.consignmentType =
          this.consNo === 0 ? constants.MASTER : constants.HOUSE;
      }
    );

    this.masterConGenItemService.initializeState();
    this.codelistService.getCL214PrelodgedCodeList().subscribe((codelist) => {
      this.CL214PreCodelist = codelist;
    });
    this.codelistService.getCL214CombinedCodeList().subscribe((codelist) => {
      this.CL214ComCodelist = codelist;
    });
    this.codelistService.getCL709CodeList().subscribe((codelist) => {
      this.CL709Codelist = codelist;
    });
    this.codelistService.getCL213CodeList().subscribe((codelist) => {
      this.CL213Codelist = codelist;
    });
    this.codelistService.getCL704CodeList().subscribe((codelist) => {
      this.CL704Codelist = codelist;
    });
    this.codelistService.getCL017CodeList().subscribe((codelist) => {
      this.CL017Codelist = codelist;
    });
    this.codelistService.getCL016CodeList().subscribe((codelist) => {
      this.CL016Codelist = codelist;
    });
    this.codelistService.getCL380CodeList().subscribe((codelist) => {
      this.CL380Codelist = codelist;
    });
  }
  handleDeclarationSubscription(): void {
    this.declarationSubscription = this.consultGenInfodata$.subscribe(
      (data) => {
        if (data) {
          this.declarationData = data;
          this.typeOfTSD = data.type;
          this.tsdVersion = parseInt(data.version.toString());
          this.isOnlyHouseConsignmentType = data?.consignmentType?.includes(
            'Master'
          )
            ? false
            : true;
          this.ensReUse = data.ensReuseIndicator.toString() === '1';
        }
      }
    );
  }
  packagingTypeChanged(event) {
    this.masterConGenItemService.packagingTypeChanged(event.value, event.index);
    if (event.index == 0)
      this.masterConGenItemService.getRemainingPackagesCodeList(event.value);
  }
  validatePackagingTypeEvent(event) {
    this.masterConGenItemService.validatePackagingType(event);
  }
  handleConsignmentSubscription(): void {
    this.consignmentSubscription = this.consignmentInfo$.subscribe(
      (consignment) => {
        if (consignment) {
          if (
            consignment.consignee &&
            consignment.consignor &&
            consignment.consignee.typeOfPerson?.toString() === '1' &&
            consignment.consignor.typeOfPerson?.toString() === '1'
          )
            this.isCommodityCodeMandatory = false;
          else this.isCommodityCodeMandatory = true;
        }
      }
    );
  }
  handleItemSubscription(): void {
    this.itemInfoSubscription = this.itemInfo$.subscribe((item) => {
      if (item) {
        this.currentItem = item;
        this.allowedSections = item.allowedSections;
      }
    });
  }

  addWeight() {
    this.masterConGenItemService.addWeightGroupElement();
  }
  removeWeight() {
    this.masterConGenItemService.removeWeightGroupElement();
  }
  addSealIdentifierGrpElement(event: { index: number }) {
    this.masterConGenItemService.addSealIdentifierGroupElement(event.index);
  }
  disableSealIdentifierGrpElement() {
    this.masterConGenItemService.disableSealIdentifierGroupElement();
  }
  addAddRefGrpElement() {
    this.masterConGenItemService.addAdditionalReferencesGroupElement();
  }
  addPackagingGrpElement() {
    this.masterConGenItemService.addPackagingGroupElement();
  }
  removeAddrefElement(event: { element: number }) {
    this.masterConGenItemService.removeAdditionalReferencesGroupElement(
      event.element
    );
  }
  removePackagingElement(event: { element: number }) {
    this.masterConGenItemService.removePackagingGroupElement(event.element);
  }
  removeAddrefAllElement() {
    this.masterConGenItemService.removeAllAdditionalReferencesGroupElement();
  }
  removeTransEquipAllElement() {
    this.masterConGenItemService.removeTransportEquipmentAllGroupElement();
  }
  addTransEquipElement() {
    this.masterConGenItemService.addTransportEquipmentGroupElement();
  }
  removeTransEquipElement(event: { index: number }) {
    this.masterConGenItemService.removeTransportEquipmentGroupElement(
      event.index
    );
  }
  addSuppDocElement() {
    this.masterConGenItemService.addSupportinDocumentGroupElement();
  }
  removeSealIdentifierGrpElement(e: {
    index: number;
    sealIdentifierIndex: number;
  }) {
    this.masterConGenItemService.removeSealIdentifierGroupElement(
      e.index,
      e.sealIdentifierIndex
    );
  }
  removeSuppDocAllElement() {
    this.masterConGenItemService.removeSupportinDocumentAllGroupElement();
  }
  removeSuppDocElement(event: { index: number }) {
    this.masterConGenItemService.removeSupportinDocumentGroupElement(
      event.index
    );
  }
  addAddInfoElement() {
    this.masterConGenItemService.addAdditionalInformationGroupElement();
  }
  removeAddInfoElement(event: { index: number }) {
    this.masterConGenItemService.removeAdditionalInformationGroupElement(
      event.index
    );
  }

  removeAddInfoAllElement() {
    this.masterConGenItemService.removeAdditionalInformationAllGroupElement();
  }
  removeAddScaAllElement() {
    this.masterConGenItemService.removeAdditionalSupplyChainActorAllGroupElement();
  }
  removeAddScaElement(event: { index: number }) {
    this.masterConGenItemService.removeAdditionalSupplyChainActorGroupElement(
      event.index
    );
  }
  addAddScaElement() {
    this.masterConGenItemService.addAdditionalSupplyChainActorGroupElement();
  }
  addPrevDocGrpElement(event: { element: string; value: string }) {
    this.masterConGenItemService.addPreviousDocumentGroupElement(event);
  }
  removePrevDocGrpElement(event: { element: string }) {
    this.masterConGenItemService.removePreviousDocumentGroupElement(
      event.element
    );
  }
  addCommodityCode() {
    this.masterConGenItemService.addCommodityCodeGroupElement();
  }
  removeCommodityCode() {
    this.masterConGenItemService.removeCommodityCodeGroupElement();
  }
  eoriChange(event) {
    this.masterConGenItemService.validateEori(
      event.event.eori,
      event.event.index
    );
  }
  hssChangeActionEvent(event) {
    this.masterConGenItemService.validateHssCode(event);
  }
  cnnChangeActionEvent(event) {
    this.masterConGenItemService.validateCnnCode(event.cnn, event.hss);
  }
  deleteItem(itemToDelete: DeleteItem): void {
    this.editDeclarationFacade.dispatchDeleteConsignmentItemAction(
      {
        tsdId: this.tsdId,
        consNo: this.consNo
      },
      itemToDelete.sequence
    );
  }
  validateSupportingDocument(event: any) {
    this.masterConGenItemService.validateSupportingDocument(event);
  }
  validateCusCode(event: any) {
    this.masterConGenItemService.validateCusCode(event);
  }
  validateAdditionalReferences(event: any) {
    this.masterConGenItemService.validateAdditionalReferences(event);
  }
  validateSupportingDocumentReferenceNumber(event: any) {
    this.masterConGenItemService.validateSupportingDocumentReferenceNumber(
      event
    );
  }
}
