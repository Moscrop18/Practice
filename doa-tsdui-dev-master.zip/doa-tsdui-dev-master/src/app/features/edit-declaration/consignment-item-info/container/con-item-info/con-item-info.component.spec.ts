/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { ConsignmentItemInfoService } from '@features/edit-declaration/services/con-item-info.service';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of, Subscription } from 'rxjs';
import { masConsInformation } from 'src/assets/mocks/cons-info.mock';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';
import { houseOverview } from 'src/assets/mocks/house-overview.mock';
import { itemsInformation } from 'src/assets/mocks/items-info.mock';

import { ConItemInfoEffects } from '../../store/effects/con-item-info.effects';
import { conItemInfoReducer } from '../../store/reducers/con-item-info.reducer';

import { ConItemInfoComponent } from './con-item-info.component';

describe('ConsignmentGenInfoComponent', () => {
  cacheTestingModule();
  let component: ConItemInfoComponent;
  let fixture: ComponentFixture<ConItemInfoComponent>;
  let facade: ConsignmentItemInfoService;
  let declarationFacade: EditDeclarationFacade;
  const genInfoData: ConsultGeneralInformation = {
    id: 2313413,
    self: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
    lrn: 'REF123456789000000000',
    mrn: '20BETP000000C3FLU4',
    crn: 'CRN21BETS00000000QIU0',
    current: true,
    ensReuseIndicator: 0,
    expirationTimestamp: '2021-04-01T16:50:42.999Z',
    type: 'Combined',
    status: 'PreLodged',
    consignmentType: 'House',
    consignmentItemType: 'House',
    linkedPnFrn: '20BEPN000000C3FLU8',
    registrationDate: '2021-04-01T15:49:42.999Z',
    declarationDate: '2021-04-28T15:50:42.999Z',
    dateAndTimeOfPresentationOfTheGoods: '2022-04-28T15:50:42.999Z',
    version: 2,
    draftErrors: 'All',
    supervisingCustomsOffice: {
      referenceNumber: 'BE212000'
    },
    personPresentingTheGoods: {
      identificationNumber: 'string',
      name: 'string',
      address: {
        streetAndNumber: 'River Road 12',
        country: 'BE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info2@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        }
      ]
    },
    declarant: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      address: {
        streetAndNumber: 'River Road 1234',
        country: 'AD',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        },
        {
          identifier: 'info1@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        }
      ]
    },
    representative: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      status: 'Direct',
      address: {
        streetAndNumber: 'River Road 123',
        country: 'AE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        }
      ]
    },
    consignmentHeader: {
      declaredLocationOfGoods: {
        typeOfLocation: 'D',
        qualifierOfIdentification: 'Y',
        unLoCode: 'BEZAVA00710',
        authorisationNumber: 'Ref1234',
        additionalIdentifier: 'Ref12345',
        gnss: {
          longitude: '50.85045',
          latitude: '4.34878'
        },
        economicOperator: {
          identificationNumber: 'XX0214596464'
        },
        address: {
          streetAndNumber: 'River Road 123',
          country: 'BE',
          postCode: '1000',
          city: 'Brussel',
          poBox: '1234'
        }
      },
      arrivalTransportMeans: {
        identificationNumber: 'IMO1924100',
        typeOfIdentification: '10'
      },
      warehouse: {
        identifier: 'REF123456789',
        type: 'V'
      },
      placeOfUnloading: {
        unLoCode: 'BEZAVA00710'
      },
      presentedLocationOfGoods: {
        typeOfLocation: 'string',
        qualifierOfIdentification: 'string',
        unLoCode: 'string',
        authorisationNumber: 'string',
        additionalIdentifier: 'string',
        customsOffice: {
          referenceNumber: 'string'
        },
        gnss: {
          longitude: 50.85045,
          latitude: 4.34878
        },
        economicOperator: {
          identificationNumber: 'string'
        },
        address: {
          postCode: 'string',
          city: 'string',
          streetAndNumber: 'string',
          country: 'string'
        }
      },
      carrier: {
        identificationNumber: 'string',
        name: 'string'
      }
    },
    amendmentRequest: {
      registrationDate: '2019-08-24T14:15:22Z',
      status: 'Accepted'
    },
    _links: {
      amend:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend',
      draftAmendment:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
      invalidate:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/invalidate',
      consignments:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments'
    }
  };
  const translations: any = {
    'generalInfoForm.errors.requiredWithLength':
      'Please enter a valid LRN, consisting of maximum 22 characters.'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }
  beforeEach(() => {
    return TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CommonModule,
        SharedModule,
        EditDeclarationModule,
        NgrxFormsModule,
        RouterTestingModule,
        MaterialModule,
        StoreModule.forRoot(conItemInfoReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        HttpClientModule,
        EffectsModule.forRoot([
          CodeListEffects,
          ConItemInfoEffects,
          ConsInfoEffects
        ]),
        NoopAnimationsModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        })
      ],
      providers: [
        EditDeclarationFacade,
        CodeListService,
        ConsignmentItemInfoService,
        ConfigService
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConItemInfoComponent);
    component = fixture.componentInstance;
    facade = TestBed.inject(ConsignmentItemInfoService);
    declarationFacade = TestBed.inject(EditDeclarationFacade);
    component.allowedSections = [
      'PreviousDocument',
      'TransportEquipment',
      'SupportingDocument',
      'AdditionalInformation',
      'AdditionalSupplyChainActor'
    ];
    jest
      .spyOn(declarationFacade, 'fetchHouseListData')
      .mockImplementation(() => of(houseOverview));
    jest
      .spyOn(declarationFacade, 'fetchConsInfo')
      .mockImplementation(() => of(masConsInformation));
    jest
      .spyOn(declarationFacade, 'fetchConsItemInfo')
      .mockImplementation(() => of(itemsInformation));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call addSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'addSealIdentifierGroupElement');
    component.addSealIdentifierGrpElement({ index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call ngOnDestroy', () => {
    component.itemInfoSubscription = new Subscription();
    const spy = jest.spyOn(component.itemInfoSubscription, 'unsubscribe');
    component.ngOnDestroy();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSealIdentifierGroupElement');
    component.removeSealIdentifierGrpElement({
      index: 0,
      sealIdentifierIndex: 0
    });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call disableSealIdentifierGrpElement', () => {
    const spy = jest.spyOn(facade, 'disableSealIdentifierGroupElement');
    component.disableSealIdentifierGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addTranEquipGrpElement', () => {
    const spy = jest.spyOn(facade, 'addTransportEquipmentGroupElement');
    component.addTransEquipElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeTranEquipGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeTransportEquipmentGroupElement');
    component.removeTransEquipElement({ index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addCommodityCode', () => {
    const spy = jest.spyOn(facade, 'addCommodityCodeGroupElement');
    component.addCommodityCode();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeCommodityCode', () => {
    const spy = jest.spyOn(facade, 'removeCommodityCodeGroupElement');
    component.removeCommodityCode();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addSca', () => {
    const spy = jest.spyOn(facade, 'addAdditionalSupplyChainActorGroupElement');
    component.addAddScaElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSca', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalSupplyChainActorGroupElement'
    );
    component.removeAddScaElement({ index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeTranEquipAllGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeTransportEquipmentAllGroupElement');
    component.removeTransEquipAllElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addSupDocGrpElement', () => {
    const spy = jest.spyOn(facade, 'addSupportinDocumentGroupElement');
    component.addSuppDocElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSupDocGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSupportinDocumentGroupElement');
    component.removeSuppDocElement({ index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeSupDocAllGrpElement', () => {
    const spy = jest.spyOn(facade, 'removeSupportinDocumentAllGroupElement');
    component.removeSuppDocAllElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removePreviousDocumentGroupElement', () => {
    const spy = jest.spyOn(facade, 'removePreviousDocumentGroupElement');
    component.removePrevDocGrpElement({ element: 'element' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addWeight', () => {
    const spy = jest.spyOn(facade, 'addWeightGroupElement');
    component.addWeight();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeWeight', () => {
    const spy = jest.spyOn(facade, 'removeWeightGroupElement');
    component.removeWeight();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call addAddRef', () => {
    const spy = jest.spyOn(facade, 'addAdditionalReferencesGroupElement');
    component.addAddRefGrpElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeAddRef', () => {
    const spy = jest.spyOn(facade, 'removeAdditionalReferencesGroupElement');
    component.removeAddrefElement({ element: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeAddRefAll', () => {
    const spy = jest.spyOn(facade, 'removeAllAdditionalReferencesGroupElement');
    component.removeAddrefAllElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addAddAdInfo', () => {
    const spy = jest.spyOn(facade, 'addAdditionalInformationGroupElement');
    component.addAddInfoElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeAddInfo', () => {
    const spy = jest.spyOn(facade, 'removeAdditionalInformationGroupElement');
    component.removeAddInfoElement({ index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeAddInfoAll', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalInformationAllGroupElement'
    );
    component.removeAddInfoAllElement();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should test ngOnInit', fakeAsync(() => {
    jest
      .spyOn(declarationFacade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    component.consultGenInfodata$ = declarationFacade.fetchGeneralInformationData();
    const handleConsignmentSubscriptionSpy = jest.spyOn(
      component,
      'handleConsignmentSubscription'
    );
    const queryParams = {
      queryParams: {
        tsdId: '1',
        consNo: '1'
      },
      url: 'http://localhost:4200/edit-declaration/tsd/general-info'
    };
    jest
      .spyOn(declarationFacade, 'currentRouteParams', 'get')
      .mockImplementation(() => of(queryParams));
    component.ngOnInit();
    tick();
    fixture.detectChanges();
    expect(component.consNo).toBe(1);
  }));
  it('should test handleConsignmentSubscription', fakeAsync(() => {
    jest
      .spyOn(declarationFacade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    component.consignmentInfo$ = declarationFacade.fetchConsInfo();
    component.handleConsignmentSubscription();
    tick();
    fixture.detectChanges();
    expect(component.allowedSections).toStrictEqual(
      masConsInformation.allowedSections
    );
  }));
  it('should test handleDeclarationSubscription', fakeAsync(() => {
    jest
      .spyOn(declarationFacade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    component.consultGenInfodata$ = declarationFacade.fetchGeneralInformationData();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    expect(component.typeOfTSD).toStrictEqual(genInfoMockData.type);
  }));
  it('should call addPackagingGrpElement', () => {
    const spy = jest.spyOn(facade, 'addPackagingGroupElement');
    component.addPackagingGrpElement();
    expect(spy).toHaveBeenCalled();
  });
  it('should test handleItemSubscription', fakeAsync(() => {
    component.itemInfo$ = declarationFacade.fetchConsItemInfo();
    component.handleItemSubscription();
    tick();
    fixture.detectChanges();
    expect(component.currentItem).toStrictEqual(itemsInformation);
  }));

  it('should call removePackagingElement', () => {
    const spy = jest.spyOn(facade, 'removePackagingGroupElement');
    component.removePackagingElement({ element: 0 });
    expect(spy).toHaveBeenCalled();
  });

  it('should call removeAddScaAllElement', () => {
    const spy = jest.spyOn(
      facade,
      'removeAdditionalSupplyChainActorAllGroupElement'
    );
    component.removeAddScaAllElement();
    expect(spy).toHaveBeenCalled();
  });

  it('should call eoriChange', () => {
    const spy = jest.spyOn(facade, 'validateEori');
    component.eoriChange({
      event: {
        eori: '111',
        index: '0'
      }
    });
    expect(spy).toHaveBeenCalled();
  });

  it('should call hsscode', () => {
    const spy = jest.spyOn(facade, 'validateHssCode');
    component.hssChangeActionEvent('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test cnncodes', () => {
    const spy = jest.spyOn(facade, 'validateCnnCode');
    component.cnnChangeActionEvent('');
    expect(spy).toHaveBeenCalled();
  });

  it('should handleDeclarationSubscription', fakeAsync(() => {
    jest
      .spyOn(declarationFacade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    fixture.detectChanges();
    component.consultGenInfodata$ = declarationFacade.fetchGeneralInformationData();
    component.consignmentInfo$ = declarationFacade.fetchConsInfo();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.typeOfTSD).toBe(genInfoMockData.type);
    expect(component.isOnlyHouseConsignmentType).toBeFalsy();
  }));

  it('should test isOnlyHouseConsignmentType', fakeAsync(() => {
    jest
      .spyOn(declarationFacade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoData));
    fixture.detectChanges();
    component.consultGenInfodata$ = declarationFacade.fetchGeneralInformationData();
    component.consignmentInfo$ = declarationFacade.fetchConsInfo();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.isOnlyHouseConsignmentType).toBeTruthy();
  }));
  it('should test validateSupportingDocument', () => {
    const spy = jest.spyOn(facade, 'validateSupportingDocument');
    component.validateSupportingDocument(true);
    expect(spy).toHaveBeenCalled();
  });
  it('should test validateCusCode', () => {
    const spy = jest.spyOn(facade, 'validateCusCode');
    component.validateCusCode(true);
    expect(spy).toHaveBeenCalled();
  });
  it('should test validateAdditionalReferences', () => {
    const spy = jest.spyOn(facade, 'validateAdditionalReferences');
    component.validateAdditionalReferences(true);
    expect(spy).toHaveBeenCalled();
  });
});
