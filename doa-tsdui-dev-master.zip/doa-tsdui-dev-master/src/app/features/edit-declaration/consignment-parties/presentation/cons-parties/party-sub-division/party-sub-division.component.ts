/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { CountryCode } from '@core/gateways/codelist/model/country-code';
import { TypeOfPersonCode } from '@core/gateways/codelist/model/type-of-person-code';
import { FormGroupState } from 'ngrx-forms';

import { PartySubDiv } from '../../../../models/cons-parties/party-sub-div';

@Component({
  selector: 'app-party-sub-division',
  templateUrl: './party-sub-division.component.html',
  styleUrls: ['./party-sub-division.component.scss']
})
export class PartySubDivisionComponent {
  @Input() formState: FormGroupState<PartySubDiv>;
  @Input() typeOfPersonCode: TypeOfPersonCode[];
  @Input() communicationTypeCodeList: CommunicationTypeCodeList[];
  @Input() countryCodes: CountryCode[];
  @Output() addCommunicationEvent = new EventEmitter();
  @Output() removeCommunicationEvent = new EventEmitter<any>();
  @Output() addressTypeChangedEvent = new EventEmitter<string>();
  @Output() postCodeChangedEvent = new EventEmitter<string>();
  @Output() additionalStreetChangedEvent = new EventEmitter();
  @Output() countryChangedEvent = new EventEmitter<string>();
  @Output() validateCountryCodeSelectionEvent = new EventEmitter<{
    value: string;
    codeList: string[];
  }>();
  addressTypeRequired = true;
  addCommunication() {
    this.addCommunicationEvent.emit();
  }

  removeCommunication(event: any) {
    this.removeCommunicationEvent.emit(event);
  }
  onAddressTypeChanged(event: any) {
    this.addressTypeChangedEvent.emit(event);
  }
  onAdditionalStreetChanged() {
    this.additionalStreetChangedEvent.emit();
  }
  onPostCodeChanged(event: any) {
    this.postCodeChangedEvent.emit(event);
  }
  onCountryChanged(event: any) {
    this.countryChangedEvent.emit(event);
  }
  validateCountryCodeSelection(event: any) {
    this.validateCountryCodeSelectionEvent.emit(event);
  }
}
