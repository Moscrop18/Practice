/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { CountryCode } from '@core/gateways/codelist/model/country-code';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { FormGroupState } from 'ngrx-forms';

import { TypeOfPersonCode } from '../../../../../core/gateways/codelist/model/type-of-person-code';
import { ConsPartyFormValue } from '../../../models/cons-parties/cons-par-form-value';

@Component({
  selector: 'app-cons-parties',
  templateUrl: './cons-parties.component.html',
  styleUrls: ['./cons-parties.component.scss']
})
export class ConsPartiesComponent {
  @Input() formState: FormGroupState<ConsPartyFormValue>;
  @Input() consignmentId: number;
  @Input() typeOfPersonCode: TypeOfPersonCode[];
  @Input() communicationTypeCodeList: CommunicationTypeCodeList[];
  @Input() countryCodes: CountryCode[];
  @Input() isEnsReuse: boolean;
  @Input() consignmentType: string;
  @Input() sequence: number;
  @Input() isOnlyHouseConsignmentType: boolean;
  @Output() addCommunicationEvent = new EventEmitter<number>();
  @Output() removeCommunicationEvent = new EventEmitter<any>();
  @Output() addressTypeChangedEvent = new EventEmitter<any>();
  @Output() postCodeChangedEvent = new EventEmitter<any>();
  @Output() additionalStreetChangedEvent = new EventEmitter<number>();
  @Output() countryChangedEvent = new EventEmitter<any>();
  @Output() showNotiyPartyEvent = new EventEmitter<boolean>();
  @Output() deleteHouseConsignmentAction = new EventEmitter<number>();
  @Output() validateCountryCodeSelectionEvent = new EventEmitter<any>();
  public get constants() {
    return constants;
  }
  isNotifySectionVisible(): boolean {
    return (
      this.formState.controls.section.controls[2] &&
      Object.keys(this.formState.controls.section.controls[2].controls).length >
        0
    );
  }
  addCommunication(index: number) {
    this.addCommunicationEvent.emit(index);
  }
  removeCommunication(parent: number, event: any) {
    const out = { parent, event };
    this.removeCommunicationEvent.emit(out);
  }
  onAddressTypeChanged(index: number, event: any) {
    const out = { index, event };
    this.addressTypeChangedEvent.emit(out);
  }
  onAdditionalStreetChanged(index: number) {
    this.additionalStreetChangedEvent.emit(index);
  }
  onPostCodeChanged(index: number, event: any) {
    const out = { index, event };
    this.postCodeChangedEvent.emit(out);
  }
  onCountryChanged(index: number, event: any) {
    const out = { index, event };
    this.countryChangedEvent.emit(out);
  }
  showNotifyParty(event: boolean) {
    this.showNotiyPartyEvent.emit(event);
  }

  deleteHouseConsignment(): void {
    this.deleteHouseConsignmentAction.emit(this.sequence);
  }
  validateCountryCodeSelection(index: any, event: any) {
    const out = { index, event };
    this.validateCountryCodeSelectionEvent.emit(out);
  }
}
