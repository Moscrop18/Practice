/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ConsignmentPartiesModule } from '@features/edit-declaration/consignment-parties/consignment-parties.module';
import { consPartiesReducer } from '@features/edit-declaration/consignment-parties/store/reducers/cons-parties.reducer';
import { AddressType } from '@features/edit-declaration/models';
import { PartySubDiv } from '@features/edit-declaration/models/cons-parties/party-sub-div';
import { MaterialModule } from '@material/material.module';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { PartySubDivisionComponent } from './party-sub-division.component';

describe('PartySubDivisionComponent', () => {
  let component: PartySubDivisionComponent;
  let fixture: ComponentFixture<PartySubDivisionComponent>;
  const translations: any = {
    'parties.errors.selectRequired': 'Please select a value'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CommonModule,
        SharedModule,
        NoopAnimationsModule,
        HttpClientModule,
        MaterialModule,
        NoopAnimationsModule,
        NgrxFormsModule,
        ConsignmentPartiesModule,
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        }),
        StoreModule.forRoot(consPartiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PartySubDivisionComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<PartySubDiv>('subDiv', {
      typeOfPerson: '',
      address: {
        addressType: AddressType.STREET_AND_NUMBER,
        street: '',
        number: '',
        country: '',
        city: '',
        postCode: ''
      },
      declarant: {
        communication: [
          {
            type: '',
            identifier: ''
          }
        ],
        eoriIdentification: '',
        name: ''
      },
      subDivision: ''
    });
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call addCommunication', () => {
    const spy = jest.spyOn(component.addCommunicationEvent, 'emit');
    component.addCommunication();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeCommunication', () => {
    const spy = jest.spyOn(component.removeCommunicationEvent, 'emit');
    component.removeCommunication('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onAddressTypeChanged', () => {
    const spy = jest.spyOn(component.addressTypeChangedEvent, 'emit');
    component.onAddressTypeChanged('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onAdditionalStreetChanged', () => {
    const spy = jest.spyOn(component.additionalStreetChangedEvent, 'emit');
    component.onAdditionalStreetChanged();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onPostCodeChanged', () => {
    const spy = jest.spyOn(component.postCodeChangedEvent, 'emit');
    component.onPostCodeChanged('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onCountryChanged', () => {
    const spy = jest.spyOn(component.countryChangedEvent, 'emit');
    component.onCountryChanged('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
});
