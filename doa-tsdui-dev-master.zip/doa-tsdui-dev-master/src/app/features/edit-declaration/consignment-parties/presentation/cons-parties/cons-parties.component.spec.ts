/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { AddressType } from '@features/edit-declaration/models';
import { ConsPartyFormValue } from '@features/edit-declaration/models/cons-parties/cons-par-form-value';
import { PartySubDiv } from '@features/edit-declaration/models/cons-parties/party-sub-div';
import { MaterialModule } from '@material/material.module';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { ConsignmentPartiesModule } from '../../consignment-parties.module';
import { consPartiesReducer } from '../../store/reducers/cons-parties.reducer';

import { ConsPartiesComponent } from './cons-parties.component';
import { PartySubDivisionComponent } from './party-sub-division/party-sub-division.component';

describe('ConsPartiesComponent', () => {
  cacheTestingModule();
  let component: ConsPartiesComponent;
  let fixture: ComponentFixture<ConsPartiesComponent>;
  let de: DebugElement;
  const formEl: PartySubDiv = {
    typeOfPerson: '',
    address: {
      addressType: AddressType.STREET_AND_NUMBER,
      street: '',
      number: '',
      country: '',
      city: '',
      postCode: ''
    },
    declarant: {
      communication: [
        {
          type: '',
          identifier: ''
        }
      ],
      eoriIdentification: '',
      name: ''
    },
    subDivision: ''
  };
  const translations: any = {
    'parties.errors.selectRequired': 'Please select a value'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CommonModule,
        SharedModule,
        NoopAnimationsModule,
        HttpClientModule,
        MaterialModule,
        NoopAnimationsModule,
        NgrxFormsModule,
        ConsignmentPartiesModule,
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        }),
        StoreModule.forRoot(consPartiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsPartiesComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<ConsPartyFormValue>(
      'consParties',
      {
        section: [formEl, formEl]
      }
    );
    component.formState = INITIAL_STATE;
    component.isOnlyHouseConsignmentType = true;
    de = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should test isOnlyHouseConsignmentType', () => {
    expect(component.isOnlyHouseConsignmentType).toBeTruthy();
  });
  it('should handle child addCommunicationEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.addCommunicationEvent.emit(0);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.addCommunication).toHaveBeenCalled();
    });
  });
  it('should handle child removeCommunicationEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.removeCommunicationEvent.emit(0);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.removeCommunication).toHaveBeenCalled();
    });
  });
  it('should handle child addressTypeChangedEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.addressTypeChangedEvent.emit(AddressType.POBOX);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.onAddressTypeChanged).toHaveBeenCalled();
    });
  });
  it('should handle child postCodeChangedEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.postCodeChangedEvent.emit('');
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.onPostCodeChanged).toHaveBeenCalled();
    });
  });
  it('should handle child additionalStreetChangedEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.additionalStreetChangedEvent.emit();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.onAdditionalStreetChanged).toHaveBeenCalled();
    });
  });
  it('should handle child countryChangedEvent', () => {
    fixture.detectChanges();
    const childEl: PartySubDivisionComponent = de.query(
      By.directive(PartySubDivisionComponent)
    ).componentInstance;
    childEl.countryChangedEvent.emit('');
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.onCountryChanged).toHaveBeenCalled();
    });
  });

  it('should test addCommunication', () => {
    const spy = jest.spyOn(component.addCommunicationEvent, 'emit');
    component.addCommunication(2);
    expect(spy).toHaveBeenCalled();
  });

  it('should test removeCommunication', () => {
    const spy = jest.spyOn(component.removeCommunicationEvent, 'emit');
    component.removeCommunication(2, '');
    expect(spy).toHaveBeenCalled();
  });

  it('should test onAddressTypeChanged', () => {
    const spy = jest.spyOn(component.addressTypeChangedEvent, 'emit');
    component.onAddressTypeChanged(2, '');
    expect(spy).toHaveBeenCalled();
  });

  it('should test onAdditionalStreetChanged', () => {
    const spy = jest.spyOn(component.additionalStreetChangedEvent, 'emit');
    component.onAdditionalStreetChanged(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test onPostCodeChanged', () => {
    const spy = jest.spyOn(component.postCodeChangedEvent, 'emit');
    component.onPostCodeChanged(2, '');
    expect(spy).toHaveBeenCalled();
  });
  it('should test onCountryChanged', () => {
    const spy = jest.spyOn(component.countryChangedEvent, 'emit');
    component.onCountryChanged(2, '');
    expect(spy).toHaveBeenCalled();
  });
  it('should test showNotifyParty', () => {
    const spy = jest.spyOn(component.showNotiyPartyEvent, 'emit');
    component.showNotifyParty(true);
    expect(spy).toHaveBeenCalled();
  });
  it('should test deleteHouseConsignment', () => {
    const spy = jest.spyOn(component.deleteHouseConsignmentAction, 'emit');
    component.deleteHouseConsignment();
    expect(spy).toHaveBeenCalled();
  });
  it('should test validateCountryCodeSelection', () => {
    const spy = jest.spyOn(component.validateCountryCodeSelectionEvent, 'emit');
    component.validateCountryCodeSelection(true, 0);
    expect(spy).toHaveBeenCalled();
  });
});
