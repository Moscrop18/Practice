/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Address, AddressType } from '@features/edit-declaration/models';
import { ConsPartyFormValue } from '@features/edit-declaration/models/cons-parties/cons-par-form-value';
import { Declarant } from '@features/edit-declaration/models/parties/declarant';
import { validateAutoCompleteSelection } from '@features/edit-declaration/validation-functions/auto-complete-validation-functions';
import { validatePostCode } from '@features/edit-declaration/validation-functions/location-of-goods-function';
import { Action, combineReducers } from '@ngrx/store';
import { consignmentPartyFormDirtyAction } from '@shared/feature-store/common-store/actions/common.actions';
import { resetConsignmentPartyForm } from '@shared/feature-store/consignment/actions/cons-info.actions';
import {
  addArrayControl,
  createFormGroupState,
  formGroupReducer,
  FormGroupState,
  markAsPristine,
  markAsTouched,
  removeArrayControl,
  setValue,
  updateArray,
  updateArrayWithFilter,
  updateGroup,
  validate
} from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';

import { PartySubDiv } from '../../../models/cons-parties/party-sub-div';
import { Communication } from '../../../models/parties/communication';
import {
  addAddress,
  addCommunicationAction,
  addNotifyParty,
  dispatchConsPartyTouchAction,
  initializeState,
  removeAddress,
  removeCommunicationAction,
  removeNotifyParty,
  updateConsignmentPartiesForm,
  validatePartyCountryCodeSelection,
  validatePost
} from '../actions/cons-parties.actions';

export interface ConsPartyState {
  consParties: {
    formState: FormGroupState<ConsPartyFormValue>;
  };
}
export const FORM_ID = 'consParties';
const formEl: PartySubDiv = {
  typeOfPerson: '',
  address: {
    addressType: AddressType.STREET_AND_NUMBER,
    street: '',
    number: '',
    country: '',
    city: '',
    postCode: ''
  },
  declarant: {
    communication: [
      {
        type: '',
        identifier: ''
      }
    ],
    eoriIdentification: '',
    name: ''
  },
  subDivision: ''
};
export const INITIAL_FORM_STATE = createFormGroupState<ConsPartyFormValue>(
  FORM_ID,
  {
    section: [formEl, formEl]
  }
);

const validateAndUpdateForm = updateGroup<ConsPartyFormValue>({
  section: updateArray<PartySubDiv>(
    updateGroup<PartySubDiv>({
      typeOfPerson: validate(required),
      declarant: (declarationInfo) => {
        return updateGroup<Declarant>(declarationInfo, {
          name: validate(required),
          communication: updateArray(
            updateGroup<Communication>({
              type: validate(required),
              identifier: validate(required)
            })
          )
        });
      },
      address: (address) => {
        return updateGroup<Address>(address, {
          city: validate(required),
          street: validate(required),
          number: validate(required),
          poBox: validate(required)
        });
      }
    })
  )
});

export function consignmentPartiesFormStateReducer(
  s = INITIAL_FORM_STATE,
  a: any = {}
) {
  s = formGroupReducer(s, a);
  switch (a.type) {
    case dispatchConsPartyTouchAction.type:
      return markAsTouched(s);
    case resetConsignmentPartyForm.type:
      return INITIAL_FORM_STATE;
    case consignmentPartyFormDirtyAction.type:
      return markAsPristine(s);
    case initializeState.type:
      return updateGroup<ConsPartyFormValue>({})(INITIAL_FORM_STATE);
    case addCommunicationAction.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.payload,
            updateGroup<PartySubDiv>({
              declarant: (declarant) => {
                return updateGroup<Declarant>({
                  communication: (communication) => {
                    return addArrayControl(communication, {
                      type: '',
                      identifier: ''
                    });
                  }
                })(declarant);
              }
            })
          )(section);
        }
      })(s);
    case removeCommunicationAction.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.pIndex,
            updateGroup<PartySubDiv>({
              declarant: (declarant) => {
                return updateGroup<Declarant>({
                  communication: (communication) => {
                    return removeArrayControl(communication, a.payload);
                  }
                })(declarant);
              }
            })
          )(section);
        }
      })(s);
    case addAddress.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.index,
            updateGroup<PartySubDiv>({
              address: (group) => {
                let newValue = {};
                newValue = { ...group.value, [a.name]: '' };
                return setValue(group, newValue);
              }
            })
          )(section);
        }
      })(s);
    case removeAddress.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.index,
            updateGroup<PartySubDiv>({
              address: (group) => {
                const newValue = { ...group.value };
                delete newValue[a.name];
                return setValue(group, newValue);
              }
            })
          )(section);
        }
      })(s);
    case validatePost.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.index,
            updateGroup<PartySubDiv>({
              address: (address) => {
                return updateGroup<Address>({
                  postCode: validate(validatePostCode(a.name, address))
                })(address);
              }
            })
          )(section);
        }
      })(s);
    case addNotifyParty.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          if (section.controls[2])
            return addArrayControl(removeArrayControl(section, 2), formEl);
          return addArrayControl(section, formEl);
        }
      })(s);
    case removeNotifyParty.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return removeArrayControl(section, 2);
        }
      })(s);
    case updateConsignmentPartiesForm.type:
      return createFormGroupState<ConsPartyFormValue>(FORM_ID, a.data);

    case validatePartyCountryCodeSelection.type:
      return updateGroup<ConsPartyFormValue>({
        section: (section) => {
          return updateArrayWithFilter<PartySubDiv>(
            (subDiv, idx) => idx === a.index,
            updateGroup<PartySubDiv>({
              address: (address) => {
                return updateGroup<Address>({
                  country: validate([
                    required,
                    validateAutoCompleteSelection(
                      a.event.value,
                      a.event.codeList
                    )
                  ])
                })(address);
              }
            })
          )(section);
        }
      })(s);

    default:
      return s;
  }
}

const reducers = combineReducers<ConsPartyState['consParties'], any>({
  formState(s = INITIAL_FORM_STATE, a: any = {}) {
    return validateAndUpdateForm(consignmentPartiesFormStateReducer(s, a));
  }
});

export function consPartiesReducer(
  s: ConsPartyState['consParties'],
  a: Action
) {
  return reducers(s, a);
}
