import { ConsPartyFormValue } from '@features/edit-declaration/models/cons-parties/cons-par-form-value';
import { createAction, props } from '@ngrx/store';

export const addCommunicationAction = createAction(
  'masConsparties/ADD_COMMUNICATION_ACTION',
  props<{ payload: number }>()
);
export const removeCommunicationAction = createAction(
  'masConsparties/REMOVE_COMMUNICATION_ACTION',
  props<{ pIndex: number; payload: number }>()
);
export const addAddress = createAction(
  'masConsparties/ADD_ADDRESS_ACTION',
  props<{ index: number; name: string }>()
);
export const removeAddress = createAction(
  'masConsparties/REMOVE_ADDRESS_ACTION',
  props<{ index: number; name: string }>()
);
export const validatePost = createAction(
  'masConsparties/VALIDATE_POST_CODE_ACTION',
  props<{ index: number; name: string }>()
);
export const addNotifyParty = createAction(
  'masConsparties/ADD_NOTIFY_PARTY_ACTION'
);
export const removeNotifyParty = createAction(
  'masConsparties/REMOVE_NOTIFY_PARTY_ACTION'
);
export const initializeState = createAction(
  'masConsparties/INITIALIZE_STATE_ACTION'
);
export const dispatchConsPartyTouchAction = createAction(
  'masConsparties/FORM_TOUCH_ACTION'
);
export const updateConsignmentPartiesForm = createAction(
  'masConsparties/UPDATE_CONSIGNMENT_PARTIES_FORM',
  props<{ data: ConsPartyFormValue }>()
);
export const validatePartyCountryCodeSelection = createAction(
  'generalInformation/VALIDATE_Party_CountryCode_SELECTION',
  props<{ index: any; selectedValue: string; autoCompleteList: string[] }>()
);
