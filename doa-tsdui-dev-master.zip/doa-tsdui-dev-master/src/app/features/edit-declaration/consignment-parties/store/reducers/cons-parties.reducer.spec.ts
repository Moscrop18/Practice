import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { AddressType } from '@features/edit-declaration/models';
import { ConsPartyFormValue } from '@features/edit-declaration/models/cons-parties/cons-par-form-value';
import { PartySubDiv } from '@features/edit-declaration/models/cons-parties/party-sub-div';
import { createFormGroupState, FormGroupState } from 'ngrx-forms';

import {
  addCommunicationAction,
  addNotifyParty,
  removeNotifyParty,
  removeCommunicationAction,
  addAddress,
  removeAddress,
  validatePost,
  validatePartyCountryCodeSelection
} from '../actions/cons-parties.actions';

import * as fromReducer from './cons-parties.reducer';

export interface ConsPartyState {
  consParties: {
    formState: FormGroupState<ConsPartyFormValue>;
  };
}

describe('partiesReducer', () => {
  it('should return the default state', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = { type: '' };
    const state = fromReducer.consPartiesReducer(undefined, action);
    expect(state.formState.controls.section.id).toBe(
      INITIAL_FORM_STATE.controls.section.id
    );
  });

  it('should return the state with 2 communication control added', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = { type: addCommunicationAction.type, payload: 0 };

    const state = fromReducer.consPartiesReducer(
      { formState: INITIAL_FORM_STATE },
      action
    );

    expect(
      state.formState.controls.section.controls[0].controls.declarant.controls
        .communication.controls.length
    ).toBe(2);
  });
  it('should return the state with 0 communication control added', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = {
      type: removeCommunicationAction.type,
      pIndex: 0,
      payload: 0
    };

    const state = fromReducer.consPartiesReducer(
      { formState: INITIAL_FORM_STATE },
      action
    );

    expect(
      state.formState.controls.section.controls[0].controls.declarant.controls
        .communication.controls.length
    ).toBe(0);
  });
  it('should return the state with address controls added', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = { type: addAddress.type, index: 0, name: constants.STREET };
    const state = fromReducer.consPartiesReducer(
      { formState: INITIAL_FORM_STATE },
      action
    );
    expect(
      state.formState.controls.section.controls[0].controls.address.controls
        .street
    ).toBeDefined();
  });
  it('should test validatePartyCountryCodeSelection', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = {
      type: validatePartyCountryCodeSelection.type,
      index: 0,
      selectedValue: 'BE - Belgium',
      event: {
        value: ''
      },
      autoCompleteList: [
        {
          'id': 14,
          'value': 'BE',
          'definition': 'Belgium'
        },
        {
          'id': 15,
          'value': 'BF',
          'definition': 'Burkina Faso'
        }
      ]
    };
    const state = fromReducer.consPartiesReducer(
      { formState: INITIAL_FORM_STATE },
      action
    );
    expect(state.formState.controls.section.controls[0]).toBeDefined();
  });
  it('should return the state with Notify Party section removed', () => {
    const { INITIAL_FORM_STATE } = fromReducer;
    const action = {
      type: removeAddress.type,
      index: 0,
      name: constants.STREET
    };
    const state = fromReducer.consPartiesReducer(
      { formState: INITIAL_FORM_STATE },
      action
    );
    expect(
      state.formState.controls.section.controls[0].controls.address.controls
        .street
    ).toBeUndefined();
  });
  it('should execute validatePost', () => {
    const formEl: PartySubDiv = {
      typeOfPerson: '',
      address: {
        addressType: AddressType.STREET_AND_NUMBER,
        street: '',
        number: '',
        country: '',
        city: '',
        postCode: ''
      },
      declarant: {
        communication: [
          {
            type: '',
            identifier: ''
          }
        ],
        eoriIdentification: '',
        name: ''
      },
      subDivision: ''
    };
    const INIT_STATE = createFormGroupState<ConsPartyFormValue>(
      'CONS_PARTY_ID',
      {
        section: [formEl, formEl]
      }
    );
    const action = { type: validatePost.type, index: 0, name: 'B' };
    const state = fromReducer.consPartiesReducer(
      { formState: INIT_STATE },
      action
    );
    expect(
      state.formState.controls.section.controls[0].controls.address.controls
        .postCode.isInvalid
    ).toBeTruthy();
  });
  it('should execute addNotify', () => {
    const formEl: PartySubDiv = {
      typeOfPerson: '',
      address: {
        addressType: AddressType.STREET_AND_NUMBER,
        street: '',
        number: '',
        country: '',
        city: '',
        postCode: ''
      },
      declarant: {
        communication: [
          {
            type: '',
            identifier: ''
          }
        ],
        eoriIdentification: '',
        name: ''
      },
      subDivision: ''
    };
    const INIT_STATE = createFormGroupState<ConsPartyFormValue>(
      'CONS_PARTY_ID',
      {
        section: [formEl, formEl]
      }
    );
    const action = { type: addNotifyParty.type };
    const state = fromReducer.consPartiesReducer(
      { formState: INIT_STATE },
      action
    );
    expect(state.formState.controls.section.controls.length).toBe(3);
  });
  it('should execute removeNotifyParty', () => {
    const formEl: PartySubDiv = {
      typeOfPerson: '',
      address: {
        addressType: AddressType.STREET_AND_NUMBER,
        street: '',
        number: '',
        country: '',
        city: '',
        postCode: ''
      },
      declarant: {
        communication: [
          {
            type: '',
            identifier: ''
          }
        ],
        eoriIdentification: '',
        name: ''
      },
      subDivision: ''
    };
    const INIT_STATE = createFormGroupState<ConsPartyFormValue>(
      'CONS_PARTY_ID',
      {
        section: [formEl, formEl, formEl]
      }
    );
    const action = { type: removeNotifyParty.type };
    const state = fromReducer.consPartiesReducer(
      { formState: INIT_STATE },
      action
    );
    expect(state.formState.controls.section.controls.length).toBe(2);
  });
});
