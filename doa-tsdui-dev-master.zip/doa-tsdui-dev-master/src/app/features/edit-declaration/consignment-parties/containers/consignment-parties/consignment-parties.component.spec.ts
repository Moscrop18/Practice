/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Params } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import {
  ConsPartiesService,
  EditDeclarationFacade
} from '@features/edit-declaration/services';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { HouseConsOverview } from '@features/manage-declaration/models/house-overview/house-cons-overview';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { mapAddressStateToForm } from '@shared/utility/consignment-parties';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';

import { ConsignmentPartiesModule } from '../../consignment-parties.module';
import { consPartiesReducer } from '../../store/reducers/cons-parties.reducer';

import { ConsignmentPartiesComponent } from './consignment-parties.component';

describe('ConsignmentPartiesComponent', () => {
  cacheTestingModule();
  let component: ConsignmentPartiesComponent;
  let fixture: ComponentFixture<ConsignmentPartiesComponent>;
  let facade: EditDeclarationFacade;
  const translations: any = {
    'parties.errors.selectRequired': 'Please select a value'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        ConsignmentPartiesModule,
        SharedModule,
        EditDeclarationModule,
        NgrxFormsModule,
        RouterTestingModule,
        MaterialModule,
        StoreModule.forRoot(consPartiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        EffectsModule.forRoot([CodeListEffects, ConsInfoEffects]),
        HttpClientModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        }),
        NoopAnimationsModule
      ],
      providers: [
        EditDeclarationFacade,
        CodeListService,
        ConsPartiesService,
        ConfigService
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsignmentPartiesComponent);
    component = fixture.componentInstance;
    facade = TestBed.inject(EditDeclarationFacade);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call addCommunicationEvent', () => {
    const spy = jest.spyOn(facade, 'addCommunication');
    component.addCommunication(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should test handleDeclarationSubscription', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    expect(component.tsdType).toStrictEqual(genInfoMockData.type);
  }));
  it('should call deleteConsignment', () => {
    const spy = jest.spyOn(facade, 'dispatchDeleteConsignmentAction');
    component.deleteHouseConsignment(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call removeCommunicationEvent', () => {
    const spy = jest.spyOn(facade, 'removeCommunication');
    component.removeCommunication({ event: 0, parent: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call addressTypeChangedEvent', () => {
    const spy = jest.spyOn(facade, 'changeConsPartyAddressTypeValue');
    component.onAddressTypeChanged({ event: 0, index: 0 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call postCodeChangedEvent', () => {
    const spy = jest.spyOn(facade, 'validatePartyPostCode');
    component.onPostCodeChanged({ index: 0, event: '' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call additionalStreetChangedEvent', () => {
    const spy = jest.spyOn(facade, 'onAdditionalPartyStreetChanged');
    component.onAdditionalStreetChanged(0);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call countryChangedEvent', () => {
    const spy = jest.spyOn(facade, 'validatePartyPostCode');
    component.onCountryChange({ index: 0, event: '' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call showNotiyPartyEvent', () => {
    const spy = jest.spyOn(facade, 'showNotifyParty');
    component.showNotifyParty(true);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call showNotiyPartyEvent1', () => {
    const queryParams = {
      queryParams: {
        tsdId: '0',
        ensReuse: 'false',
        consignmentType: 'both',
        consignmentItemAddedTo: 'both'
      }
    };
    const spy = jest
      .spyOn(facade, 'currentRouteParams', 'get')
      .mockImplementation(() => of(queryParams));
    component.consignmentInfo$ = of({
      id: 1,
      type: 'Master',
      sequenceNumber: 0
    });
    component.consultGenInfodata$ = of({
      id: 1,
      type: 'Master',
      sequenceNumber: 0
    });

    const houseItem: HouseConsOverview = {
      sequenceNumber: 1
    };
    component.houseList$ = of({
      id: 1,
      page: 1,
      items: [houseItem],
      pageSize: 1,
      totalPages: 1,
      totalElements: 1
    });
    component.ngOnInit();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should test mapAddressStateToForm', () => {
    const updatedPackaging = mapAddressStateToForm({}, [], 'ss');
    expect(updatedPackaging).toBeDefined();
  });

  const genInfoData: ConsultGeneralInformation = {
    id: 2313413,
    self: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
    lrn: 'REF123456789000000000',
    mrn: '20BETP000000C3FLU4',
    crn: 'CRN21BETS00000000QIU0',
    current: true,
    ensReuseIndicator: 0,
    expirationTimestamp: '2021-04-01T16:50:42.999Z',
    type: 'Combined',
    status: 'PreLodged',
    consignmentType: 'House',
    consignmentItemType: 'House',
    linkedPnFrn: '20BEPN000000C3FLU8',
    registrationDate: '2021-04-01T15:49:42.999Z',
    declarationDate: '2021-04-28T15:50:42.999Z',
    dateAndTimeOfPresentationOfTheGoods: '2022-04-28T15:50:42.999Z',
    version: 2,
    draftErrors: 'All',
    supervisingCustomsOffice: {
      referenceNumber: 'BE212000'
    },
    personPresentingTheGoods: {
      identificationNumber: 'string',
      name: 'string',
      address: {
        streetAndNumber: 'River Road 12',
        country: 'BE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info2@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        }
      ]
    },
    declarant: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      address: {
        streetAndNumber: 'River Road 1234',
        country: 'AD',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        },
        {
          identifier: 'info1@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        },
        {
          identifier: '003222012345',
          type: 'TE',
          fullName: 'Telephone contact name'
        }
      ]
    },
    representative: {
      identificationNumber: 'BE0214596464',
      name: 'REF1234567name1',
      status: 'Direct',
      address: {
        streetAndNumber: 'River Road 123',
        country: 'AE',
        postCode: '1000',
        city: 'Brussel',
        poBox: '1234'
      },
      communication: [
        {
          identifier: 'info@bpost.be',
          type: 'EM',
          fullName: 'Email contact name'
        }
      ]
    },
    consignmentHeader: {
      declaredLocationOfGoods: {
        typeOfLocation: 'D',
        qualifierOfIdentification: 'Y',
        unLoCode: 'BEZAVA00710',
        authorisationNumber: 'Ref1234',
        additionalIdentifier: 'Ref12345',
        gnss: {
          longitude: '50.85045',
          latitude: '4.34878'
        },
        economicOperator: {
          identificationNumber: 'XX0214596464'
        },
        address: {
          streetAndNumber: 'River Road 123',
          country: 'BE',
          postCode: '1000',
          city: 'Brussel',
          poBox: '1234'
        }
      },
      arrivalTransportMeans: {
        identificationNumber: 'IMO1924100',
        typeOfIdentification: '10'
      },
      warehouse: {
        identifier: 'REF123456789',
        type: 'V'
      },
      placeOfUnloading: {
        unLoCode: 'BEZAVA00710'
      },
      presentedLocationOfGoods: {
        typeOfLocation: 'string',
        qualifierOfIdentification: 'string',
        unLoCode: 'string',
        authorisationNumber: 'string',
        additionalIdentifier: 'string',
        customsOffice: {
          referenceNumber: 'string'
        },
        gnss: {
          longitude: 50.85045,
          latitude: 4.34878
        },
        economicOperator: {
          identificationNumber: 'string'
        },
        address: {
          postCode: 'string',
          city: 'string',
          streetAndNumber: 'string',
          country: 'string'
        }
      },
      carrier: {
        identificationNumber: 'string',
        name: 'string'
      }
    },
    amendmentRequest: {
      registrationDate: '2019-08-24T14:15:22Z',
      status: 'Accepted'
    },
    _links: {
      amend:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend',
      draftAmendment:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
      invalidate:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/invalidate',
      consignments:
        'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments'
    }
  };
  it('should test isOnlyHouseConsignmentType to be true', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoData));
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.isOnlyHouseConsignmentType).toBeTruthy();
  }));
  it('should test isOnlyHouseConsignmentType to be false', fakeAsync(() => {
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.consignmentInfo$ = facade.fetchConsInfo();
    component.handleDeclarationSubscription();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.isOnlyHouseConsignmentType).toBeFalsy();
  }));
});
