/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { CountryCode } from '@core/gateways/codelist/model/country-code';
import { CodeListState } from '@core/gateways/codelist/store/reducer/code-list.reducer';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { ConsignmentInformation } from '@features/manage-declaration/models/consignment-information/cons-info-state';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { HouseList } from '@features/manage-declaration/models/house-overview/house-list';
import { FormGroupState } from 'ngrx-forms';
import { Observable, Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import { TypeOfPersonCode } from '../../../../../core/gateways/codelist/model/type-of-person-code';
import { ConsPartyFormValue } from '../../../models/cons-parties/cons-par-form-value';

@Component({
  selector: 'app-consignment-parties',
  templateUrl: './consignment-parties.component.html'
})
export class ConsignmentPartiesComponent implements OnInit, OnDestroy {
  formState$: Observable<FormGroupState<ConsPartyFormValue>>;
  consultGenInfodata$: Observable<ConsultGeneralInformation>;
  countryCodes$: Observable<CountryCode[]>;
  houseList$: Observable<HouseList>;
  typeOfPersonCode$: Observable<TypeOfPersonCode[]>;
  communicationTypeCodes$: Observable<CommunicationTypeCodeList[]>;
  isEnsReuse: boolean;
  tsdType: string;
  consignmentType: string;
  sequence = 0;
  tsdId: number;
  consignmentInfo$: Observable<ConsignmentInformation>;
  public consignmentSubscription: Subscription;
  public routeSubscription: Subscription;
  public declarationSubscription: Subscription;
  public isOnlyHouseConsignmentType: boolean;
  codeLists$: Observable<CodeListState>;
  constructor(private editDeclarationFacade: EditDeclarationFacade) {
    this.codeLists$ = this.editDeclarationFacade.getCodeLists();
    this.editDeclarationFacade.initializeConsPartyState();
    this.formState$ = this.editDeclarationFacade.getMasConsPartiesFormState();
    this.typeOfPersonCode$ = this.editDeclarationFacade.getTypeOfPersonCodes();
    this.communicationTypeCodes$ = this.editDeclarationFacade.getCommunicationTypeCodeList();
    this.countryCodes$ = this.editDeclarationFacade.getCountryCodes();
    this.consultGenInfodata$ = this.editDeclarationFacade.fetchGeneralInformationData();
    this.houseList$ = this.editDeclarationFacade.fetchHouseListData();
    this.consignmentInfo$ = this.editDeclarationFacade.fetchConsInfo();
    this.handleDeclarationSubscription();
  }
  addCommunication(index: number) {
    this.editDeclarationFacade.addCommunication(index);
  }
  removeCommunication(event: any) {
    this.editDeclarationFacade.removeCommunication(event.parent, event.event);
  }
  onAddressTypeChanged(event: any) {
    this.editDeclarationFacade.changeConsPartyAddressTypeValue(
      event.index,
      event.event
    );
  }
  onCountryChange(event: any) {
    const country: string = event.event;
    this.editDeclarationFacade
      .getPostCodeDataLevel(country.substring(0, 2))
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.validatePartyPostCode(event.index, data);
      });
  }
  onPostCodeChanged(event: any) {
    this.editDeclarationFacade
      .getPostCodeDataLevel(event.event)
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.validatePartyPostCode(event.index, data);
      });
  }
  onAdditionalStreetChanged(event: number) {
    this.editDeclarationFacade.onAdditionalPartyStreetChanged(event);
  }
  showNotifyParty(event: boolean) {
    this.editDeclarationFacade.showNotifyParty(event);
  }
  ngOnInit(): void {
    this.routeSubscription = this.editDeclarationFacade.currentRouteParams.subscribe(
      (route) => {
        this.tsdId = parseInt(route.queryParams.tsdId);
        this.sequence = parseInt(route.queryParams.consNo);
        this.consignmentType =
          this.sequence === 0 ? constants.MASTER : constants.HOUSE;
      }
    );
  }
  handleDeclarationSubscription(): void {
    this.declarationSubscription = this.consultGenInfodata$.subscribe(
      (data) => {
        if (data) {
          this.tsdType = data.type;
          this.isOnlyHouseConsignmentType = data?.consignmentType?.includes(
            'Master'
          )
            ? false
            : true;
          this.isEnsReuse = data.ensReuseIndicator.toString() === '1';
        }
      }
    );
  }
  ngOnDestroy(): void {
    this.routeSubscription?.unsubscribe();
    this.declarationSubscription?.unsubscribe();
  }
  deleteHouseConsignment(seq: number): void {
    this.editDeclarationFacade.dispatchDeleteConsignmentAction(
      {
        tsdId: this.tsdId
      },
      seq
    );
  }
  validateCountryCodeSelection(event: any) {
    this.editDeclarationFacade.validatePartyCountryCodeSelection(event);
  }
}
