import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { EditDeclarationSharedModule } from '@features/edit-declaration/edit-declaration-shared/edit-declaration-shared.module';
import { MaterialModule } from '@material/index';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from '@shared/shared.module';
import { NgrxFormsModule } from 'ngrx-forms';

import { ConsignmentPartiesComponent } from './containers/consignment-parties/consignment-parties.component';
import { ConsPartiesComponent } from './presentation/cons-parties/cons-parties.component';
import { PartySubDivisionComponent } from './presentation/cons-parties/party-sub-division/party-sub-division.component';
import { consPartiesReducer } from './store/reducers/cons-parties.reducer';
@NgModule({
  declarations: [
    ConsignmentPartiesComponent,
    ConsPartiesComponent,
    PartySubDivisionComponent
  ],
  imports: [
    CommonModule,
    EditDeclarationSharedModule,
    SharedModule,
    NgrxFormsModule,
    MaterialModule,
    FlexLayoutModule,
    StoreModule.forFeature('consParties', consPartiesReducer)
  ],
  exports: [
    ConsignmentPartiesComponent,
    ConsPartiesComponent,
    PartySubDivisionComponent
  ]
})
export class ConsignmentPartiesModule {}
