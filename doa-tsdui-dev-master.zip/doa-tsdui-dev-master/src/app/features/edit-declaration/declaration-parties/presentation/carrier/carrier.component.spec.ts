/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { Carrier } from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormGroupState,
  formStateReducer,
  MarkAsTouchedAction,
  NgrxFormsModule,
  SetErrorsAction
} from 'ngrx-forms';
import { of } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';

import { DeclarantEffects } from '../../store/effects/declarant.effects';
import { partiesReducer } from '../../store/reducers/parties.reducer';

import { CarrierComponent } from './carrier.component';

describe('CarrierComponent', () => {
  let component: CarrierComponent;
  let fixture: ComponentFixture<CarrierComponent>;

  const translations: any = {
    'party.eori': 'Eori Number',
    'party.maximum17Character': 'Maximum 17 characters'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgrxFormsModule,
        MaterialModule,
        SharedModule,
        NoopAnimationsModule,
        HttpClientModule,
        EffectsModule.forRoot([DeclarantEffects]),
        SharedModule,
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: FakeLoader }
        }),
        StoreModule.forRoot(partiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ],
      declarations: [CarrierComponent]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CarrierComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<Carrier>('carrier', {
      name: '',
      eoriNumber: ''
    });
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should check the value of name field', async () => {
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<Carrier>(
      'personPresentingTheGoods',
      {
        name: 'party',
        eoriNumber: 'BE0214596464'
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
    expect(component).toBeTruthy();
    await fixture.whenStable();
    const el = fixture.nativeElement.querySelector('.eoriName');
    expect(el.value).toContain('party');
  });

  it('Should check the validity of EORI number field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls.eoriNumber.id, {
        errors: {
          errorType: 'requiredWithLength'
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(updatedGroupViaAction.controls.eoriNumber.id)
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('Should check the validity of name field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls.name.id, {
        required: {
          actual: ''
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(updatedGroupViaAction.controls.eoriNumber.id)
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('should test carrierEoriChange', () => {
    const spy = jest.spyOn(component.carrierEoriChangeEvent, 'emit');
    component.carrierEoriChange('');
    expect(spy).toHaveBeenCalled();
  });
});
