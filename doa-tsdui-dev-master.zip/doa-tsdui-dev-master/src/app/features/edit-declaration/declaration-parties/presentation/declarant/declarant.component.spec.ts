import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { EditDeclarationSharedModule } from '@features/edit-declaration/edit-declaration-shared/edit-declaration-shared.module';
import { Declarant } from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { DeclarantEffects } from '../../store/effects/declarant.effects';
import { partiesReducer } from '../../store/reducers/parties.reducer';

import { DeclarantComponent } from './declarant.component';

describe('DeclarantComponent', () => {
  let component: DeclarantComponent;
  let fixture: ComponentFixture<DeclarantComponent>;

  const translations: unknown = {
    'party.eori': 'Eori Number',
    'party.maximum17Character': 'Maximum 17 characters',
    'party.error.invalidEoriNumber': 'Invalid EoriNumber'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(): Observable<unknown> {
      return of(translations);
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgrxFormsModule,
        MaterialModule,
        SharedModule,
        NoopAnimationsModule,
        HttpClientModule,
        RouterTestingModule,
        EffectsModule.forRoot([DeclarantEffects]),
        SharedModule,
        EditDeclarationSharedModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: FakeLoader }
        }),
        StoreModule.forRoot(partiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ],
      declarations: [DeclarantComponent]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeclarantComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<Declarant>('declarant', {
      communication: [
        {
          type: '',
          identifier: ''
        }
      ],
      name: '',
      eoriIdentification: ''
    });
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Should check onEoriChanged', () => {
    const spy = jest.spyOn(component.eoriChangedEvent, 'emit');
    component.onEoriChanged('123');
    expect(spy).toHaveBeenCalled();
  });
  it('Should check addCommunication', () => {
    const spy = jest.spyOn(component.addCommunicationEvent, 'emit');
    component.addCommunication();
    expect(spy).toHaveBeenCalled();
  });
  it('Should check removeCommunication', () => {
    const spy = jest.spyOn(component.removeCommunicationEvent, 'emit');
    component.removeCommunication(1);
    expect(spy).toHaveBeenCalled();
  });
  it('Should check trackByFn', () => {
    expect(component.trackByFn(1)).toBe(1);
  });
});
