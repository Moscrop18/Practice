import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PipesModule } from '@core/pipes/pipes.module';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { PartiesService } from '@features/edit-declaration/services/parties.service';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { PartiesForm } from '../../../models/parties/parties-form';
import { RepresentativeEffects } from '../../store/effects/representative.effects';
import { partiesReducer } from '../../store/reducers/parties.reducer';
import { CarrierComponent } from '../carrier/carrier.component';
import { DeclarantComponent } from '../declarant/declarant.component';
import { PersonPresentiongTheGoodsComponent } from '../person-presentiong-the-goods/person-presentiong-the-goods.component';
import { RepresentativeComponent } from '../representative/representative.component';

import { EditDeclarationSharedModule } from './../../../edit-declaration-shared/edit-declaration-shared.module';
import { PartyComponent } from './party.component';

describe('PartyComponent', () => {
  let component: PartyComponent;
  let fixture: ComponentFixture<PartyComponent>;

  const translations: any = {
    'party.eori': 'Eori Number',
    'party.maximum17Character': 'Maximum 17 characters'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgrxFormsModule,
        PipesModule,
        MaterialModule,
        NoopAnimationsModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        EditDeclarationSharedModule,
        HttpClientModule,
        EffectsModule.forRoot([RepresentativeEffects]),
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: FakeLoader }
        }),
        StoreModule.forRoot(partiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ],
      declarations: [
        PartyComponent,
        PersonPresentiongTheGoodsComponent,
        RepresentativeComponent,
        CarrierComponent,
        DeclarantComponent
      ],
      providers: [EditDeclarationFacade, PartiesService]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PartyComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<PartiesForm>('parties', {
      declarant: {
        communication: [
          {
            type: '',
            identifier: ''
          }
        ],
        eoriIdentification: '',
        name: ''
      },
      representative: {},
      personPresentingTheGoods: {},
      carrier: {}
    });
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test removeCommunication', () => {
    const spy = jest.spyOn(component.removeCommunicationEvent, 'emit');
    component.removeCommunication(2);
    expect(spy).toHaveBeenCalled();
  });
  it('should test showRepresentative', () => {
    const spy = jest.spyOn(component.showRepresentativeEvent, 'emit');
    component.showRepresentative(true);
    expect(spy).toHaveBeenCalled();
  });
  it('should test representativeEoriChanged', () => {
    const spy = jest.spyOn(component.representativeEoriChangedEvent, 'emit');
    component.representativeEoriChanged('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test personPresentingGoodsEoriChange', () => {
    const spy = jest.spyOn(
      component.personPresentingGoodsEoriChangeEvent,
      'emit'
    );
    component.personPresentingGoodsEoriChange('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test carrierEoriChange', () => {
    const spy = jest.spyOn(component.carrierEoriChangeEvent, 'emit');
    component.carrierEoriChange('');
    expect(spy).toHaveBeenCalled();
  });
  it('should test addCommunication', () => {
    const spy = jest.spyOn(component.addCommunicationEvent, 'emit');
    component.addCommunication();
    expect(spy).toHaveBeenCalled();
  });
  it('should test onEoriChanged', () => {
    const spy = jest.spyOn(component.eoriChangedEvent, 'emit');
    component.onEoriChanged('');
    expect(spy).toHaveBeenCalled();
  });
});
