/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { PersonPresentingTheGoods } from '@features/edit-declaration/models';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import {
  createFormGroupState,
  formStateReducer,
  MarkAsTouchedAction,
  NgrxFormsModule,
  SetErrorsAction
} from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { RepresentativeEffects } from '../../store/effects/representative.effects';
import { partiesReducer } from '../../store/reducers/parties.reducer';

import { PersonPresentiongTheGoodsComponent } from './person-presentiong-the-goods.component';

describe('PersonPresentiongTheGoodsComponent', () => {
  let component: PersonPresentiongTheGoodsComponent;
  let fixture: ComponentFixture<PersonPresentiongTheGoodsComponent>;

  const translations: any = {
    'party.eori': 'Eori Number',
    'party.maximum17Character': 'Maximum 17 characters'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        NgrxFormsModule,
        MaterialModule,
        NoopAnimationsModule,
        HttpClientModule,
        EffectsModule.forRoot([RepresentativeEffects]),
        SharedModule,
        MaterialModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: FakeLoader }
        }),
        StoreModule.forRoot(partiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ],
      declarations: [PersonPresentiongTheGoodsComponent]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonPresentiongTheGoodsComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<PersonPresentingTheGoods>(
      'personPresentingTheGoods',
      {
        name: '',
        eoriNumber: ''
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should check the value of name field', async () => {
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<PersonPresentingTheGoods>(
      'personPresentingTheGoods',
      {
        name: 'party',
        eoriNumber: 'BE0214596464'
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
    expect(component).toBeTruthy();
    await fixture.whenStable();
    const el = fixture.nativeElement.querySelector('.eoriName');
    expect(el.value).toContain('party');
  });

  it('Should check the validity of EORI number field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls.eoriNumber.id, {
        errors: {
          errorType: 'requiredWithLength'
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(updatedGroupViaAction.controls.eoriNumber.id)
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('Should check the validity of name field', () => {
    const updatedGroupViaAction = formStateReducer(
      component.formState,
      new SetErrorsAction(component.formState.controls.name.id, {
        required: {
          actual: ''
        }
      })
    );
    const touchedGroupViaAction = formStateReducer(
      updatedGroupViaAction,
      new MarkAsTouchedAction(updatedGroupViaAction.controls.eoriNumber.id)
    );
    component.formState = touchedGroupViaAction;
    fixture.detectChanges();
    expect(updatedGroupViaAction.isValid).toBeFalsy();
  });

  it('should call personPresentingGoodsEoriChange', () => {
    const spy = jest.spyOn(
      component.personPresentingGoodsEoriChangeEvent,
      'emit'
    );
    component.personPresentingGoodsEoriChange('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
});
