import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroupState } from 'ngrx-forms';

import { PersonPresentingTheGoods } from '../../../models/parties/personPresentingTheGoods';

@Component({
  selector: 'app-person-presentiong-the-goods',
  templateUrl: './person-presentiong-the-goods.component.html'
})
export class PersonPresentiongTheGoodsComponent {
  @Input() formState: FormGroupState<PersonPresentingTheGoods>;
  @Output() personPresentingGoodsEoriChangeEvent = new EventEmitter<string>();

  constructor() {
    //empty
  }

  personPresentingGoodsEoriChange(event: string): void {
    this.personPresentingGoodsEoriChangeEvent.emit(event);
  }
}
