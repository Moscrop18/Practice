import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { RepresentativeStatusCodeList } from '@core/gateways/codelist/model/representative-status';
import { PartiesForm } from '@features/edit-declaration/models';
import { FormGroupState } from 'ngrx-forms';

@Component({
  selector: 'app-party',
  templateUrl: './party.component.html'
})
export class PartyComponent {
  @Input() formState: FormGroupState<PartiesForm>;
  @Output() eoriChangedEvent = new EventEmitter();
  @Output() addCommunicationEvent = new EventEmitter();
  @Input() tsdType: string;
  @Input() communicationLength: number;
  @Input() communicationTypeCodeList: CommunicationTypeCodeList[];
  @Input() representativeStatusCodeList: RepresentativeStatusCodeList[];
  @Output() removeCommunicationEvent = new EventEmitter<number>();
  @Output() showRepresentativeEvent = new EventEmitter<boolean>();
  @Output() representativeEoriChangedEvent = new EventEmitter();
  @Output() personPresentingGoodsEoriChangeEvent = new EventEmitter();
  @Output() carrierEoriChangeEvent = new EventEmitter();
  constructor() {
    //empty
  }

  onEoriChanged(event: string): void {
    this.eoriChangedEvent.emit(event);
  }

  addCommunication(event: string): void {
    this.addCommunicationEvent.emit(event);
  }

  removeCommunication(event: number): void {
    this.removeCommunicationEvent.emit(event);
  }

  showRepresentative(event: boolean): void {
    this.showRepresentativeEvent.emit(event);
  }
  representativeEoriChanged(event: string): void {
    this.representativeEoriChangedEvent.emit(event);
  }
  personPresentingGoodsEoriChange(event: string): void {
    this.personPresentingGoodsEoriChangeEvent.emit(event);
  }
  carrierEoriChange(event: string): void {
    this.carrierEoriChangeEvent.emit(event);
  }
}
