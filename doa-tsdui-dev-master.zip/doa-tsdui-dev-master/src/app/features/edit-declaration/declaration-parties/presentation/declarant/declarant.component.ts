import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { Declarant } from '@features/edit-declaration/models';
import { FormGroupState } from 'ngrx-forms';

@Component({
  selector: 'app-declarant',
  templateUrl: './declarant.component.html'
})
export class DeclarantComponent {
  @Input() formState: FormGroupState<Declarant>;
  @Input() tsdType: string;
  @Input() communicationLength: number;
  @Output() eoriChangedEvent = new EventEmitter<string>();
  @Output() addCommunicationEvent = new EventEmitter<string>();
  @Output() removeCommunicationEvent = new EventEmitter<number>();
  @Input() communicationTypeCodeList: CommunicationTypeCodeList[];
  constructor() {
    //empty
  }

  onEoriChanged(event: string): void {
    this.eoriChangedEvent.emit(event);
  }
  addCommunication(event: string): void {
    this.addCommunicationEvent.emit(event);
  }
  removeCommunication(event: number): void {
    this.removeCommunicationEvent.emit(event);
  }
  trackByFn(index: number): number {
    return index;
  }
}
