import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Carrier } from '@features/edit-declaration/models';
import { FormGroupState } from 'ngrx-forms';

@Component({
  selector: 'app-carrier',
  templateUrl: './carrier.component.html'
})
export class CarrierComponent {
  @Input() formState: FormGroupState<Carrier>;
  @Input() tsdType: string;
  @Output() carrierEoriChangeEvent = new EventEmitter<string>();

  constructor() {
    // empty
  }

  carrierEoriChange(event: string): void {
    this.carrierEoriChangeEvent.emit(event);
  }
}
