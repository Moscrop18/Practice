/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable sonarjs/no-identical-functions */
/* eslint-disable sonarjs/no-duplicate-string */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick
} from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { EditDeclarationSharedModule } from '@features/edit-declaration/edit-declaration-shared/edit-declaration-shared.module';
import { DraftErrors } from '@features/edit-declaration/edit-declaration.constants';
import { EditDeclarationModule } from '@features/edit-declaration/edit-declaration.module';
import { TSDStatus } from '@features/edit-declaration/models/enums/tsd-status';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { ConsInfoEffects } from '@shared/feature-store/consignment/effects/cons-info.effects';
import { SharedModule } from '@shared/shared.module';
import { cacheTestingModule } from 'ng-cache-testing-module';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';

import { PartiesService } from '../../services/parties.service';
import { PartyModule } from '../party.module';
import { CarrierEffects } from '../store/effects/carrier.effects';
import { DeclarantEffects } from '../store/effects/declarant.effects';
import { PersonPresentingGoodsEffects } from '../store/effects/personPresentingGoods-info.effects';
import { RepresentativeEffects } from '../store/effects/representative.effects';
import {
  INITIAL_PARTIES_FORM_STATE,
  partiesReducer
} from '../store/reducers/parties.reducer';

import { PartyComponent } from './../presentation/party/party.component';
import { EditDeclarationPartiesComponent } from './edit-declaration-parties.component';

describe('EditDeclarationPartiesComponent', () => {
  cacheTestingModule();
  let component: EditDeclarationPartiesComponent;
  let fixture: ComponentFixture<EditDeclarationPartiesComponent>;
  let debugElement: DebugElement;
  let facade: EditDeclarationFacade;

  const translations: any = {
    'party.eori': 'Eori Number',
    'party.maximum17Character': 'Maximum 17 characters'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(): Observable<any> {
      return of({ translations });
    }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [],
      imports: [
        CommonModule,
        SharedModule,
        PartyModule,
        NgrxFormsModule,
        RouterTestingModule,
        EditDeclarationModule,
        EditDeclarationSharedModule,
        MaterialModule,
        NgrxFormsModule,
        HttpClientModule,
        EffectsModule.forRoot([
          CodeListEffects,
          CarrierEffects,
          PersonPresentingGoodsEffects,
          RepresentativeEffects,
          DeclarantEffects,
          ConsInfoEffects
        ]),
        NoopAnimationsModule,
        StoreModule.forRoot(partiesReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        })
      ],
      providers: [
        EditDeclarationFacade,
        CodeListService,
        PartiesService,
        ConfigService
      ]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditDeclarationPartiesComponent);
    facade = TestBed.inject(EditDeclarationFacade);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    jest
      .spyOn(facade.partiesService, 'getPartiesFormState')
      .mockImplementation(() => of(INITIAL_PARTIES_FORM_STATE));
    jest
      .spyOn(facade.codeListService, 'dispatchFetchEoriListAction')
      .mockImplementation(() =>
        of({
          partyList: [
            {
              id: 'BE0214596464',
              name: 'LA POSTE DIR GEN FIN C.SUC L1050',
              communication: [
                {
                  id: 'BE0214596464',
                  fullName: 'Email contact name',
                  identifier: 'info@bpost.be',
                  type: 'E-mail address'
                },
                {
                  id: 'BE0214596464',
                  fullName: 'Telephone contact name',
                  identifier: '003222012345',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0436501681',
              name: 'INTERNATIONAL POST CORPORATION',
              communication: [
                {
                  id: 'BE0436501681',
                  fullName: 'Email contact name',
                  identifier: 'info@ipc.be',
                  type: 'E-mail address'
                }
              ]
            },
            {
              id: 'BE0427599358',
              name: 'DHL AVIATION',
              communication: [
                {
                  id: 'BE0427599358',
                  fullName: 'Telephone contact name',
                  identifier: '003227216517',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0458858302',
              name: 'TNT EXPRESS WORLDWIDE (EURO HUB)',
              communication: [
                {
                  id: 'BE0458858302',
                  fullName: 'Telephone contact name',
                  identifier: '003227216517',
                  type: 'Phone number'
                },
                {
                  id: 'BE0458858302',
                  fullName: 'Email contact name',
                  identifier: 'infotntliege@tnt.com',
                  type: 'E-mail address'
                }
              ]
            },
            {
              id: 'BE0812191490',
              name: 'FEDEX TRADE NETWORKS TRANSPORT',
              communication: [
                {
                  id: 'BE0812191490',
                  fullName: 'Telephone contact name',
                  identifier: '003222521005',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0404529392',
              name: 'AVIAPARTNER BELGIUM',
              communication: [
                {
                  id: 'BE0404529392',
                  fullName: 'Telephone contact name',
                  identifier: '003227230311',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0404531966',
              name: 'KUEHNE + NAGEL',
              communication: [
                {
                  id: 'BE0404531966',
                  fullName: 'Telephone contact name',
                  identifier: '003227230311',
                  type: 'Phone number'
                },
                {
                  id: 'BE0404531966',
                  fullName: 'Email contact name',
                  identifier: 'info.antwerpen@kuehne-nagel.com',
                  type: 'E-mail address'
                }
              ]
            },
            {
              id: 'BE0218843678',
              name: 'HAVENBEDRIJF GENT',
              communication: [
                {
                  id: 'BE0218843678',
                  fullName: 'Telephone contact name',
                  identifier: '003292510550',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0404754472',
              name: 'B A S F ANTWERPEN',
              communication: [
                {
                  id: 'BE0404754472',
                  fullName: 'Telephone contact name',
                  identifier: '003235612111',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0424188423',
              name: 'NIPPON EXPRESS (BELGIUM)',
              communication: [
                {
                  id: 'BE0424188423',
                  fullName: 'Telephone contact name',
                  identifier: '003227530202',
                  type: 'Phone number'
                }
              ]
            },
            {
              id: 'BE0446536134',
              name: 'ALL FREIGHT LOGISTICS',
              communication: [
                {
                  id: 'BE0446536134',
                  fullName: 'Telephone contact name',
                  identifier: '003227529520',
                  type: 'Phone number'
                }
              ]
            },
            {
              name: 'KATOEN NATIE',
              communication: [
                {
                  id: 'BE0404778426',
                  fullName: 'Telephone contact name',
                  identifier: '003232216811',
                  type: 'Phone number'
                }
              ]
            },
            {
              name: 'MSC HOME TERMINAL NV',
              communication: [
                {
                  id: 'BE0861301897',
                  fullName: 'Telephone contact name',
                  identifier: '003235604248',
                  type: 'Phone number'
                }
              ]
            }
          ]
        })
      );
    jest.spyOn(facade.partiesService, 'validateEORI').mockImplementation(() =>
      of({
        validEORINumbers: [
          'BE0214596464',
          'BE0436501681',
          'BE0427599358',
          'BE0458858302',
          'BE0812191490',
          'BE0404529392',
          'BE0404531966',
          'BE0218843678',
          'BE0404754472',
          'BE0424188423',
          'BE0446536134',
          'BE0404778426',
          'BE0861301897'
        ]
      })
    );
    jest
      .spyOn(facade.partiesService, 'validatePersonPresentingGoodsEori')
      .mockImplementation(() =>
        of({
          validEORINumbers: [
            'BE0214596464',
            'BE0436501681',
            'BE0427599358',
            'BE0458858302',
            'BE0812191490',
            'BE0404529392',
            'BE0404531966',
            'BE0218843678',
            'BE0404754472',
            'BE0424188423',
            'BE0446536134',
            'BE0404778426',
            'BE0861301897'
          ]
        })
      );
    jest
      .spyOn(facade.partiesService, 'validateCarrierEori')
      .mockImplementation(() =>
        of({
          validEORINumbers: [
            'BE0214596464',
            'BE0436501681',
            'BE0427599358',
            'BE0458858302',
            'BE0812191490',
            'BE0404529392',
            'BE0404531966',
            'BE0218843678',
            'BE0404754472',
            'BE0424188423',
            'BE0446536134',
            'BE0404778426',
            'BE0861301897'
          ]
        })
      );
    jest.spyOn(facade.codeListService, 'getParty').mockImplementation(() =>
      of({
        id: 'BE0214596464',
        name: 'LA POSTE DIR GEN FIN C.SUC L1050',
        communication: [
          {
            id: 'BE0214596464',
            fullName: 'Email contact name',
            identifier: 'info@bpost.be',
            type: 'E-mail address'
          },
          {
            id: 'BE0214596464',
            fullName: 'Telephone contact name',
            identifier: '003222012345',
            type: 'Phone number'
          }
        ]
      })
    );
    jest.spyOn(console, 'error').mockImplementation(() => {});
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should ngOnInit', fakeAsync(() => {
    fixture.detectChanges();
    component.consultGenInfodata$ = facade.fetchGeneralInformationData();
    component.ngOnInit();
    tick();
    fixture.detectChanges();
    tick();
    expect(component.tsdType.toLowerCase()).toStrictEqual(
      genInfoMockData.type.toLowerCase()
    );
    expect(component.communicationLength).toStrictEqual(
      genInfoMockData.declarant.communication.length
    );
  }));
  it('should handle child addCommunicationEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.addCommunicationEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.addCommunication).toHaveBeenCalled();
    });
  });

  it('should handle child carrierEoriChangeEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.carrierEoriChangeEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.carrierEoriChange).toHaveBeenCalled();
    });
  });

  it('should handle child eoriChangedEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.eoriChangedEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.onEoriChange).toHaveBeenCalled();
    });
  });

  it('should handle child removeCommunicationEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.removeCommunicationEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.removeCommunication).toHaveBeenCalled();
    });
  });

  it('should handle child personPresentingGoodsEoriChangeEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.personPresentingGoodsEoriChangeEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.personPresentingGoodsEoriChange).toHaveBeenCalled();
    });
  });

  it('should handle child showRepresentativeEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.showRepresentativeEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.showRepresentative).toHaveBeenCalled();
    });
  });

  it('should handle child showRepresentativeEvent', () => {
    fixture.detectChanges();
    const childEl: PartyComponent = debugElement.query(
      By.directive(PartyComponent)
    ).componentInstance;
    childEl.representativeEoriChangedEvent.emit();
    fixture.detectChanges();
    void fixture.whenStable().then(() => {
      expect(component.representativeEoriChange).toHaveBeenCalled();
    });
  });
});
