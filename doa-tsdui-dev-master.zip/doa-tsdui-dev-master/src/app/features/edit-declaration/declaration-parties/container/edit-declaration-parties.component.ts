/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { RepresentativeStatusCodeList } from '@core/gateways/codelist/model/representative-status';
import { PartiesForm } from '@features/edit-declaration/models';
import { EditDeclarationFacade } from '@features/edit-declaration/services';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { FormGroupState } from 'ngrx-forms';
import { Observable, Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-edit-declaration-parties',
  templateUrl: './edit-declaration-parties.component.html'
})
export class EditDeclarationPartiesComponent implements OnInit, OnDestroy {
  formState$: Observable<FormGroupState<PartiesForm>>;
  consultGenInfodata$: Observable<ConsultGeneralInformation>;
  communicationLength: number;
  tsdType: string;
  ensReuse: boolean;
  communicationTypeCodes$: Observable<CommunicationTypeCodeList[]>;
  representativeStatusCodes$: Observable<RepresentativeStatusCodeList[]>;
  declarationSubscription: Subscription;
  constructor(private editDeclarationFacade: EditDeclarationFacade) {
    this.editDeclarationFacade.codeListService.dispatchFetchEoriListAction();
    this.formState$ = this.editDeclarationFacade.partiesService.getPartiesFormState();
    this.consultGenInfodata$ = this.editDeclarationFacade.fetchGeneralInformationData();
    this.communicationTypeCodes$ = this.editDeclarationFacade.getCommunicationTypeCodeList();
    this.representativeStatusCodes$ = this.editDeclarationFacade.getRepresentativeStatusCodeList();
    this.editDeclarationFacade.partiesService.disableDeclarantAndRepresentative();
  }
  ngOnDestroy(): void {
    this.declarationSubscription?.unsubscribe();
  }

  ngOnInit(): void {
    this.declarationSubscription = this.consultGenInfodata$.subscribe(
      (data) => {
        if (data) {
          this.tsdType = data.type.toLowerCase();
          this.communicationLength = data?.declarant?.communication?.length;
        }
      }
    );
  }
  onEoriChange(event: string): void {
    this.editDeclarationFacade.partiesService.validateEORI(event);
    this.editDeclarationFacade.codeListService
      .getParty(event)
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.partiesService.updateNameAndCommunication(
          data
        );
        this.communicationLength = data?.communication.length;
        this.editDeclarationFacade.partiesService.disableNameAndCommunication();
      });
  }
  addCommunication(event: string): void {
    this.editDeclarationFacade.codeListService
      .getParty(event)
      .pipe(take(1))
      .subscribe((data) => {
        if (data) {
          this.communicationLength = data.communication.length;
        }
      });
    this.editDeclarationFacade.partiesService.addCommunication();
  }
  removeCommunication(event: number): void {
    this.editDeclarationFacade.partiesService.removeCommunication(event);
  }
  showRepresentative(event: boolean): void {
    this.editDeclarationFacade.partiesService.showRepresentative(event);
    this.editDeclarationFacade.partiesService.disableDeclarantAndRepresentative();
    this.editDeclarationFacade.initValidationAction();
  }
  representativeEoriChange(event: string): void {
    this.editDeclarationFacade.partiesService.validateRepresentativeEori(event);
    this.editDeclarationFacade.codeListService
      .getParty(event)
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.partiesService.updateRepresentative(data);
        if (data) {
          this.editDeclarationFacade.partiesService.disableRepsNameAndCommAction();
        }
      });
  }
  personPresentingGoodsEoriChange(event: string): void {
    this.editDeclarationFacade.partiesService.validatePersonPresentingGoodsEori(
      event
    );
    this.editDeclarationFacade.codeListService
      .getParty(event)
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.partiesService.updatePersonPresentingGoods(
          data
        );
      });
  }
  carrierEoriChange(event: string): void {
    this.editDeclarationFacade.partiesService.validateCarrierEori(event);
    this.editDeclarationFacade.codeListService
      .getParty(event)
      .pipe(take(1))
      .subscribe((data) => {
        this.editDeclarationFacade.partiesService.updateCarrier(data);
      });
  }
}
