import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PipesModule } from '@core/pipes/pipes.module';
import { EditDeclarationSharedModule } from '@features/edit-declaration/edit-declaration-shared/edit-declaration-shared.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { NgrxFormsModule } from 'ngrx-forms';

import { MaterialModule } from '../../../material/material.module';
import { SharedModule } from '../../../shared/shared.module';
import { EditDeclarationFacade } from '../services';
import { PartiesService } from '../services/parties.service';

import { EditDeclarationPartiesComponent } from './container/edit-declaration-parties.component';
import { CarrierComponent } from './presentation/carrier/carrier.component';
import { DeclarantComponent } from './presentation/declarant/declarant.component';
import { PartyComponent } from './presentation/party/party.component';
import { PersonPresentiongTheGoodsComponent } from './presentation/person-presentiong-the-goods/person-presentiong-the-goods.component';
import { RepresentativeComponent } from './presentation/representative/representative.component';
import { CarrierEffects } from './store/effects/carrier.effects';
import { DeclarantEffects } from './store/effects/declarant.effects';
import { PersonPresentingGoodsEffects } from './store/effects/personPresentingGoods-info.effects';
import { RepresentativeEffects } from './store/effects/representative.effects';
import { partiesReducer } from './store/reducers/parties.reducer';

@NgModule({
  declarations: [
    EditDeclarationPartiesComponent,
    CarrierComponent,
    DeclarantComponent,
    PersonPresentiongTheGoodsComponent,
    RepresentativeComponent,
    PartyComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    EditDeclarationSharedModule,
    NgrxFormsModule,
    MaterialModule,
    FlexLayoutModule,
    PipesModule,
    StoreModule.forFeature('parties', partiesReducer),
    EffectsModule.forFeature([
      DeclarantEffects,
      RepresentativeEffects,
      CarrierEffects,
      PersonPresentingGoodsEffects
    ])
  ],
  exports: [
    PartyComponent,
    CarrierComponent,
    DeclarantComponent,
    PersonPresentiongTheGoodsComponent,
    RepresentativeComponent
  ],
  providers: [EditDeclarationFacade, PartiesService]
})
export class PartyModule {
  constructor() {
    //empty
  }
}
