import { AdvSearchResultItem } from './search-result-item';

export interface AdvSearchResult {
  id?: number;
  items: AdvSearchResultItem[];
  pageSize: number;
  _links: {
    prev?: string;
    next?: string;
  };
}
