export interface SearchWarehouseIdentifier {
  identifier: string;
}
