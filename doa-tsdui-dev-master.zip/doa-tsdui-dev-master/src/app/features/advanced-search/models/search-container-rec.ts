export interface SearchContainerOrRecep {
  identifictionNo?: string;
}
