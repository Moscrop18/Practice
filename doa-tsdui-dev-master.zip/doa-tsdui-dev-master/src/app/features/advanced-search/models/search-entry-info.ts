export interface SearchEntryInformation {
  arrivalTransMeansIdn?: string;
}
