export interface SearchLocationOfGoods {
  unLoCode?: string;
}
