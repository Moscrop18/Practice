export interface SearchDeclarationInformation {
  lrn?: string;
  registrationDateBefore: string;
  registrationDateAfter: string;
  presentationDateBefore: string;
  presentationDateAfter: string;
}
