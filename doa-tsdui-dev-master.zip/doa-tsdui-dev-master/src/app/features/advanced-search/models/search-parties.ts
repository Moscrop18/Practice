export interface SearchParties {
  eori?: string;
  name?: string;
  declarant?: boolean;
  representative?: boolean;
  carrier?: boolean;
  personPresGoods?: boolean;
}
