import { SearchAddCustomsOffice } from './search-add-cus-office';
import { SearchContainerOrRecep } from './search-container-rec';
import { SearchDeclarationInformation } from './search-dec-info';
import { SearchDeclarationStatus } from './search-dec-status';
import { SearchEntryInformation } from './search-entry-info';
import { SearchLocationOfGoods } from './search-location-goods';
import { SearchParties } from './search-parties';
import { SearchRacStatus } from './search-rac-status';
import { SearchTransportDocument } from './search-trans-doc';
import { SearchWarehouseIdentifier } from './search-warehouse-identifier';

export interface AdvancedSearchParamForm {
  declarationInfo: SearchDeclarationInformation;
  addCusOffice?: SearchAddCustomsOffice;
  entryInformation?: SearchEntryInformation;
  parties?: SearchParties;
  transportDocument?: SearchTransportDocument;
  containerOrRecep?: SearchContainerOrRecep;
  declarationStatus?: SearchDeclarationStatus;
  racStatus?: SearchRacStatus;
  locationOfGoods?: SearchLocationOfGoods;
  warehouseIdentifier?: SearchWarehouseIdentifier;
}
