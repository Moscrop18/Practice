export interface AdvSearchResultItem {
  href: string;
  id: number;
  mrn: string;
  crn: string;
  lrn: string;
  modificationDate: string;
  type: string;
  status: string;
  registrationDate: string;
  declarant: {
    identificationNumber: string;
    name: string;
  };
  representative: {
    identificationNumber: string;
    name: string;
  };
  linkedPN: string;
  category: string;
  _links: {
    amend?: string;
    draftAmendment?: string;
    invalidate?: string;
  };
}
