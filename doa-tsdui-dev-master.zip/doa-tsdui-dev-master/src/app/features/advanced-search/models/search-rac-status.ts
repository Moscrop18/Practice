export interface SearchRacStatus {
  [x: string]: any;
  searchValue: {
    UnderControl?: boolean;
    AwaitingRiskAnalysisResult?: boolean;
    AwaitingRiskHitConfirmation?: boolean;
    ControlResultRegistered?: boolean;
    PreArrivalRiskAnalysisCompleted?: boolean;
    PreArrivalRiskAnalysisCancelled?: boolean;
    NoRisk?: boolean;
  };
}
