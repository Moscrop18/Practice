export interface SearchDeclarationStatus {
  [x: string]: any;
  searchValue: {
    PreLodged?: boolean;
    Accepted?: boolean;
    IrregularityUnderInvestigation?: boolean;
    Invalidated?: boolean;
    UnderControl?: boolean;
  };
}
