export interface SearchTransportDocument {
  refNum?: string;
}
