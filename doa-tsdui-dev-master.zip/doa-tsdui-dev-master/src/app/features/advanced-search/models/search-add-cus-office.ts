export interface SearchAddCustomsOffice {
  cusOffice?: string;
  supervCusOffice?: boolean;
  cusOffOfPres?: boolean;
}
