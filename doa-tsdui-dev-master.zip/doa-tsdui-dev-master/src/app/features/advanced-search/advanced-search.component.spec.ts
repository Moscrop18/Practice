/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';

import { AdvancedSearchComponent } from './advanced-search.component';
import { SearchAddCustomsOfficeComponent } from './search-param/components/search-add-customs-office/search-add-customs-office.component';
import { SearchContainerOrRecComponent } from './search-param/components/search-container-or-rec/search-container-or-rec.component';
import { SearchDeclarationInfoComponent } from './search-param/components/search-declaration-info/search-declaration-info.component';
import { SearchDeclarationStatusComponent } from './search-param/components/search-declaration-status/search-declaration-status.component';
import { SearchEntryInformationComponent } from './search-param/components/search-entry-information/search-entry-information.component';
import { SearchLocationOfGoodsComponent } from './search-param/components/search-location-of-goods/search-location-of-goods.component';
import { SearchPartiesComponent } from './search-param/components/search-parties/search-parties.component';
import { SearchRacStatusComponent } from './search-param/components/search-rac-status/search-rac-status.component';
import { SearchTransportDocComponent } from './search-param/components/search-transport-doc/search-transport-doc.component';
import { SearchWarehouseIdentifierComponent } from './search-param/components/search-warehouse-identifier/search-warehouse-identifier.component';
import { SearchParamComponent } from './search-param/search-param.component';
import { AdvanceSearchParamService } from './services/adv-search-param.service';
import { AdvanceSearchRequestBuilderService } from './services/adv-search-request-builder.service';
import { AdvSearchParamEffects } from './store/effects/adv-search-param.effects';
import { advSearchParamReducer } from './store/reducers/adv-search-param.reducer';

describe('AdvSearchComponent', () => {
  let component: AdvancedSearchComponent;
  let fixture: ComponentFixture<AdvancedSearchComponent>;
  let facade: AdvanceSearchParamService;
  const translations: any = {
    'generalInfoForm.errors.requiredWithLength':
      'Please enter a valid LRN, consisting of maximum 22 characters.'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        AdvancedSearchComponent,
        SearchParamComponent,
        SearchDeclarationInfoComponent,
        SearchAddCustomsOfficeComponent,
        SearchEntryInformationComponent,
        SearchPartiesComponent,
        SearchTransportDocComponent,
        SearchContainerOrRecComponent,
        SearchDeclarationStatusComponent,
        SearchRacStatusComponent,
        SearchLocationOfGoodsComponent,
        SearchWarehouseIdentifierComponent
      ],
      imports: [
        CommonModule,
        SharedModule,
        NgrxFormsModule,
        RouterTestingModule,
        MaterialModule,
        StoreModule.forRoot(advSearchParamReducer, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        }),
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        HttpClientModule,
        EffectsModule.forRoot([CodeListEffects, AdvSearchParamEffects]),
        NoopAnimationsModule,
        TranslateModule.forRoot({
          loader: { provide: TranslateLoader, useClass: MockLoader }
        })
      ],
      providers: [
        AdvanceSearchRequestBuilderService,
        AdvanceSearchParamService,
        CodeListService,
        ModuleLoadService,
        ConfigService
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdvancedSearchComponent);
    component = fixture.componentInstance;
    facade = TestBed.inject(AdvanceSearchParamService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call eori change', () => {
    const spy = jest.spyOn(facade, 'getDeclarantForEori');
    component.eoriChange({ event: { event: { eori: '' } } });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should call clear form', () => {
    const spy = jest.spyOn(facade, 'clearForm');
    component.clearAllForm();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
});
