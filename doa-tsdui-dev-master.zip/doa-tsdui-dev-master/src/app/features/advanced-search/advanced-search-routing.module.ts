import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@core/guards/auth.guard';

import { AdvancedSearchComponent } from './advanced-search.component';
import { SearchListComponent } from './search-list/container/search-list.component';
import { SearchResultsComponent } from './search-results/search-results.component';
const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: AdvancedSearchComponent
      },
      {
        path: 'search-results',
        data: {
          breadcrumb: 'breadcrumb.searchResults',
          path: 'advanced-search/search-results',
          isClickable: true,
          pathMatch: 'full'
        },
        component: SearchResultsComponent,
        children: [
          {
            path: '',
            component: SearchListComponent
          },
          {
            path: ':id',
            canActivate: [AuthGuard],
            loadChildren: () =>
              import(
                '@features/manage-declaration/manage-declaration.module'
              ).then((m) => m.ManageDeclarationModule)
          },
          {
            path: ':id/amendment',
            canActivate: [AuthGuard],
            loadChildren: () =>
              import('@features/edit-declaration/edit-declaration.module').then(
                (m) => m.EditDeclarationModule
              )
          }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdvancedSearchRoutingModule {}
