import { Params } from '@angular/router';
import { AdvSearchResult } from '@features/advanced-search/models';
import { createAction, props } from '@ngrx/store';

export const LoadAdvSearchResult = createAction(
  '[AdvSearch] Load AdvSearch',
  props<{
    payload: any;
    initial: boolean;
    url: string;
    param?: string;
    queryParam?: Params;
  }>()
);

export const LoadAdvSearchResultSuccess = createAction(
  '[AdvSearch] Load AdvSearch Success',
  props<{ payload: AdvSearchResult }>()
);

export const Navigate = createAction(
  '[AdvSearch] Navigate To Consult Screen',
  props<{ url: string; param?: string; queryParam?: Params }>()
);
