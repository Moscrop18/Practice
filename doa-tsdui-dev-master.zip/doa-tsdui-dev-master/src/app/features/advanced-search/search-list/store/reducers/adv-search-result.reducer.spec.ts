/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import * as reducer from '@features/advanced-search/search-list/store/reducers/adv-search-result.reducer';

import {
  LoadAdvSearchResult,
  LoadAdvSearchResultSuccess
} from '../actions/adv-search-result.actions';

describe('advSearchResultReducer', () => {
  it('should push search result', () => {
    const { searchResultInitialState } = reducer;
    const LoadAdvSearchResultSuccessAction = {
      type: LoadAdvSearchResultSuccess.type,
      payload: {
        id: 0,
        items: [
          {
            href: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1',
            id: 1,
            mrn: '20BETP000000C3FLU41',
            crn: 'CRN21BETS00000000QIU01',
            lrn: '1234343QS3982KE1',
            modificationDate: '2019-01-24T14:15:22Z',
            type: 'PreLodged',
            status: 'Invalidated',
            registrationDate: '2019-01-24T14:15:22Z',
            declarant: {
              identificationNumber: 'BE04045222221',
              name: 'ACME Corp1'
            },
            representative: {
              identificationNumber: 'BE04045363221',
              name: 'Looney Tunes Inc1.'
            },
            linkedPN: '20BEPN000000C3FLU81',
            category: 'Amendment',
            _links: {
              amend:
                'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/amend',
              invalidate:
                'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/invalidate'
            }
          }
        ],
        pageSize: 20,
        _links: {
          prev: '',
          next: ''
        }
      }
    };
    const state = reducer.advSearcResultReducer(
      searchResultInitialState,
      LoadAdvSearchResultSuccessAction
    );
    expect(state.searchResultState['entities'][0]['items'][0].mrn).toEqual(
      '20BETP000000C3FLU41'
    );
  });
  it('should push search result 2', () => {
    const { searchResultInitialState } = reducer;
    const LoadAdvSearchResultAction = {
      type: LoadAdvSearchResult.type,
      initial: true
    };
    const state = reducer.advSearcResultReducer(
      searchResultInitialState,
      LoadAdvSearchResultAction
    );
    expect(state).toBeDefined();
  });

  it('should push search result 3', () => {
    const { searchResultInitialState } = reducer;
    const LoadAdvSearchResultAction = {};
    const state = reducer.advSearcResultReducer(
      searchResultInitialState,
      LoadAdvSearchResultAction
    );
    expect(state).toBeDefined();
  });
});
