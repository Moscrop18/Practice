/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-misused-promises */
/* eslint-disable @typescript-eslint/restrict-template-expressions */

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfigService } from '@core/services/config/config.service';
import { AdvSearchResult } from '@features/advanced-search/models';
import * as actions from '@features/advanced-search/search-list/store/actions/adv-search-result.actions';
import { AdvanceSearchRequestBuilderService } from '@features/advanced-search/services/adv-search-request-builder.service';
import { TsdService } from '@features/edit-declaration/services/tsd.service';
import { ConsultTSD } from '@features/manage-declaration/manage-declaration.constants';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';

@Injectable()
export class AdvSearchResultEffects {
  private apiUrl: string;
  errorHandler = catchError((error) => {
    if (
      error.status &&
      (error.status === 400 ||
        error.status === 404 ||
        error.status === 0 ||
        error.status >= 500)
    )
      this.tsdService.routeToUrl(ConsultTSD.PAGE_NOT_FOUND);
    else console.error(error);
    return of();
  });
  searchTSDResultData = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.LoadAdvSearchResult),
      switchMap((loadAction) => {
        return this.httpService
          .get(
            `${this.apiUrl}/temporaryStorageDeclarations?${loadAction.payload}`
          )
          .pipe(
            map((data: AdvSearchResult) => {
              data.id = 0; // this line crashed the pagination to the next/prev page in some cases?
              //updating the route
              this.router.navigate([loadAction.url + loadAction.param], {
                queryParams: loadAction.queryParam,
                relativeTo: this.activatedRoute
              });
              return actions.LoadAdvSearchResultSuccess({
                payload: data
              });
            }),
            this.errorHandler
          );
      })
    )
  );

  navigate$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(actions.Navigate),
        tap((action) =>
          this.router.navigate([action.url + action.param], {
            queryParams: action.queryParam,
            relativeTo: this.activatedRoute
          })
        )
      ),
    { dispatch: false }
  );

  constructor(
    private actions$: Actions,
    public httpService: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private tsdService: TsdService,
    private advanceSearchParamService: AdvanceSearchRequestBuilderService,
    private configService: ConfigService
  ) {
    this.apiUrl = String(configService.getConfig().apiUrl);
  }
}
