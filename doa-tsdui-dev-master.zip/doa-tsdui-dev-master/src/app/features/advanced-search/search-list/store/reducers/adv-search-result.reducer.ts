/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */

import { AdvSearchResult } from '@features/advanced-search/models';
import { createEntityAdapter, EntityState } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';

import {
  LoadAdvSearchResult,
  LoadAdvSearchResultSuccess
} from '../actions/adv-search-result.actions';

export type SearchResultState = EntityState<AdvSearchResult>;
export interface AdvsearchResultState {
  searchResultState: SearchResultState;
}
const searchResultAdapter = createEntityAdapter<AdvSearchResult>();

export const searchResultInitialState: AdvsearchResultState = {
  searchResultState: searchResultAdapter.getInitialState()
};

export function advSearcResultReducer(
  state: AdvsearchResultState = searchResultInitialState,
  action: any = {}
) {
  if (action.type === LoadAdvSearchResultSuccess.type) {
    return {
      ...state,
      searchResultState: searchResultAdapter.upsertOne(
        action.payload,
        state.searchResultState
      )
    };
  } else if (action.type === LoadAdvSearchResult.type && action.initial) {
    return {
      ...state,
      searchResultState: searchResultAdapter.getInitialState()
    };
  } else {
    return state;
  }
}

export const getAdvSearchResultFeature = createFeatureSelector<AdvsearchResultState>(
  'advSearchResult'
);
export const getAdvSearchResultData = createSelector(
  getAdvSearchResultFeature,
  (state) => {
    return state.searchResultState.entities[0];
  }
);
