/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient, HttpHandler, HttpResponse } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '@core/services/config/config.service';
import { LoadAdvSearchResult } from '@features/advanced-search/search-list/store/actions/adv-search-result.actions';
import { AdvanceSearchRequestBuilderService } from '@features/advanced-search/services/adv-search-request-builder.service';
import { TsdService } from '@features/edit-declaration/services/tsd.service';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import { of, ReplaySubject } from 'rxjs';

import { AdvSearchResultEffects } from './adv-search-result.effects';

describe('AdvSearchResultEffect', () => {
  let actions: ReplaySubject<any>;
  let effects: AdvSearchResultEffects;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AdvSearchResultEffects,
        TsdService,
        ConfigService,
        AdvanceSearchRequestBuilderService,
        provideMockActions(() => actions),
        HttpClient,
        {
          provide: Store,
          useValue: {
            dispatch: jest.fn(),
            pipe: jest.fn()
          }
        },
        HttpHandler
      ]
    });

    effects = TestBed.get(AdvSearchResultEffects);
    httpClient = TestBed.inject(HttpClient);
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });

  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });

  it('should fetch search result', () => {
    jest.spyOn(effects.httpService, 'get').mockImplementation(() =>
      of(
        new HttpResponse({
          status: 200,
          body: {}
        })
      )
    );
    actions = new ReplaySubject(1);
    const LoadAdvSearchResultAction = {
      type: LoadAdvSearchResult.type,
      payload: {}
    };
    actions.next(LoadAdvSearchResultAction);
    effects.searchTSDResultData.subscribe((data) => {
      expect(data).toBeDefined();
    });
  });
});
