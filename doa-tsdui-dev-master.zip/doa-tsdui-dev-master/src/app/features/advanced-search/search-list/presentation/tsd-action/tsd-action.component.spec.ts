import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { AdvancedSearchModule } from '@features/advanced-search/advanced-search.module';
import { TsdActionComponent } from '@features/advanced-search/search-list/presentation/tsd-action/tsd-action.component';
import { AdvSearchResultEffects } from '@features/advanced-search/search-list/store/effects/adv-search-result.effects';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';

describe('TsdActionComponent', () => {
  let component: TsdActionComponent;
  let fixture: ComponentFixture<TsdActionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [],
      imports: [
        MaterialModule,
        NoopAnimationsModule,
        AdvancedSearchModule,
        RouterTestingModule,
        HttpClientModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        EffectsModule.forRoot([AdvSearchResultEffects]),
        TranslateModule.forRoot()
      ],
      providers: [ConfigService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TsdActionComponent);
    component = fixture.componentInstance;
    component.status = 'Accepted';
    component.links = {};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
