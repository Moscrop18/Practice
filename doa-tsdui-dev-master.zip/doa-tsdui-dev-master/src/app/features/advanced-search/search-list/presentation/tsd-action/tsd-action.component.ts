import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-tsd-action',
  templateUrl: './tsd-action.component.html'
})
export class TsdActionComponent {
  @Input() status: string;
  @Output() tsdAction = new EventEmitter<string>();
  @Input() links: any;
  clickMenu(action: string): void {
    this.tsdAction.emit(action);
  }
}
