/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/restrict-plus-operands */

import {
  AfterViewInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { ConfigService } from '@core/services/config/config.service';
import { UnsubscribeOnDestroyComponent } from '@core/utils/unsubscribe-on-destroy';
import {
  AdvSearchResult,
  AdvSearchResultItem
} from '@features/advanced-search/models';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-tsd-list',
  templateUrl: './tsd-list.component.html',
  styleUrls: ['./tsd-list.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [
    {
      provide: MAT_FORM_FIELD_DEFAULT_OPTIONS,
      useValue: { appearance: 'outline' }
    }
  ]
})
export class TsdListComponent
  extends UnsubscribeOnDestroyComponent
  implements AfterViewInit {
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @Input() tsdList$: Observable<AdvSearchResult>;
  @Input() locale: string;
  @Input() pnUrl: string;
  @Output() refineSearchAction = new EventEmitter();
  @Output() changePageEvent = new EventEmitter<{
    backendURL: string;
  }>();
  @Output() changePageSize = new EventEmitter<{
    pageSize: string;
  }>();

  @Output() tsdAction = new EventEmitter<{
    action: string;
    mrn: string;
    draftAmendment: string;
  }>();
  public isLoading = true; //initial page load
  public isUpdating = true; // update due to sorting / pagination
  @Output() sortDraft = new EventEmitter<{ sort: string; pageSize: number }>();
  public dataSource: MatTableDataSource<AdvSearchResultItem> = new MatTableDataSource(
    []
  );
  currentPageSize = 10;
  displayedColumns: string[] = [
    'chk',
    'mrn',
    'registrationDate',
    'declarant',
    'representative',
    'status',
    'linkedPN',
    'actions'
  ];
  public resultsLength = undefined;
  public hidePaginator = false;
  public pageIndex = 0;
  public pageSize = 10;
  private data: AdvSearchResult;
  public showTableOverlays;
  lastDirection: string;
  constructor(
    public dialog: MatDialog,
    private ref: ChangeDetectorRef,
    private configService: ConfigService
  ) {
    super();
    this.showTableOverlays = this.configService.getConfig().showTableOverlays;
  }

  ngAfterViewInit(): void {
    this.subs.sink = this.tsdList$.subscribe((data) => {
      if (!data) {
        this.dataSource.data = new Array(10);
        return;
      }
      this.dataSource.data = data.items;
      this.dataSource.paginator = this.paginator;
      this.data = data;

      this.pageIndex = data._links.prev ? 1 : 0;
      this.resultsLength =
        this.pageSize * (this.pageIndex + 1) + (data._links.next ? 1 : 0);
      this.hidePaginator =
        (!data?._links?.prev && !data?._links?.next) ||
        data?.items?.length == 0;
      this.isLoading = false;
      setTimeout(() => {
        this.isUpdating = false; // update with small delay
        this.ref.detectChanges();
      }, 200);
    });
  }

  refineSearch(): void {
    this.refineSearchAction.emit();
  }

  changePage(event): void {
    this.isUpdating = true;
    if (event.previousPageIndex < event.pageIndex)
      this.changePageEvent.emit({
        backendURL: this.data._links.next
      });
    else if (event.previousPageIndex > event.pageIndex)
      this.changePageEvent.emit({
        backendURL: this.data._links.prev
      });
    else {
      this.currentPageSize = event.pageSize;
      this.changePageSize.emit({ pageSize: event.pageSize });
    }
  }

  onSort(e, column): void {
    this.isUpdating = true;
    if (!this.lastDirection) {
      this.lastDirection = e.direction;
    } else {
      this.lastDirection = this.lastDirection === 'asc' ? 'desc' : 'asc';
    }
    if (this.lastDirection === 'asc')
      this.sortDraft.emit({ sort: column, pageSize: this.currentPageSize });
    else if (this.lastDirection === 'desc')
      this.sortDraft.emit({
        sort: '-' + column,
        pageSize: this.currentPageSize
      });
  }

  handleTsdAction(action: string, mrn: string, draftAmendment: string): void {
    this.tsdAction.emit({ action, mrn, draftAmendment });
  }

  onRowClicked(element) {
    this.tsdAction.emit({
      action: 'view',
      mrn: element.mrn ? element.mrn : element.crn,
      draftAmendment: element?._links?.draftAmendment
    });
  }
}
