import { HttpClientModule } from '@angular/common/http';
import {
  ComponentFixture,
  fakeAsync,
  flush,
  TestBed,
  tick
} from '@angular/core/testing';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { AdvancedSearchModule } from '@features/advanced-search/advanced-search.module';
import { AdvSearchFacade } from '@features/advanced-search/services/adv-search-facade.service';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { CustomPaginator } from '@material/mat-table-config';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';
import { advsearchResult } from 'src/assets/mocks/adv-search-result.mock';

import { AdvSearchResultEffects } from '../../store/effects/adv-search-result.effects';

import { TsdListComponent } from './tsd-list.component';

describe('TsdListComponent', () => {
  let component: TsdListComponent;
  let fixture: ComponentFixture<TsdListComponent>;
  let facade: AdvSearchFacade;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [],
      imports: [
        MaterialModule,
        NoopAnimationsModule,
        AdvancedSearchModule,
        RouterTestingModule,
        HttpClientModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        EffectsModule.forRoot([AdvSearchResultEffects]),
        TranslateModule.forRoot()
      ],
      providers: [
        ConfigService,
        {
          provide: MatPaginatorIntl
        },
        {
          provide: CustomPaginator
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TsdListComponent);
    component = fixture.componentInstance;
    component.tsdList$ = of({ items: [], pageSize: 20, _links: {} });
    facade = TestBed.inject(AdvSearchFacade);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check ngAfterViewInit method', () => {
    component.dataSource.data = advsearchResult.items;
    component.ngAfterViewInit();
    fixture.detectChanges();
    expect(component.pageIndex).toEqual(0);
  });

  it('should be called refineSearchAction() for refineSearch', () => {
    const spy = jest.spyOn(component.refineSearchAction, 'emit');
    component.refineSearch();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call handleTsdAction', () => {
    const spy = jest.spyOn(component.tsdAction, 'emit');
    component.handleTsdAction('', '', '');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onRowClicked', () => {
    const spy = jest.spyOn(component.tsdAction, 'emit');
    component.onRowClicked('');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onSort', () => {
    const spy = jest.spyOn(component.sortDraft, 'emit');
    component.onSort({ direction: 'asc' }, {});
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onSort', () => {
    component.lastDirection = 'desc';
    const spy = jest.spyOn(component.sortDraft, 'emit');
    component.onSort({ direction: 'asc' }, {});
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onSort with desc', () => {
    component.lastDirection = 'asc';
    const spy = jest.spyOn(component.sortDraft, 'emit');
    component.onSort({ direction: 'desc' }, {});
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call changePage', () => {
    const spy = jest.spyOn(component.changePageEvent, 'emit');
    component.changePage({ previousPageIndex: 1, pageIndex: 2, pagesize: 10 });
    component.changePage({ previousPageIndex: 2, pageIndex: 2, pagesize: 10 });
    component.changePage({ previousPageIndex: 1, pageIndex: 1, pagesize: 10 });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should call onSort with desc', () => {
    const spy = jest.spyOn(component.sortDraft, 'emit');
    component.onSort({ direction: 'desc' }, {});
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
});
