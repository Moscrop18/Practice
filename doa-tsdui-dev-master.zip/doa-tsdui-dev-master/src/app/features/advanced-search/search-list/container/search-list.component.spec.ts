/* eslint-disable sonarjs/no-duplicate-string */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginatorIntl } from '@angular/material/paginator';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { AdvancedSearchModule } from '@features/advanced-search/advanced-search.module';
import { SearchListComponent } from '@features/advanced-search/search-list/container/search-list.component';
import { AdvSearchResultEffects } from '@features/advanced-search/search-list/store/effects/adv-search-result.effects';
import { AdvSearchFacade } from '@features/advanced-search/services/adv-search-facade.service';
import { AdvanceSearchParamService } from '@features/advanced-search/services/adv-search-param.service';
import { CustomPaginator } from '@material/mat-table-config';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

describe('SearchListComponent', () => {
  let component: SearchListComponent;
  let fixture: ComponentFixture<SearchListComponent>;
  let advSearchService: AdvanceSearchParamService;
  let advSearchFacade: AdvSearchFacade;
  let dialog: MatDialog;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [],
      imports: [
        MaterialModule,
        NoopAnimationsModule,
        AdvancedSearchModule,
        RouterTestingModule,
        HttpClientModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        EffectsModule.forRoot([AdvSearchResultEffects]),
        TranslateModule.forRoot()
      ],
      providers: [
        ConfigService,
        AdvanceSearchParamService,
        {
          provide: MatPaginatorIntl
        },
        {
          provide: CustomPaginator
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchListComponent);
    advSearchService = TestBed.inject(AdvanceSearchParamService);
    advSearchFacade = TestBed.inject(AdvSearchFacade);
    dialog = TestBed.inject(MatDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should test ngOnInit', () => {
    const routeMock = {
      url: 'http://localhost:4200/12345Mrn'
    };
    jest
      .spyOn(advSearchFacade, 'currentRouteParams', 'get')
      .mockImplementation(() => of(routeMock));
    component.handleRouteSubscription();
    expect(component.currUrl).toBe('http://localhost:4200/12345Mrn');
  });
  it('should be called refinesearch()', () => {
    component.currUrl = 'search-results?registrationDateAfter=6/16/2021';
    const spy = jest.spyOn(advSearchService, 'navigateToSearchParam');
    component.refineSearch();
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should be called sortDraft()', () => {
    const spy = jest.spyOn(advSearchService, 'getAdvSearch');
    component.currUrl = 'search-results?registrationDateAfter=6/16/2021';
    component.sortDraft({ sort: 'registrationDate' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });

  it('should be called handleTsdAction()', () => {
    const spy = jest.spyOn(advSearchService, 'navigateToConsultScreen');
    component.handleTsdAction({ action: 'view' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should be called handleTsdAction()', () => {
    const spy = jest.spyOn(dialog, 'open');
    component.handleTsdAction({ action: 'invalidation' });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should be called changePage()', () => {
    const spy = jest.spyOn(advSearchService, 'getAdvSearchResult');
    component.changePage({
      backendURL:
        'http://localhost:4200/advanced-search/search-results?registrationDateAfter=2022-03-31T00:00:00.000Z&registrationDateBefore=2022-04-08T23:59:00.000Z&sort=registrationDate&pageSize=20'
    });
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should be called changePageSize()', () => {
    component.currUrl = 'search-results?registrationDateAfter=6/16/2021';
    const spy = jest.spyOn(advSearchFacade, 'getAdvSearch');
    component.changePageSize(20);
    fixture.detectChanges();
    expect(spy).toHaveBeenCalled();
  });
  it('should  add default Parameters ()', () => {
    const url =
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z';
    const newURL = component.addParameters(url);
    expect(newURL).toEqual(
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&pageSize=10&sort=-registrationDate'
    );
  });
  it('should  add default pageSize Parameters ()', () => {
    const url =
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&sort=-registrationDate';
    const newURL = component.addParameters(url);
    expect(newURL).toEqual(
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&sort=-registrationDate&pageSize=10'
    );
  });
  it('should  add default sort Parameters ()', () => {
    const url =
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&pageSize=20';
    const newURL = component.addParameters(url);
    expect(newURL).toEqual(
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&pageSize=20&sort=-registrationDate'
    );
  });
  it('should  not add Parameters ()', () => {
    const url =
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&pageSize=20&sort=-registrationDate';
    const newURL = component.addParameters(url);
    expect(newURL).toEqual(
      'registrationDateAfter=2022-03-06T00:00:00.000Z&registrationDateBefore=2022-04-06T00:00:00.000Z&pageSize=20&sort=-registrationDate'
    );
  });
});
