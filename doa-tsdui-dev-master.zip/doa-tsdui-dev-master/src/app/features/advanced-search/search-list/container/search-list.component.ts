/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
import { ChangeDetectionStrategy, Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@core/services/config/config.service';
import { AdvSearchResult } from '@features/advanced-search/models';
import { AdvSearchFacade } from '@features/advanced-search/services/adv-search-facade.service';
import { InvalidateDialogComponent } from '@features/manage-declaration/invalidation-dialog/invalidation-dialog.component';
import { ConsultGenralInfoService } from '@features/manage-declaration/services/consult-genral-info.service';
import { TranslateService } from '@ngx-translate/core';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-search-list',
  templateUrl: './search-list.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchListComponent {
  tsdList$: Observable<AdvSearchResult>;
  locale: string;
  pnUrl: string;
  currUrl: string;
  pageSizeParam = '&pageSize=';
  constructor(
    private advSearchFacade: AdvSearchFacade,
    private translateService: TranslateService,
    private configService: ConfigService,
    public dialog: MatDialog,
    private consultGenInfoService: ConsultGenralInfoService
  ) {
    this.pnUrl = String(configService.getConfig().pnUIUrl);
    this.translateService.onLangChange.subscribe(() => {
      this.locale = this.translateService.currentLang;
    });
    this.handleRouteSubscription();
    this.tsdList$ = this.advSearchFacade.getAdvSearchResult();
  }
  handleRouteSubscription(): void {
    this.advSearchFacade.currentRouteParams.subscribe((params) => {
      if (params) {
        this.currUrl = params.url;
        this.advSearchFacade.getAdvSearch(
          params.url.split('?')[1],
          true,
          false
        );
      }
    });
  }
  refineSearch(): void {
    this.advSearchFacade.navigateToSearchParam(this.currUrl.split('?')[1]);
  }
  handleTsdAction(action): void {
    if (action.action === 'view') {
      this.advSearchFacade.navigateToConsultScreen(action.mrn);
    }
    if (action.action === 'invalidation') {
      this.dialog.open(InvalidateDialogComponent, {
        disableClose: true,
        minWidth: '735px',
        minHeight: '271px',
        autoFocus: false,
        data: {
          tsdId: action.mrn
        }
      });
    }
    // adding amendment functionality
    if (action.action === 'amendment') {
      this.consultGenInfoService.dispatchAmendTsdAction(action.mrn, action.mrn);
    }
    if (action.action === 'continueAmend') {
      const tsdId = action?.draftAmendment.split('/')?.pop();
      this.consultGenInfoService.continueAmendTsdAction(tsdId, action.mrn);
    }
  }
  sortDraft(event): void {
    const url =
      this.currUrl.split('?')[1] +
      '&sort=' +
      event?.sort +
      this.pageSizeParam +
      event?.pageSize;
    this.advSearchFacade.getAdvSearch(this.addParameters(url), false, false);
    this.tsdList$ = this.advSearchFacade.getAdvSearchResult();
  }

  changePage(event): void {
    this.advSearchFacade.getAdvSearch(
      this.addParameters(event?.backendURL.split('?')[1]),
      false,
      false
    );
    this.tsdList$ = this.advSearchFacade.getAdvSearchResult();
  }
  changePageSize(size) {
    const url = this.currUrl.split('?')[1] + this.pageSizeParam + size.pageSize;
    this.advSearchFacade.getAdvSearch(this.addParameters(url), false, false);
    this.tsdList$ = this.advSearchFacade.getAdvSearchResult();
  }
  // add default sort column && default pageSize
  addParameters(url: string): string {
    url = url.includes('pageSize') ? url : url + this.pageSizeParam + 10;
    url = url.includes('sort') ? url : url + '&sort=' + '-registrationDate';
    return url;
  }
}
