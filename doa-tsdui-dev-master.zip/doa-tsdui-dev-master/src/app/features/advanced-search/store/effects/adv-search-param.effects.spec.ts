/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ConfigService } from '@core/services/config/config.service';
import { AdvancedSearchParamForm } from '@features/advanced-search/models/adv-search-param-form';
import { AdvanceSearchRequestBuilderService } from '@features/advanced-search/services/adv-search-request-builder.service';
import { ValidateEORIActionItem } from '@features/edit-declaration/consignment-item-info/store/actions/con-item-info.actions';
import { provideMockActions } from '@ngrx/effects/testing';
import { FormGroupState } from 'ngrx-forms';
import { ReplaySubject } from 'rxjs';

import { FetchNameByEORISuccessActionItem } from '../actions/adv-search-param.actions';

import { AdvSearchParamEffects } from './adv-search-param.effects';

export interface ConGenInfodState {
  conGenInfo: {
    formState: FormGroupState<AdvancedSearchParamForm>;
  };
}
describe('AdvSearchEffect', () => {
  let actions: ReplaySubject<any>;
  let effects: AdvSearchParamEffects;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AdvSearchParamEffects,
        ConfigService,
        AdvanceSearchRequestBuilderService,
        provideMockActions(() => actions),
        HttpClient,
        HttpHandler
      ]
    });

    effects = TestBed.get(AdvSearchParamEffects);
  });

  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });
  it('should fetch name by eori', () => {
    actions = new ReplaySubject(1);
    const fetchNameByEORIAction = {
      type: FetchNameByEORISuccessActionItem.type,
      name: 'samplename',
      index: 0
    };
    actions.next(fetchNameByEORIAction);
    effects.fetchEORINameItem.subscribe((name) => {
      expect(name).toBeDefined();
    });
  });

  it('should validate eori', () => {
    actions = new ReplaySubject(1);
    const validateEORIAction = {
      type: ValidateEORIActionItem.type,
      eori: 'invalideori',
      index: 0
    };
    actions.next(validateEORIAction);
    effects.validateEoriItems.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });
});
