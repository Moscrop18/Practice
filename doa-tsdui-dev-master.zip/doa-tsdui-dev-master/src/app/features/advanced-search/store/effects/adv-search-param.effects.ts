/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-misused-promises */

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfigService } from '@core/services/config/config.service';
import { AdvanceSearchRequestBuilderService } from '@features/advanced-search/services/adv-search-request-builder.service';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { CRSGateway } from '@shared/models/crs-gateway';
import { of } from 'rxjs';
import { catchError, concatMap, map, switchMap, tap } from 'rxjs/operators';

import * as actions from '../actions/adv-search-param.actions';

@Injectable()
export class AdvSearchParamEffects {
  private apiUrl: string;

  validateEoriItems = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORIActionItem),
      concatMap((validateEORIActionItem) => {
        const isValidEoriNumberItem = true;
        return this.httpService
          .get<CRSGateway>('../../../../assets/crs-mock/crs.json')
          .pipe(
            map((data) => {
              if (data.validEORINumbers.includes(validateEORIActionItem.eori)) {
                return actions.ValidateEORISuccessActionItem({
                  eori: validateEORIActionItem.eori,
                  isValid: true
                });
              } else {
                return actions.ValidateEORISuccessActionItem({
                  eori: validateEORIActionItem.eori,
                  isValid: false
                });
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  fetchEORINameItem = createEffect((): any =>
    this.actions$.pipe(
      ofType(actions.ValidateEORISuccessActionItem),
      switchMap((validateEORISuccessActionItem) => {
        const isValidEoriNumberItem = false;
        return this.httpService
          .get('../../../../assets/crs-mock/eori-mock.json')
          .pipe(
            map((data) => {
              if (validateEORISuccessActionItem.isValid) {
                return actions.FetchNameByEORISuccessActionItem({
                  name:
                    data[constants.VALID_EORI_NUMBERS][
                      validateEORISuccessActionItem.eori
                    ].name
                });
              } else {
                return actions.FetchNameByEORISuccessActionItem({
                  name: ''
                });
              }
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      })
    )
  );

  navigate$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(actions.SetSubmittedValueAction),
        tap((action) =>
          this.router.navigate(['advanced-search/search-results'], {
            relativeTo: this.activatedRoute,
            queryParams: this.advanceSearchParamService.buildRequest(
              action.submittedValue
            )
          })
        )
      ),
    { dispatch: false }
  );

  constructor(
    private actions$: Actions,
    private httpService: HttpClient,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private advanceSearchParamService: AdvanceSearchRequestBuilderService,
    private configService: ConfigService
  ) {
    this.apiUrl = String(configService.getConfig().apiUrl);
  }
}
