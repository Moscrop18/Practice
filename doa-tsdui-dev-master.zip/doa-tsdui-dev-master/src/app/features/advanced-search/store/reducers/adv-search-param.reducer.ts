/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-member-access  */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable no-case-declarations */
import { SearchAddCustomsOffice } from '@features/advanced-search/models/search-add-cus-office';
import { SearchDeclarationInformation } from '@features/advanced-search/models/search-dec-info';
import { SearchLocationOfGoods } from '@features/advanced-search/models/search-location-goods';
import { SearchParties } from '@features/advanced-search/models/search-parties';
import { validateAutoCompleteSelection } from '@features/edit-declaration/validation-functions/auto-complete-validation-functions';
import { Action, combineReducers } from '@ngrx/store';
import {
  createFormGroupState,
  createFormStateReducerWithUpdate,
  FormGroupState,
  setValue,
  updateGroup,
  validate
} from 'ngrx-forms';
import { required } from 'ngrx-forms/validation';

import { AdvancedSearchParamForm } from '../../models/adv-search-param-form';
import * as actions from '../actions/adv-search-param.actions';

export const FORM_ID_DECLARATION_INFO = 'advSearchParam';
export const INITIAL_DECLARATION_FORM_STATE = createFormGroupState<AdvancedSearchParamForm>(
  FORM_ID_DECLARATION_INFO,
  {
    declarationInfo: {
      lrn: '',
      registrationDateBefore: null,
      registrationDateAfter: null,
      presentationDateBefore: null,
      presentationDateAfter: null
    },
    addCusOffice: {
      cusOffice: '',
      supervCusOffice: null,
      cusOffOfPres: null
    },
    entryInformation: {
      arrivalTransMeansIdn: ''
    },
    parties: {
      eori: '',
      name: '',
      declarant: null,
      representative: null,
      carrier: null,
      personPresGoods: null
    },
    transportDocument: {
      refNum: ''
    },
    containerOrRecep: {
      identifictionNo: ''
    },
    warehouseIdentifier: {
      identifier: ''
    },
    locationOfGoods: {
      unLoCode: ''
    },
    declarationStatus: {
      searchValue: {
        PreLodged: null,
        Accepted: null,
        IrregularityUnderInvestigation: null,
        Invalidated: null,
        UnderControl: null
      }
    },
    racStatus: {
      searchValue: {
        UnderControl: null,
        AwaitingRiskAnalysisResult: null,
        AwaitingRiskHitConfirmation: null,
        ControlResultRegistered: null,
        PreArrivalRiskAnalysisCompleted: null,
        PreArrivalRiskAnalysisCancelled: null,
        NoRisk: null
      }
    }
  }
);

export function advSearchParamReducer(
  s: SearchParamState['advSearchParam'],
  a: Action
) {
  return reducers(s, a);
}

const reducers = combineReducers<SearchParamState['advSearchParam'], any>({
  formState: formStateReducer,
  submittedValue(s: AdvancedSearchParamForm | undefined, a: any) {
    if (a.type == actions.SetSubmittedValueAction.type) {
      return a.submittedValue;
    } else {
      return s;
    }
  }
});
export interface SearchParamState {
  advSearchParam: {
    formState: FormGroupState<AdvancedSearchParamForm>;
    submittedValue?: AdvancedSearchParamForm;
  };
}

export function formStateReducer(
  s = INITIAL_DECLARATION_FORM_STATE,
  a: any = {}
) {
  s = validateAndUpdateForm(s, a);
  switch (a.type) {
    case actions.InitializeSearchParamAction.type:
    case actions.ClearSearchFormPage.type:
    case actions.RestoreStateParamAction.type:
      let sn: FormGroupState<AdvancedSearchParamForm> = s;
      if (actions.ClearSearchFormPage.type === a.type) {
        sn = INITIAL_DECLARATION_FORM_STATE;
      } else if (actions.InitializeSearchParamAction.type === a.type) {
        sn = createFormGroupState<AdvancedSearchParamForm>(
          FORM_ID_DECLARATION_INFO,
          a.payload
        );
      }
      return updateGroup<AdvancedSearchParamForm>({
        declarationInfo: (declaration) => {
          return updateGroup<SearchDeclarationInformation>(declaration, {
            registrationDateBefore: validate([
              required,
              validateDateRange(declaration.value)
            ]),
            registrationDateAfter: validate([
              required,
              validateDateRange(declaration.value)
            ])
          });
        }
      })(sn);
    case actions.FetchNameByEORISuccessActionItem.type:
      return updateGroup<AdvancedSearchParamForm>({
        parties: (parties) => {
          return updateGroup<SearchParties>(parties, {
            name: (name) => {
              name = setValue<string>(name, a.name);
              return name;
            }
          });
        }
      })(s);
    case actions.ValidateUnloCode.type:
      return updateGroup<AdvancedSearchParamForm>({
        locationOfGoods: (locationOfGoods) => {
          return updateGroup<SearchLocationOfGoods>({
            unLoCode: validate(
              validateAutoCompleteSelection(a.selectedValue, a.autoCompleteList)
            )
          })(s.controls.locationOfGoods);
        }
      })(s);
    case actions.validateAddressedCustomsOffice.type:
      return updateGroup<AdvancedSearchParamForm>({
        addCusOffice: (addCusOffice) => {
          return updateGroup<SearchAddCustomsOffice>({
            cusOffice: validate(
              validateAutoCompleteSelection(a.selectedValue, a.autoCompleteList)
            )
          })(s.controls.addCusOffice);
        }
      })(s);
    default:
      return s;
  }
}

const validateAndUpdateForm = createFormStateReducerWithUpdate<AdvancedSearchParamForm>(
  updateGroup<AdvancedSearchParamForm>({
    declarationInfo: (declarationInfo) => {
      return updateGroup<SearchDeclarationInformation>(declarationInfo, {
        registrationDateBefore: validate([
          required,
          validateDateRange(declarationInfo.value)
        ]),
        registrationDateAfter: validate([
          required,
          validateDateRange(declarationInfo.value)
        ])
      });
    }
  })
);

export function validateDateRange<T>(
  expr: SearchDeclarationInformation
): (value: T | null) => MCInformationError {
  return (value: T | null): MCInformationError => {
    const d1 = new Date(expr.registrationDateBefore);
    const d2 = new Date(expr.registrationDateAfter);
    let diff = Math.abs(d1.getTime() - d2.getTime());
    diff = diff / (1000 * 60 * 60 * 24);
    if (diff > 61) {
      return {
        isDateRangeValid: false
      };
    }
    return {};
  };
}

export interface MCInformationError {
  isDateRangeValid?: boolean;
}
