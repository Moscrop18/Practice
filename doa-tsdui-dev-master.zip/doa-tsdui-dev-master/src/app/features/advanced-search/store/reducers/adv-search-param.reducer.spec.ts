import { AdvancedSearchParamForm } from '@features/advanced-search/models/adv-search-param-form';
import { FormGroupState, setValue } from 'ngrx-forms';

import * as action from '../actions/adv-search-param.actions';

import * as reducer from './adv-search-param.reducer';

export interface AdvSearchState {
  advSearch: {
    formState: FormGroupState<AdvancedSearchParamForm>;
  };
}

describe('advSearchReducer', () => {
  it('should return the default state', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const action = { type: '' };
    const state = reducer.advSearchParamReducer(undefined, action);
    expect(state.formState.controls.addCusOffice.id).toBe(
      INITIAL_DECLARATION_FORM_STATE.controls.addCusOffice.id
    );
  });

  it('should submit form', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const submitAction = {
      type: action.SetSubmittedValueAction.type,
      submittedValue: {
        declarationInfo: {
          lrn: '1234',
          registrationDateBefore: null,
          registrationDateAfter: null,
          presentationDateBefore: null,
          presentationDateAfter: null
        },
        addCusOffice: {
          cusOffice: '',
          supervCusOffice: null,
          cusOffOfPres: null
        },
        entryInformation: {
          arrivalTransMeansIdn: ''
        },
        parties: {
          eori: '',
          name: '',
          declarant: null,
          representative: null,
          carrier: null,
          personPresGoods: null
        },
        transportDocument: {
          refNum: ''
        },
        warehouseIdentifier: {
          identifier: ''
        },
        locationOfGoods: {
          unLoCode: ''
        },
        containerOrRecep: {
          identifictionNo: ''
        },
        declarationStatus: {
          searchValue: {
            prelodged: null,
            accepted: null,
            irregularity: null,
            invalidated: null
          }
        }
      }
    };
    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      submitAction
    );
    expect(state.submittedValue.declarationInfo.lrn).toEqual('1234');
  });

  it('should populate name', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const fetchNameByEORIAction = {
      type: action.FetchNameByEORISuccessActionItem.type,
      name: 'samplename',
      index: 0
    };

    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      fetchNameByEORIAction
    );

    expect(state.formState.controls.parties.controls.name.value).toEqual(
      'samplename'
    );
  });
  it('test ClearSearchFormPage', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const intAtion = {
      type: action.ClearSearchFormPage.type
    };

    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      intAtion
    );

    expect(state.formState.controls.declarationInfo.controls.lrn.value).toEqual(
      ''
    );
  });
  it('test RestoreStateParamAction', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const intAtion = {
      type: action.RestoreStateParamAction.type
    };

    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      intAtion
    );

    expect(state.formState.controls.declarationInfo.controls.lrn.value).toEqual(
      ''
    );
  });

  it('test InitializeSearchParamAction', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const intAtion = {
      type: action.InitializeSearchParamAction.type,
      payload: {
        declarationInfo: {
          lrn: '',
          registrationDateBefore: null,
          registrationDateAfter: null,
          presentationDateBefore: null,
          presentationDateAfter: null
        },
        addCusOffice: {
          cusOffice: '',
          supervCusOffice: null,
          cusOffOfPres: null
        },
        entryInformation: {
          arrivalTransMeansIdn: ''
        },
        parties: {
          eori: '',
          name: '',
          declarant: null,
          representative: null,
          carrier: null,
          personPresGoods: null
        },
        transportDocument: {
          refNum: ''
        },
        warehouseIdentifier: {
          identifier: ''
        },
        locationOfGoods: {
          unLoCode: ''
        },
        containerOrRecep: {
          identifictionNo: ''
        },
        declarationStatus: {
          searchValue: {
            prelodged: null,
            accepted: null,
            irregularity: null,
            invalidated: null
          }
        }
      }
    };

    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      intAtion
    );

    expect(state.formState.controls.declarationInfo.controls.lrn.value).toEqual(
      ''
    );
  });
  it('should call ValidateUnloCode for invalid selection', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const ValidateUnloCode = {
      type: action.ValidateUnloCode.type,
      selectedValue: 'C',
      autoCompleteList: ['A', 'B']
    };
    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      ValidateUnloCode
    );
    expect(
      state.formState.controls.locationOfGoods.controls.unLoCode.errors
    ).toEqual({ 'isWrongSelection': true });
  });
  it('should call ValidateUnloCode for valid selection', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const ValidateUnloCode = {
      type: action.ValidateUnloCode.type,
      selectedValue: 'a',
      autoCompleteList: ['A', 'B']
    };
    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      ValidateUnloCode
    );
    expect(
      state.formState.controls.locationOfGoods.controls.unLoCode.errors
    ).toEqual({});
  });
  it('should call validateAddressedCustomsOffice for invalid selection', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const validateAddressedCustomsOffice = {
      type: action.validateAddressedCustomsOffice.type,
      selectedValue: 'C',
      autoCompleteList: ['A', 'B']
    };
    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      validateAddressedCustomsOffice
    );
    expect(
      state.formState.controls.addCusOffice.controls.cusOffice.errors
    ).toEqual({
      'isWrongSelection': true
    });
  });
  it('should call validateAddressedCustomsOffice for valid selection', () => {
    const { INITIAL_DECLARATION_FORM_STATE } = reducer;
    const validateAddressedCustomsOffice = {
      type: action.validateAddressedCustomsOffice.type,
      selectedValue: 'b',
      autoCompleteList: ['A', 'B']
    };
    const state = reducer.advSearchParamReducer(
      { formState: INITIAL_DECLARATION_FORM_STATE },
      validateAddressedCustomsOffice
    );
    expect(
      state.formState.controls.addCusOffice.controls.cusOffice.errors
    ).toEqual({});
  });
});
