import { createAction, props } from '@ngrx/store';

import { AdvancedSearchParamForm } from '../../models/adv-search-param-form';

export const SetSubmittedValueAction = createAction(
  'advSearchParam/SET_SUBMITTED_VALUE',
  props<{ submittedValue: AdvancedSearchParamForm }>()
);

export const ValidateEORIActionItem = createAction(
  'advSearchParam/GET_DECLARANT_EORI',
  props<{ eori: string }>()
);

export const FetchNameByEORISuccessActionItem = createAction(
  'advSearchParam/FETCH_NAME_BY_EORI_SUCCESS',
  props<{ name: string }>()
);

export const ValidateUnloCode = createAction(
  'advSearchParam/VALIDATE_UNLOCODE_SELECTION',
  props<{ selectedValue: string; autoCompleteList: string[] }>()
);

export const validateAddressedCustomsOffice = createAction(
  'advSearchParam/VALIDATE_ADDRESSED_CUSTOMSOFFICE',
  props<{ selectedValue: string; autoCompleteList: string[] }>()
);

export const ValidateEORISuccessActionItem = createAction(
  'advSearchParam/VALIDATE_EORI_SUCCESS',
  props<{ eori: string; isValid: boolean }>()
);

export const ClearSearchFormPage = createAction(
  'advSearchParam/CLEAR_SEARCH_FORM'
);

export const InitializeSearchParamAction = createAction(
  'advSearchParam/INITIALIZE_SEARCH_PARAM',
  props<{ payload: AdvancedSearchParamForm }>()
);

export const RestoreStateParamAction = createAction(
  'advSearchParam/RESTORE_SEARCH_PARAM'
);
