/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable sonarjs/no-duplicate-string */
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { Store } from '@ngrx/store';
import { of } from 'rxjs';

import { AdvancedSearchParamForm } from './../models/adv-search-param-form';
import * as action from './../store/actions/adv-search-param.actions';
import { AdvanceSearchParamService } from './adv-search-param.service';

describe('AdvanceSearchParamService', () => {
  let service: AdvanceSearchParamService;
  let store: Store<any>;
  let facade: CodeListService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AdvanceSearchParamService,
        {
          provide: Store,
          useValue: {
            dispatch: jest.fn(),
            pipe: jest.fn(),
            select: jest.fn()
          }
        }
      ]
    });
    service = TestBed.inject(AdvanceSearchParamService);
    facade = TestBed.inject(CodeListService);
    store = TestBed.inject(Store);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('clearForm should be called', () => {
    const dispatchSpy = jest.spyOn(store, 'dispatch');
    service.clearForm();
    expect(dispatchSpy).toHaveBeenCalledWith(action.ClearSearchFormPage());
  });

  it('Handle parties should be called', () => {
    const param = {
      queryParams: {
        carrier: null,
        declarant: null,
        representative: null,
        personPresentingTheGoods: null
      }
    };
    const result = service.handleParties(param);
    expect(result).toEqual({
      carrier: null,
      declarant: null,
      eori: '',
      name: '',
      personPresGoods: null,
      representative: null
    });
  });

  it('Handle status should be called', () => {
    const param = {
      queryParams: {
        status:
          'Accepted,IrregularityUnderInvestigation,Invalidated,PreLodged,UnderControl'
      }
    };
    const result = service.handleStatus(param);
    expect(result).toEqual({
      searchValue: {
        Accepted: true,
        Invalidated: true,
        IrregularityUnderInvestigation: true,
        PreLodged: true,
        UnderControl: true
      }
    });
  });

  it('Handle declaration should be called', () => {
    const param = {
      queryParams: {
        lrn: '123',
        registrationDateAfter: 'Fri Apr 29 2022 17:57:23 GMT+0530',
        registrationDateBefore: 'Fri Apr 29 2022 18:57:23 GMT+0530',
        presentationDateAfter: 'Fri Apr 29 2022 19:57:23 GMT+0530',
        presentationDateBefore: 'Fri Apr 29 2022 20:57:23 GMT+0530'
      }
    };
    const result = service.handleDeclarationInfo(param);
    expect(result).toEqual({
      lrn: '123',
      presentationDateAfter: 'Fri Apr 29 2022 19:57:23 GMT+0530',
      presentationDateBefore: '2022-04-28T23:00:00.000Z',
      registrationDateAfter: 'Fri Apr 29 2022 17:57:23 GMT+0530',
      registrationDateBefore: '2022-04-28T23:00:00.000Z'
    });
  });

  it('navigate to search param', () => {
    const dispatchSpy = jest.spyOn(store, 'dispatch');
    service.navigateToSearchParam(
      'regDateBefore=21-19-2020?regDateAfter=21-19-2020'
    );
    expect(dispatchSpy).toHaveBeenCalled();
  });

  it('getDeclarantForEori should be called', () => {
    const dispatchSpy = jest.spyOn(store, 'dispatch');
    service.getDeclarantForEori('');
    expect(dispatchSpy).toHaveBeenCalledWith(
      action.ValidateEORIActionItem({ eori: '' })
    );
  });

  it('submitForm should be called', () => {
    const dispatchSpy = jest.spyOn(store, 'dispatch');
    const form: AdvancedSearchParamForm = {
      declarationInfo: {
        lrn: '',
        registrationDateBefore: null,
        registrationDateAfter: null,
        presentationDateBefore: null,
        presentationDateAfter: null
      },
      addCusOffice: {
        cusOffice: '',
        supervCusOffice: null,
        cusOffOfPres: null
      },
      entryInformation: {
        arrivalTransMeansIdn: ''
      },
      parties: {
        eori: '',
        name: '',
        declarant: null,
        representative: null,
        carrier: null,
        personPresGoods: null
      },
      transportDocument: {
        refNum: ''
      },
      locationOfGoods: {
        unLoCode: ''
      },
      warehouseIdentifier: {
        identifier: ''
      },
      containerOrRecep: {
        identifictionNo: ''
      },
      declarationStatus: {
        searchValue: {
          Accepted: null,
          Invalidated: null,
          IrregularityUnderInvestigation: null,
          PreLodged: null,
          UnderControl: null
        }
      }
    };
    service.submitForm(form);
    expect(dispatchSpy).toHaveBeenCalledWith(
      action.SetSubmittedValueAction({ submittedValue: form })
    );
  });

  it('should call codelist', () => {
    const spy = jest.spyOn(facade, 'dispatchFetchCodeListDataAction');
    service.dispatchFetchCodeListDataAction();
    expect(spy).toHaveBeenCalled();
  });

  it('should call getAddressedCustomsOfficeCodes', () => {
    const spy = jest.spyOn(facade, 'getAddressedCustomsOfficeCodes');
    service.getAddressedCustomsOfficeCodes();
    expect(spy).toHaveBeenCalled();
  });

  it('should call handleContainerRecep', () => {
    const param = {
      queryParams: {
        containerOrReceptacle: ''
      }
    };
    const res = service.handleContainerRecep(param);
    expect(res).toBeDefined();
  });

  it('should call handleTransportDoc', () => {
    const param = {
      queryParams: {
        transportDocument: ''
      }
    };
    const res = service.handleTransportDoc(param);
    expect(res).toBeDefined();
  });

  it('should call handleWarehouseIdentifier', () => {
    const param = {
      queryParams: {
        warehouseIdentifier: ''
      }
    };
    const res = service.handleWarehouseIdentifier(param);
    expect(res).toBeDefined();
  });

  it('should call handleLocationOfGoods', () => {
    const param = {
      queryParams: {
        locationOfGoods: ''
      }
    };
    const res = service.handleLocationOfGoods(param);
    expect(res).toBeDefined();
  });

  it('should call handleEntryInfo', () => {
    const param = {
      queryParams: {
        arrivalTransportMeans: ''
      }
    };
    const res = service.handleEntryInfo(param);
    expect(res).toBeDefined();
  });

  it('should call handleCusOff', () => {
    const param = {
      queryParams: {
        presentationOfficeRefNum: '',
        supervisingOfficeRefNum: ''
      }
    };
    const codeList = [
      {
        id: 0,
        value: 'BE212000',
        definition: 'Zaventem D'
      }
    ];
    const res = service.handleCusOff(param, of(codeList));
    expect(res).toBeDefined();
  });
  it('should call handleCusOff with presentationOfficeRefNum', () => {
    const param = {
      queryParams: {
        presentationOfficeRefNum: 'BE212000',
        supervisingOfficeRefNum: ''
      }
    };
    const codeList = [
      {
        id: 0,
        value: 'BE212000',
        definition: 'Zaventem D'
      }
    ];
    const res = service.handleCusOff(param, of(codeList));
    expect(res).toEqual({
      cusOffice: 'BE212000 - Zaventem D',
      cusOffOfPres: 'BE212000',
      supervCusOffice: null
    });
  });
  it('should call handleCusOff with supervisingOfficeRefNum', () => {
    const param = {
      queryParams: {
        presentationOfficeRefNum: '',
        supervisingOfficeRefNum: 'BE212000'
      }
    };
    const codeList = [
      {
        id: 0,
        value: 'BE212000',
        definition: 'Zaventem D'
      }
    ];
    const res = service.handleCusOff(param, of(codeList));
    expect(res).toEqual({
      cusOffice: 'BE212000 - Zaventem D',
      cusOffOfPres: null,
      supervCusOffice: 'BE212000'
    });
  });
  it('should call handleRacStatus', () => {
    const param = {
      queryParams: {
        riskAndControlstatus: [
          'UnderControl',
          'AwaitingRiskAnalysisResult',
          'AwaitingRiskHitConfirmation',
          'ControlResultRegistered',
          'PreArrivalRiskAnalysisCompleted',
          'PreArrivalRiskAnalysisCancelled',
          'NoRisk'
        ]
      }
    };
    const result = service.handleRacStatus(param);
    expect(result).toEqual({
      searchValue: {
        UnderControl: true,
        AwaitingRiskAnalysisResult: true,
        AwaitingRiskHitConfirmation: true,
        ControlResultRegistered: true,
        PreArrivalRiskAnalysisCompleted: true,
        PreArrivalRiskAnalysisCancelled: true,
        NoRisk: true
      }
    });
  });
  it('should call handleRacStatu for null values', () => {
    const param = {
      queryParams: {
        'registrationDateAfter': '2022-01-31T00:00:00.000Z',
        'registrationDateBefore': '2022-02-24T23:59:00.000Z'
      }
    };
    const result = service.handleRacStatus(param);
    expect(result).toEqual({
      searchValue: {
        UnderControl: null,
        AwaitingRiskAnalysisResult: null,
        AwaitingRiskHitConfirmation: null,
        ControlResultRegistered: null,
        PreArrivalRiskAnalysisCompleted: null,
        PreArrivalRiskAnalysisCancelled: null,
        NoRisk: null
      }
    });
  });
  it('should call validateAddressedCustomsOffice', () => {
    const dispatchSpy = jest.spyOn(store, 'dispatch');
    service.validateAddressedCustomsOffice('A', ['A - Yes']);
    expect(dispatchSpy).toHaveBeenCalledWith(
      action.validateAddressedCustomsOffice({
        selectedValue: 'A',
        autoCompleteList: ['A - Yes']
      })
    );
  });
  it('should call getEORI', () => {
    const param = {
      queryParams: {
        carrier: '',
        declarant: '',
        representative: ''
      }
    };
    const res = service.getEORI(param);
    expect(res).toEqual('');
  });
  it('should call getEORI with carrier', () => {
    const param = {
      queryParams: {
        carrier: 'BE0214596464',
        declarant: '',
        representative: ''
      }
    };
    const res = service.getEORI(param);
    expect(res).toBe('BE0214596464');
  });
  it('should call getEORI with declarant', () => {
    const param = {
      queryParams: {
        carrier: '',
        declarant: 'BE0214596464',
        representative: ''
      }
    };
    const res = service.getEORI(param);
    expect(res).toBe('BE0214596464');
  });
  it('should call getEORI with representative', () => {
    const param = {
      queryParams: {
        carrier: '',
        declarant: '',
        representative: 'BE0214596464'
      }
    };
    const res = service.getEORI(param);
    expect(res).toBe('BE0214596464');
  });
  it('should call getEORI with personPresentingTheGoods', () => {
    const param = {
      queryParams: {
        personPresentingTheGoods: 'BE0214596464'
      }
    };
    const res = service.getEORI(param);
    expect(res).toBe('BE0214596464');
  });
  it('test getQueryParams', () => {
    const params = 'declarant=BE0214596464&declarant=BE0214596465';
    expect(service.getQueryParams(params)).toEqual({
      declarant: ['BE0214596464', 'BE0214596465']
    });
  });
});
