/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-call */
import { Injectable } from '@angular/core';
import { Params } from '@angular/router';
import {
  AddressedCustomsOfficeCode,
  Codelist
} from '@core/gateways/codelist/model/addressed-customs-office-code';
import { PlaceOfUnloadingCode } from '@core/gateways/codelist/model/place-of-unloading-code';
import { CodeListService } from '@core/gateways/codelist/service/code-list.service';
import { MergedRoute } from '@core/root-store/root.reducer';
import { getMergedRoute } from '@core/root-store/router-state.selectors';
import * as searchResultactions from '@features/advanced-search/search-list/store/actions/adv-search-result.actions';
import {
  AdvsearchResultState,
  getAdvSearchResultData
} from '@features/advanced-search/search-list/store/reducers/adv-search-result.reducer';
import * as actions from '@features/advanced-search/store/actions/adv-search-param.actions';
import { SearchParamState } from '@features/advanced-search/store/reducers/adv-search-param.reducer';
import { select, Store } from '@ngrx/store';
import { FormGroupState } from 'ngrx-forms';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import { SearchAddCustomsOffice } from '../models/search-add-cus-office';
import { SearchContainerOrRecep } from '../models/search-container-rec';
import { SearchDeclarationInformation } from '../models/search-dec-info';
import { SearchDeclarationStatus } from '../models/search-dec-status';
import { SearchEntryInformation } from '../models/search-entry-info';
import { SearchLocationOfGoods } from '../models/search-location-goods';
import { SearchParties } from '../models/search-parties';
import { SearchRacStatus } from '../models/search-rac-status';
import { SearchTransportDocument } from '../models/search-trans-doc';
import { SearchWarehouseIdentifier } from '../models/search-warehouse-identifier';

import { AdvancedSearchParamForm } from './../models/adv-search-param-form';

@Injectable()
export class AdvanceSearchParamService {
  clearForm() {
    this.store.dispatch(actions.ClearSearchFormPage());
  }

  getDeclarantForEori(eori: string) {
    this.store.dispatch(
      actions.ValidateEORIActionItem({
        eori: eori
      })
    );
  }
  getAdvSearch(param: string, newSearch: boolean, isDraftAPICalled: boolean) {
    this.searchResultStore.dispatch(
      searchResultactions.LoadAdvSearchResult({
        payload: param,
        initial: newSearch,
        url: isDraftAPICalled
          ? 'saved-drafts'
          : 'advanced-search/search-results',
        param: '',
        queryParam: this.getQueryParams(param)
      })
    );
  }

  getAdvSearchResult() {
    return this.searchResultStore.select(getAdvSearchResultData);
  }
  constructor(
    private store: Store<SearchParamState>,
    private searchResultStore: Store<AdvsearchResultState>,
    private codeListService: CodeListService,
    private routeStore: Store<MergedRoute>
  ) {}

  public getFormState(): Observable<FormGroupState<AdvancedSearchParamForm>> {
    return this.store.pipe(
      select((s) => {
        return s.advSearchParam.formState;
      })
    );
  }

  public dispatchFetchCodeListDataAction(): void {
    return this.codeListService.dispatchFetchCodeListDataAction();
  }
  public getAddressedCustomsOfficeCodes(): Observable<
    AddressedCustomsOfficeCode[]
  > {
    return this.codeListService.getAddressedCustomsOfficeCodes();
  }

  public getPlaceOfUnloadingCodes(): Observable<PlaceOfUnloadingCode[]> {
    return this.codeListService.getPlaceOfUnloadingCodes();
  }

  public validateUnloCode(value: string, codeList: string[]) {
    this.store.dispatch(
      actions.ValidateUnloCode({
        selectedValue: value,
        autoCompleteList: codeList
      })
    );
  }

  public validateAddressedCustomsOffice(value: string, codeList: string[]) {
    this.store.dispatch(
      actions.validateAddressedCustomsOffice({
        selectedValue: value,
        autoCompleteList: codeList
      })
    );
  }

  public submitForm(value: AdvancedSearchParamForm): void {
    this.store.dispatch(
      actions.SetSubmittedValueAction({ submittedValue: value })
    );
  }

  public get currentRouteParams(): Observable<Params> {
    return this.routeStore.pipe(take(1), select(getMergedRoute));
  }
  navigateToSearchParam(params: string): void {
    this.store.dispatch(
      searchResultactions.Navigate({
        url: 'advanced-search',
        param: '',
        queryParam: this.getQueryParams(params)
      })
    );
  }

  initializeSearchParam() {
    this.currentRouteParams.subscribe((param) => {
      let payload: AdvancedSearchParamForm;
      if (param.queryParams.registrationDateAfter) {
        payload = {
          declarationInfo: this.handleDeclarationInfo(param),
          addCusOffice: this.handleCusOff(
            param,
            this.getAddressedCustomsOfficeCodes()
          ),
          entryInformation: this.handleEntryInfo(param),
          parties: this.handleParties(param),
          transportDocument: this.handleTransportDoc(param),
          containerOrRecep: this.handleContainerRecep(param),
          declarationStatus: this.handleStatus(param),
          racStatus: this.handleRacStatus(param),
          warehouseIdentifier: this.handleWarehouseIdentifier(param),
          locationOfGoods: this.handleLocationOfGoods(param)
        };
        this.store.dispatch(actions.InitializeSearchParamAction({ payload }));
      } else {
        this.store.dispatch(actions.RestoreStateParamAction());
      }
    });
  }

  handleContainerRecep(param): SearchContainerOrRecep {
    return {
      identifictionNo: param.queryParams.containerOrReceptacle
        ? param.queryParams.containerOrReceptacle
        : ''
    };
  }
  handleWarehouseIdentifier(param): SearchWarehouseIdentifier {
    return {
      identifier: param.queryParams.warehouseIdentifier
        ? param.queryParams.warehouseIdentifier
        : ''
    };
  }
  handleLocationOfGoods(param): SearchLocationOfGoods {
    return {
      unLoCode: param.queryParams.locationOfGoods
        ? param.queryParams.locationOfGoods
        : ''
    };
  }
  handleTransportDoc(param): SearchTransportDocument {
    return {
      refNum: param.queryParams.transportDocument
        ? param.queryParams.transportDocument
        : ''
    };
  }

  handleEntryInfo(param): SearchEntryInformation {
    return {
      arrivalTransMeansIdn: param.queryParams.arrivalTransportMeans
        ? param.queryParams.arrivalTransportMeans
        : ''
    };
  }

  handleParties(param): SearchParties {
    return {
      carrier: param.queryParams.carrier ? param.queryParams.carrier : null,
      declarant: param.queryParams.declarant
        ? param.queryParams.declarant
        : null,
      eori: this.getEORI(param),
      name: param.queryParams.name ? param.queryParams.name : '',
      personPresGoods: param.queryParams.personPresentingTheGoods
        ? param.queryParams.personPresentingTheGoods
        : null,
      representative: param.queryParams.representative
        ? param.queryParams.representative
        : null
    };
  }

  handleStatus(param): SearchDeclarationStatus {
    return {
      searchValue: {
        Accepted:
          param.queryParams.status &&
          param.queryParams.status.includes('Accepted')
            ? true
            : null,
        Invalidated:
          param.queryParams.status &&
          param.queryParams.status.includes('Invalidated')
            ? true
            : null,
        PreLodged:
          param.queryParams.status &&
          param.queryParams.status.includes('PreLodged')
            ? true
            : null,
        IrregularityUnderInvestigation:
          param.queryParams.status &&
          param.queryParams.status.includes('IrregularityUnderInvestigation')
            ? true
            : null,
        UnderControl:
          param.queryParams.status &&
          param.queryParams.status.includes('UnderControl')
            ? true
            : null
      }
    };
  }

  handleRacStatus(param): SearchRacStatus {
    return {
      searchValue: {
        UnderControl:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes('UnderControl')
            ? true
            : null,
        AwaitingRiskAnalysisResult:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes(
            'AwaitingRiskAnalysisResult'
          )
            ? true
            : null,
        AwaitingRiskHitConfirmation:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes(
            'AwaitingRiskHitConfirmation'
          )
            ? true
            : null,
        ControlResultRegistered:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes(
            'ControlResultRegistered'
          )
            ? true
            : null,
        PreArrivalRiskAnalysisCompleted:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes(
            'PreArrivalRiskAnalysisCompleted'
          )
            ? true
            : null,
        PreArrivalRiskAnalysisCancelled:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes(
            'PreArrivalRiskAnalysisCancelled'
          )
            ? true
            : null,
        NoRisk:
          param.queryParams.riskAndControlstatus &&
          param.queryParams.riskAndControlstatus.includes('NoRisk')
            ? true
            : null
      }
    };
  }

  handleCusOff(param, codelist$): SearchAddCustomsOffice {
    let customsOfficeCodelist: AddressedCustomsOfficeCode[];
    codelist$.subscribe((val) => (customsOfficeCodelist = val));
    let newValue: AddressedCustomsOfficeCode[];
    if (
      customsOfficeCodelist.length > 0 &&
      (param?.queryParams?.presentationOfficeRefNum ||
        param?.queryParams?.supervisingOfficeRefNum)
    ) {
      let cusOffice = '';
      if (param.queryParams?.presentationOfficeRefNum)
        cusOffice = param.queryParams?.presentationOfficeRefNum;
      else cusOffice = param?.queryParams?.supervisingOfficeRefNum;
      newValue = customsOfficeCodelist.filter(function (customsOfficeCode) {
        return customsOfficeCode.value === cusOffice;
      });
    }
    return {
      cusOffice: newValue
        ? newValue[0]?.value + ' - ' + newValue[0]?.definition
        : '',
      cusOffOfPres: param.queryParams?.presentationOfficeRefNum
        ? param.queryParams.presentationOfficeRefNum
        : null,

      supervCusOffice: param.queryParams?.supervisingOfficeRefNum
        ? param.queryParams.supervisingOfficeRefNum
        : null
    };
  }

  handleDeclarationInfo(param): SearchDeclarationInformation {
    return {
      lrn: param.queryParams.lrn ? param.queryParams.lrn : '',
      registrationDateAfter: param.queryParams.registrationDateAfter
        ? param.queryParams.registrationDateAfter
        : null,
      registrationDateBefore: param.queryParams.registrationDateBefore
        ? new Date(
            new Date(param.queryParams.registrationDateBefore).setHours(
              -1,
              0,
              0,
              0
            )
          ).toISOString()
        : null,
      presentationDateAfter: param.queryParams.presentationDateAfter
        ? param.queryParams.presentationDateAfter
        : null,
      presentationDateBefore: param.queryParams.presentationDateBefore
        ? new Date(
            new Date(param.queryParams.presentationDateBefore).setHours(
              -1,
              0,
              0,
              0
            )
          ).toISOString()
        : null
    };
  }

  navigateToConsultScreen(mrn: string) {
    this.store.dispatch(
      searchResultactions.Navigate({
        url: 'advanced-search/search-results/',
        param: mrn
      })
    );
  }

  getQueryParams(param) {
    const queryParams = {};
    const searchParams = new URLSearchParams(param);
    for (const key of searchParams.keys()) {
      if (searchParams.getAll(key).length > 1)
        queryParams[key] = searchParams.getAll(key);
      else queryParams[key] = searchParams.get(key);
    }
    return queryParams;
  }
  getEORI(param: Params): any {
    let eori: string;
    if (param?.queryParams?.carrier) eori = param?.queryParams?.carrier;
    else if (param.queryParams.declarant) eori = param?.queryParams?.declarant;
    else if (param.queryParams.representative)
      eori = param?.queryParams?.representative;
    else if (param.queryParams.personPresentingTheGoods)
      eori = param?.queryParams?.personPresentingTheGoods;
    else eori = '';
    return eori;
  }
}
