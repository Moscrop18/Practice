/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/restrict-plus-operands */
/* eslint-disable sonarjs/cognitive-complexity */

import { Injectable } from '@angular/core';

import { AdvancedSearchParamForm } from './../models/adv-search-param-form';

@Injectable()
export class AdvanceSearchRequestBuilderService {
  buildRequest(value: AdvancedSearchParamForm) {
    const request = {
      registrationDateAfter: this.getInitialDate(
        value.declarationInfo.registrationDateAfter
      ),
      registrationDateBefore: this.getEndDate(
        value.declarationInfo.registrationDateBefore
      )
    };
    if (this.setStatus(value.declarationStatus.searchValue).length > 0) {
      request['status'] = this.setStatus(value.declarationStatus.searchValue);
    }
    if (this.setStatus(value?.racStatus?.searchValue).length > 0) {
      request['riskAndControlstatus'] = this.setStatus(
        value?.racStatus?.searchValue
      );
    }
    if (value.declarationInfo.presentationDateAfter)
      request['presentationDateAfter'] = this.getInitialDate(
        value.declarationInfo.presentationDateAfter
      );
    if (value.declarationInfo.presentationDateBefore)
      request['presentationDateBefore'] = this.getEndDate(
        value.declarationInfo.presentationDateBefore
      );
    if (value.declarationInfo.lrn) request['lrn'] = value.declarationInfo.lrn;
    if (value.entryInformation && value.entryInformation.arrivalTransMeansIdn)
      request['arrivalTransportMeans'] =
        value.entryInformation.arrivalTransMeansIdn;
    if (value.transportDocument && value.transportDocument.refNum)
      request['transportDocument'] = value.transportDocument.refNum;
    if (value.containerOrRecep && value.containerOrRecep.identifictionNo)
      request['containerOrReceptacle'] = value.containerOrRecep.identifictionNo;
    if (value.warehouseIdentifier && value.warehouseIdentifier.identifier)
      request['warehouseIdentifier'] = value.warehouseIdentifier.identifier;
    if (value.locationOfGoods && value.locationOfGoods.unLoCode)
      request['locationOfGoods'] = value.locationOfGoods.unLoCode;
    if (value?.addCusOffice?.cusOffice && value.addCusOffice.supervCusOffice)
      request['supervisingOfficeRefNum'] = value.addCusOffice.cusOffice
        .split('-')[0]
        .trim();
    if (value?.addCusOffice?.cusOffice && value.addCusOffice.cusOffOfPres)
      request['presentationOfficeRefNum'] = value.addCusOffice.cusOffice
        .split('-')[0]
        .trim();
    if (
      value?.addCusOffice?.cusOffice &&
      !value?.addCusOffice?.supervCusOffice &&
      !value?.addCusOffice?.cusOffOfPres
    ) {
      request['supervisingOfficeRefNum'] = value?.addCusOffice?.cusOffice
        .split('-')[0]
        .trim();
      request[
        'presentationOfficeRefNum'
      ] = value?.addCusOffice?.cusOffice.split('-')[0].trim();
    }

    return { ...request, ...this.setPartyData(value) };
  }

  setStatus(status) {
    const statusFilter: string[] = [];
    for (const element in status) {
      if (status[element]) {
        statusFilter.push(element);
      }
    }
    return statusFilter;
  }

  getInitialDate(date) {
    return date.split('T')[0] + 'T00:00:00.000Z';
  }

  getEndDate(date) {
    return date.split('T')[0] + 'T23:59:59.999Z';
  }
  setPartyData(value: AdvancedSearchParamForm) {
    const partyRequest = {};
    if (value?.parties?.eori && value?.parties?.declarant)
      partyRequest['declarant'] = value?.parties?.eori;
    if (value?.parties?.eori && value?.parties?.representative)
      partyRequest['representative'] = value?.parties?.eori;
    if (value?.parties?.eori && value?.parties?.carrier)
      partyRequest['carrier'] = value?.parties?.eori;
    if (value?.parties?.eori && value?.parties?.personPresGoods)
      partyRequest['personPresentingTheGoods'] = value?.parties?.eori;
    if (
      value?.parties?.eori &&
      !value?.parties?.declarant &&
      !value?.parties?.representative &&
      !value?.parties?.carrier &&
      !value?.parties?.personPresGoods
    ) {
      partyRequest['declarant'] = value?.parties?.eori;
      partyRequest['representative'] = value?.parties?.eori;
      partyRequest['carrier'] = value?.parties?.eori;
      partyRequest['personPresentingTheGoods'] = value?.parties?.eori;
    }
    return partyRequest;
  }
}
