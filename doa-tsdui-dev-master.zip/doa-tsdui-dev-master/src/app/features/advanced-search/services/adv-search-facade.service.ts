import { Injectable, Injector } from '@angular/core';
import { Params } from '@angular/router';
import { Observable } from 'rxjs';

import { AdvanceSearchParamService } from './adv-search-param.service';

@Injectable()
export class AdvSearchFacade {
  constructor(private injector: Injector) {}
  private advSearchParamServ: AdvanceSearchParamService;

  public get advSearchParamService(): AdvanceSearchParamService {
    if (!this.advSearchParamServ) {
      this.advSearchParamServ = this.injector.get(AdvanceSearchParamService);
    }
    return this.advSearchParamServ;
  }

  getAdvSearch(param: string, newSearch: boolean, isDraftAPICalled: boolean) {
    return this.advSearchParamService.getAdvSearch(
      param,
      newSearch,
      isDraftAPICalled
    );
  }

  getAdvSearchResult() {
    return this.advSearchParamService.getAdvSearchResult();
  }
  navigateToSearchParam(params: string) {
    return this.advSearchParamService.navigateToSearchParam(params);
  }
  navigateToConsultScreen(mrn: string) {
    return this.advSearchParamService.navigateToConsultScreen(mrn);
  }
  public get currentRouteParams(): Observable<Params> {
    return this.advSearchParamService.currentRouteParams;
  }

  initializeSearchParam() {
    return this.advSearchParamService.initializeSearchParam();
  }
}
