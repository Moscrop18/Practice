import { TestBed } from '@angular/core/testing';
import { Store } from '@ngrx/store';

import { AdvancedSearchParamForm } from '../models/adv-search-param-form';

import { AdvanceSearchRequestBuilderService } from './adv-search-request-builder.service';

describe('AdvanceSearchParamService', () => {
  let service: AdvanceSearchRequestBuilderService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AdvanceSearchRequestBuilderService,
        {
          provide: Store,
          useValue: {
            dispatch: jest.fn(),
            pipe: jest.fn()
          }
        }
      ]
    });
    service = TestBed.inject(AdvanceSearchRequestBuilderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('build request should be called', () => {
    const form: AdvancedSearchParamForm = {
      declarationInfo: {
        lrn: 'Test',
        registrationDateBefore: 'Date1',
        registrationDateAfter: 'Date2',
        presentationDateBefore: 'Test',
        presentationDateAfter: 'Test'
      },
      addCusOffice: {
        cusOffice: 'BE212000 - Zaventem D',
        supervCusOffice: true,
        cusOffOfPres: true
      },
      entryInformation: {
        arrivalTransMeansIdn: '1234'
      },
      parties: {
        eori: '1234',
        name: '',
        declarant: true,
        representative: true,
        carrier: true,
        personPresGoods: null
      },
      transportDocument: {
        refNum: '4567'
      },
      warehouseIdentifier: {
        identifier: '1234'
      },
      locationOfGoods: {
        unLoCode: 'UN/LOCODE'
      },
      containerOrRecep: {
        identifictionNo: '1234'
      },
      declarationStatus: {
        searchValue: {
          PreLodged: true,
          Accepted: null,
          IrregularityUnderInvestigation: true,
          Invalidated: null,
          UnderControl: null
        }
      },
      racStatus: {
        searchValue: {
          UnderControl: true,
          AwaitingRiskAnalysisResult: true,
          AwaitingRiskHitConfirmation: null,
          ControlResultRegistered: null,
          PreArrivalRiskAnalysisCompleted: null,
          PreArrivalRiskAnalysisCancelled: null,
          NoRisk: null
        }
      }
    };
    const req = service.buildRequest(form);
    expect(req).toBeDefined();
  });

  it('set status should be called', () => {
    const searchValue = {
      PreLodged: true,
      Accepted: true
    };
    const statusFilter = service.setStatus(searchValue);
    expect(statusFilter).toBeDefined();
  });
  it('build request do not create empty status', () => {
    const form: AdvancedSearchParamForm = {
      declarationInfo: {
        lrn: 'Test',
        registrationDateBefore: 'Date1',
        registrationDateAfter: 'Date2',
        presentationDateBefore: 'Test',
        presentationDateAfter: 'Test'
      },
      addCusOffice: {
        cusOffice: ''
      },
      entryInformation: {
        arrivalTransMeansIdn: '1234'
      },
      parties: {
        eori: '1234',
        name: '',
        declarant: true,
        representative: true,
        carrier: true,
        personPresGoods: null
      },
      transportDocument: {
        refNum: '4567'
      },
      containerOrRecep: {
        identifictionNo: '1234'
      },
      warehouseIdentifier: {
        identifier: '1234'
      },
      locationOfGoods: {
        unLoCode: 'UN/LOCODE'
      },
      declarationStatus: {
        searchValue: {
          PreLodged: null,
          Accepted: null,
          IrregularityUnderInvestigation: null,
          Invalidated: null,
          UnderControl: null
        }
      }
    };
    const statusFilter = service.setStatus(form.declarationStatus.searchValue);
    expect(statusFilter.length).toBeLessThan(1);
    const req = service.buildRequest(form);
    expect(req['status']).not.toBeDefined();
  });
  it('should  setPartyData with all when no checkbox selected', () => {
    const form: AdvancedSearchParamForm = {
      declarationInfo: {
        lrn: 'Test',
        registrationDateBefore: 'Date1',
        registrationDateAfter: 'Date2',
        presentationDateBefore: 'Test',
        presentationDateAfter: 'Test'
      },
      parties: {
        eori: 'BE01234567',
        name: 'Test',
        declarant: null,
        representative: null,
        carrier: null,
        personPresGoods: null
      }
    };
    const res = service.setPartyData(form);
    expect(res).toEqual({
      carrier: 'BE01234567',
      declarant: 'BE01234567',
      personPresentingTheGoods: 'BE01234567',
      representative: 'BE01234567'
    });
  });
  it('should call setPartyData with all', () => {
    const form: AdvancedSearchParamForm = {
      declarationInfo: {
        lrn: 'Test',
        registrationDateBefore: 'Date1',
        registrationDateAfter: 'Date2',
        presentationDateBefore: 'Test',
        presentationDateAfter: 'Test'
      },
      parties: {
        eori: 'BE01234567',
        name: 'Test',
        declarant: true,
        representative: true,
        carrier: true,
        personPresGoods: true
      }
    };
    const res = service.setPartyData(form);
    expect(res).toEqual({
      carrier: 'BE01234567',
      declarant: 'BE01234567',
      personPresentingTheGoods: 'BE01234567',
      representative: 'BE01234567'
    });
  });
});
