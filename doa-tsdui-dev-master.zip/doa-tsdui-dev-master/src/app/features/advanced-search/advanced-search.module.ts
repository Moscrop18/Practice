import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { codeListReducer } from '@core/gateways/codelist/store/reducer/code-list.reducer';
import { PipesModule } from '@core/pipes/pipes.module';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { TsdService } from '@features/edit-declaration/services/tsd.service';
import { InvRequestParamService } from '@features/manage-declaration/invalidation-dialog/services/invalidation-request-param.service';
import { ManageDeclarationModule } from '@features/manage-declaration/manage-declaration.module';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SharedModule } from '@shared/shared.module';
import { NgrxFormsModule } from 'ngrx-forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

import { AdvancedSearchRoutingModule } from './advanced-search-routing.module';
import { AdvancedSearchComponent } from './advanced-search.component';
import { SearchListComponent } from './search-list/container/search-list.component';
import { TsdActionComponent } from './search-list/presentation/tsd-action/tsd-action.component';
import { TsdListComponent } from './search-list/presentation/tsd-list/tsd-list.component';
import { AdvSearchResultEffects } from './search-list/store/effects/adv-search-result.effects';
import { advSearcResultReducer } from './search-list/store/reducers/adv-search-result.reducer';
import { SearchAddCustomsOfficeComponent } from './search-param/components/search-add-customs-office/search-add-customs-office.component';
import { SearchContainerOrRecComponent } from './search-param/components/search-container-or-rec/search-container-or-rec.component';
import { SearchDeclarationInfoComponent } from './search-param/components/search-declaration-info/search-declaration-info.component';
import { SearchDeclarationStatusComponent } from './search-param/components/search-declaration-status/search-declaration-status.component';
import { SearchEntryInformationComponent } from './search-param/components/search-entry-information/search-entry-information.component';
import { SearchLocationOfGoodsComponent } from './search-param/components/search-location-of-goods/search-location-of-goods.component';
import { SearchPartiesComponent } from './search-param/components/search-parties/search-parties.component';
import { SearchRacStatusComponent } from './search-param/components/search-rac-status/search-rac-status.component';
import { SearchTransportDocComponent } from './search-param/components/search-transport-doc/search-transport-doc.component';
import { SearchWarehouseIdentifierComponent } from './search-param/components/search-warehouse-identifier/search-warehouse-identifier.component';
import { SearchParamComponent } from './search-param/search-param.component';
import { SearchResultsComponent } from './search-results/search-results.component';
import { AdvSearchFacade } from './services/adv-search-facade.service';
import { AdvanceSearchParamService } from './services/adv-search-param.service';
import { AdvanceSearchRequestBuilderService } from './services/adv-search-request-builder.service';
import { AdvSearchParamEffects } from './store/effects/adv-search-param.effects';
import { advSearchParamReducer } from './store/reducers/adv-search-param.reducer';

@NgModule({
  declarations: [
    AdvancedSearchComponent,
    SearchResultsComponent,
    SearchListComponent,
    SearchParamComponent,
    SearchDeclarationInfoComponent,
    SearchAddCustomsOfficeComponent,
    SearchEntryInformationComponent,
    SearchPartiesComponent,
    SearchTransportDocComponent,
    SearchContainerOrRecComponent,
    SearchRacStatusComponent,
    SearchDeclarationStatusComponent,
    TsdListComponent,
    TsdActionComponent,
    SearchLocationOfGoodsComponent,
    SearchWarehouseIdentifierComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AdvancedSearchRoutingModule,
    FlexLayoutModule,
    NgxSkeletonLoaderModule,
    NgrxFormsModule,
    MaterialModule,
    ManageDeclarationModule,
    PipesModule,
    // HttpClientModule,
    StoreModule.forFeature('advSearchResult', advSearcResultReducer),
    StoreModule.forFeature('advSearchParam', advSearchParamReducer),
    StoreModule.forFeature('codeKey', codeListReducer),
    EffectsModule.forFeature([
      CodeListEffects,
      AdvSearchParamEffects,
      AdvSearchResultEffects
    ])
  ],
  providers: [
    AdvanceSearchParamService,
    ModuleLoadService,
    AdvanceSearchRequestBuilderService,
    InvRequestParamService,
    AdvSearchFacade,
    TsdService
  ]
})
export class AdvancedSearchModule {}
