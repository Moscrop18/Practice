/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AddressedCustomsOfficeCode } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { PlaceOfUnloadingCode } from '@core/gateways/codelist/model/place-of-unloading-code';
import { FormGroupState } from 'ngrx-forms';
import { Subject } from 'rxjs';

import { AdvancedSearchParamForm } from '../models/adv-search-param-form';
import { AdvSearchFacade } from '../services/adv-search-facade.service';

@Component({
  selector: 'app-search-param',
  templateUrl: './search-param.component.html',
  styleUrls: ['./search-param.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchParamComponent {
  @Input() customsOfficelist: AddressedCustomsOfficeCode[];
  @Input() locationOfGoods: PlaceOfUnloadingCode[];
  @Input() formState: FormGroupState<AdvancedSearchParamForm>;
  @Output() eoriChangeAction = new EventEmitter<{
    event: { eori: string };
  }>();
  @Output() validateUnloCodeEvent = new EventEmitter<string>();
  @Output() clearAllAction = new EventEmitter();
  @Output()
  clickAdvancedSearch: EventEmitter<AdvancedSearchParamForm> = new EventEmitter<AdvancedSearchParamForm>();
  @Output() statusCheckBoxClickedAction = new EventEmitter<{
    checked: boolean;
    status: string;
  }>();
  searchClickedEvent: Subject<any> = new Subject();
  noSearchResult: boolean;
  @Output() validateAddressedCustomsOfficeEvent = new EventEmitter<string>();
  constructor(
    private advSearchFacade: AdvSearchFacade,
    private activatedRoute: ActivatedRoute
  ) {
    this.advSearchFacade.initializeSearchParam();
    this.noSearchResult = this.activatedRoute.snapshot.queryParams.noSearchResult;
  }
  eoriChange(event: { eori: string }) {
    this.eoriChangeAction.emit({ event: event });
  }
  validateUnloCode(event: string): void {
    this.validateUnloCodeEvent.emit(event);
  }
  clearAll() {
    this.clearAllAction.emit();
  }
  submit() {
    this.searchClickedEvent.next('true');
    if (this.formState.isValid) {
      this.clickAdvancedSearch.emit(this.formState.value);
    }
  }
  validateAddressedCustomsOffice(event: any): void {
    this.validateAddressedCustomsOfficeEvent.emit(event);
  }
}
