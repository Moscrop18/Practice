/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable sonarjs/no-duplicate-string */
import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { CodeListEffects } from '@core/gateways/codelist/store/effects/code-list.effects';
import { ROOT_REDUCERS, metaReducers } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { MaterialModule } from '@material/material.module';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';

import { AdvancedSearchModule } from '../advanced-search.module';
import { AdvancedSearchParamForm } from '../models/adv-search-param-form';
import { AdvSearchFacade } from '../services/adv-search-facade.service';
import { AdvanceSearchParamService } from '../services/adv-search-param.service';
import { AdvanceSearchRequestBuilderService } from '../services/adv-search-request-builder.service';
import { AdvSearchParamEffects } from '../store/effects/adv-search-param.effects';
import { advSearchParamReducer } from '../store/reducers/adv-search-param.reducer';

import { SearchAddCustomsOfficeComponent } from './components/search-add-customs-office/search-add-customs-office.component';
import { SearchContainerOrRecComponent } from './components/search-container-or-rec/search-container-or-rec.component';
import { SearchDeclarationInfoComponent } from './components/search-declaration-info/search-declaration-info.component';
import { SearchDeclarationStatusComponent } from './components/search-declaration-status/search-declaration-status.component';
import { SearchEntryInformationComponent } from './components/search-entry-information/search-entry-information.component';
import { SearchPartiesComponent } from './components/search-parties/search-parties.component';
import { SearchTransportDocComponent } from './components/search-transport-doc/search-transport-doc.component';
import { SearchParamComponent } from './search-param.component';

describe('SearchListComponent', () => {
  let component: SearchParamComponent;
  let fixture: ComponentFixture<SearchParamComponent>;
  let rootElement: DebugElement;
  let facade: AdvSearchFacade;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [],
      imports: [
        MaterialModule,
        NoopAnimationsModule,
        AdvancedSearchModule,
        RouterTestingModule,
        HttpClientModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          metaReducers,
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true,
            strictStateSerializability: true,
            strictActionSerializability: true
          }
        }),
        EffectsModule.forRoot([AdvSearchParamEffects]),
        TranslateModule.forRoot()
      ],
      providers: [ConfigService, AdvanceSearchParamService]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchParamComponent);
    component = fixture.componentInstance;
    component.customsOfficelist = [];
    const INITIAL_STATE = createFormGroupState<AdvancedSearchParamForm>(
      'advSearchForm',
      {
        declarationInfo: {
          lrn: '',
          registrationDateBefore: null,
          registrationDateAfter: null,
          presentationDateBefore: null,
          presentationDateAfter: null
        },
        addCusOffice: {
          cusOffice: '',
          supervCusOffice: null,
          cusOffOfPres: null
        },
        entryInformation: {
          arrivalTransMeansIdn: ''
        },
        parties: {
          eori: '',
          name: '',
          declarant: null,
          representative: null,
          carrier: null,
          personPresGoods: null
        },
        transportDocument: {
          refNum: ''
        },
        locationOfGoods: {
          unLoCode: ''
        },
        warehouseIdentifier: {
          identifier: ''
        },
        containerOrRecep: {
          identifictionNo: ''
        },
        declarationStatus: {
          searchValue: {
            PreLodged: null,
            Accepted: null,
            IrregularityUnderInvestigation: null,
            Invalidated: null,
            UnderControl: null
          }
        },
        racStatus: {
          searchValue: {
            UnderControl: null,
            AwaitingRiskAnalysisResult: null,
            AwaitingRiskHitConfirmation: null,
            ControlResultRegistered: null,
            PreArrivalRiskAnalysisCompleted: null,
            PreArrivalRiskAnalysisCancelled: null,
            NoRisk: null
          }
        }
      }
    );
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call Clear button', () => {
    const addSection = rootElement.query(By.css('#clearAll'));
    addSection.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.clearAll).toHaveBeenCalled());
  });

  it('Should call Submit button', () => {
    const saveButton = rootElement.query(By.css('[data-testid=search]'));
    saveButton.nativeElement.dispatchEvent(new MouseEvent('click'));
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.submit).toHaveBeenCalled());
  });
  it('should test eoriChange', () => {
    const spy = jest.spyOn(component.eoriChangeAction, 'emit');
    component.eoriChange({ eori: '' });
    expect(spy).toHaveBeenCalled();
  });
});
