import { Component, Input, OnInit } from '@angular/core';
import { SearchTransportDocument } from '@features/advanced-search/models/search-trans-doc';
import { FormState } from 'ngrx-forms';
@Component({
  selector: 'app-search-transport-doc',
  templateUrl: './search-transport-doc.component.html'
})
export class SearchTransportDocComponent {
  @Input() formState: FormState<SearchTransportDocument>;
}
