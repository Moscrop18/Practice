import { DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchLocationOfGoods } from '@features/advanced-search/models/search-location-goods';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { createFormGroupState } from 'ngrx-forms';

import { SearchLocationOfGoodsComponent } from './search-location-of-goods.component';

describe('SearchLocationOfGoodsComponent', () => {
  let component: SearchLocationOfGoodsComponent;
  let fixture: ComponentFixture<SearchLocationOfGoodsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [SearchLocationOfGoodsComponent],
      imports: [MaterialModule, NoopAnimationsModule, TranslateModule.forRoot()]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchLocationOfGoodsComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchLocationOfGoods>(
      'searchLocationOfGoods',
      {
        unLoCode: ''
      }
    );
    component.formState = INITIAL_STATE;
    component.locationOfGoods = [
      { 'id': 0, 'value': 'BE212000', 'definition': 'Zaventem D1' }
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if formState is available or not', () => {
    expect(component.formState).toBeTruthy();
  });

  it('Should test validateUnloCode', () => {
    const spy = jest.spyOn(component.validateUnloCodeEvent, 'emit');

    const selectionValue = 'BE212000-Zaventem D1';
    component.validateUnloCode(selectionValue);
    expect(spy).toHaveBeenCalledWith({
      'codeList': ['BE212000 - Zaventem D1'],
      'value': 'BE212000-Zaventem D1'
    });
  });

  it('should call filterUnLocde with value', () => {
    const INITIAL_STATE = createFormGroupState<SearchLocationOfGoods>(
      'locationOfGoods',
      {
        unLoCode: 'BE212000'
      }
    );
    component.formState = INITIAL_STATE;
    component.filterUnLocde();
    expect(component.placeOfUnloadingOptions).toEqual([
      {
        'id': 0,
        'value': 'BE212000',
        'definition': 'Zaventem D1'
      }
    ]);
  });

  it('should call filterUnLocde without value', () => {
    const INITIAL_STATE = createFormGroupState<SearchLocationOfGoods>(
      'locationOfGoods',
      {
        unLoCode: 'ABC'
      }
    );
    component.formState = INITIAL_STATE;
    component.filterUnLocde();
    expect(component.placeOfUnloadingOptions).toEqual([]);
  });
});
