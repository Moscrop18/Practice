import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input
} from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { SearchDeclarationInformation } from '@features/advanced-search/models/search-dec-info';
import { dateValueConverter } from '@shared/converters/date-converter';
import { MY_DATE_FORMATS } from '@shared/converters/date-format';
import { FormState, NgrxValueConverter } from 'ngrx-forms';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-search-declaration-info',
  templateUrl: './search-declaration-info.component.html',
  styleUrls: ['./search-declaration-info.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [{ provide: MAT_DATE_FORMATS, useValue: MY_DATE_FORMATS }]
})
export class SearchDeclarationInfoComponent {
  @Input() formState: FormState<SearchDeclarationInformation>;
  searchClicked = false;
  @Input() searchClickedEvent: Subject<any>;
  constructor(private el: ElementRef, private fb: FormBuilder) {
    // empty
  }
  dateValueConverter: NgrxValueConverter<
    Date | null,
    string | null
  > = dateValueConverter;

  ngOnInit() {
    this.searchClickedEvent.subscribe((event) => {
      this.searchClicked = true;
    });
  }
}
