import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchContainerOrRecep } from '@features/advanced-search/models/search-container-rec';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchContainerOrRecComponent } from './search-container-or-rec.component';

describe('SearchContainerOrRecComponent', () => {
  let component: SearchContainerOrRecComponent;
  let fixture: ComponentFixture<SearchContainerOrRecComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchContainerOrRecComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchContainerOrRecComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchContainerOrRecep>(
      'searchContainerOrRecep',
      {
        identifictionNo: ''
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
