import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges
} from '@angular/core';
import { PlaceOfUnloadingCode } from '@core/gateways/codelist/model/place-of-unloading-code';
import { SearchLocationOfGoods } from '@features/advanced-search/models/search-location-goods';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-location-of-goods',
  templateUrl: './search-location-of-goods.component.html'
})
export class SearchLocationOfGoodsComponent {
  @Input() formState: FormState<SearchLocationOfGoods>;
  @Input() locationOfGoods: PlaceOfUnloadingCode[];
  @Output() validateUnloCodeEvent = new EventEmitter<{
    value: string;
    codeList: string[];
  }>();
  placeOfUnloadingOptions: PlaceOfUnloadingCode[];

  getOptionList(): void {
    this.placeOfUnloadingOptions = this.locationOfGoods;
  }

  validateUnloCode(selectedValue: string): void {
    const resultArray: string[] = [];
    this.locationOfGoods.forEach((code) => {
      resultArray.push(code?.value + ' - ' + code?.definition);
    });
    this.validateUnloCodeEvent.emit({
      value: selectedValue,
      codeList: resultArray
    });
  }

  filterUnLocde(): void {
    this.placeOfUnloadingOptions = this.locationOfGoods.filter(
      (option) =>
        option?.value
          ?.toLowerCase()
          .includes(this.formState.controls.unLoCode.value.toLowerCase()) ||
        option?.definition
          ?.toLowerCase()
          .includes(this.formState.controls.unLoCode.value.toLowerCase())
    );
  }
}
