import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchEntryInformation } from '@features/advanced-search/models/search-entry-info';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchEntryInformationComponent } from './search-entry-information.component';

describe('SearchEntryInformationComponent', () => {
  let component: SearchEntryInformationComponent;
  let fixture: ComponentFixture<SearchEntryInformationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchEntryInformationComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchEntryInformationComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchEntryInformation>(
      'searchEntryInfo',
      {
        arrivalTransMeansIdn: ''
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
