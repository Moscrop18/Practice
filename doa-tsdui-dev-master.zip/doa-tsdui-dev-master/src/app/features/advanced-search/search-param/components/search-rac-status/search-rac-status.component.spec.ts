/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchRacStatus } from '@features/advanced-search/models/search-rac-status';
import { MaterialModule } from '@material/material.module';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchRacStatusComponent } from './search-rac-status.component';

describe('SearchRacStatusComponent', () => {
  let component: SearchRacStatusComponent;
  let fixture: ComponentFixture<SearchRacStatusComponent>;
  let translate: TranslateService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchRacStatusComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchRacStatusComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchRacStatus>(
      'searchDecStatus',
      {
        x: [],
        searchValue: {
          UnderControl: true,
          AwaitingRiskAnalysisResult: true,
          AwaitingRiskHitConfirmation: null,
          ControlResultRegistered: null,
          PreArrivalRiskAnalysisCompleted: null,
          PreArrivalRiskAnalysisCancelled: null,
          NoRisk: null
        }
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should test checkClicked', () => {
    const spy = jest.spyOn(component, 'getState');
    component.checkClicked({ source: { id: 1 } });
    expect(spy).toHaveBeenCalled();
  });
});
