import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchTransportDocument } from '@features/advanced-search/models/search-trans-doc';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchTransportDocComponent } from './search-transport-doc.component';

describe('SearchTransportDocComponent', () => {
  let component: SearchTransportDocComponent;
  let fixture: ComponentFixture<SearchTransportDocComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchTransportDocComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchTransportDocComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchTransportDocument>(
      'searchTranspdoc',
      {
        refNum: ''
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
