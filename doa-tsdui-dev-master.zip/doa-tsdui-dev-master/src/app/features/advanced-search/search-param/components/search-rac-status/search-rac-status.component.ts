/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

import { Component, Input } from '@angular/core';
import { SearchRacStatus } from '@features/advanced-search/models/search-rac-status';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-rac-status',
  templateUrl: './search-rac-status.component.html'
})
export class SearchRacStatusComponent {
  @Input() formState: FormState<SearchRacStatus>;
  statusList = [
    'UnderControl',
    'AwaitingRiskAnalysisResult',
    'AwaitingRiskHitConfirmation',
    'ControlResultRegistered',
    'PreArrivalRiskAnalysisCompleted',
    'PreArrivalRiskAnalysisCancelled',
    'NoRisk'
  ];
  getState(status: string): any {
    switch (status) {
      case 'UnderControl':
        return this.formState.controls.searchValue.controls.UnderControl;
      case 'AwaitingRiskAnalysisResult':
        return this.formState.controls.searchValue.controls
          .AwaitingRiskAnalysisResult;
      case 'AwaitingRiskHitConfirmation':
        return this.formState.controls.searchValue.controls
          .AwaitingRiskHitConfirmation;
      case 'ControlResultRegistered':
        return this.formState.controls.searchValue.controls
          .ControlResultRegistered;
      case 'PreArrivalRiskAnalysisCompleted':
        return this.formState.controls.searchValue.controls
          .PreArrivalRiskAnalysisCompleted;
      case 'PreArrivalRiskAnalysisCancelled':
        return this.formState.controls.searchValue.controls
          .PreArrivalRiskAnalysisCancelled;
      case 'NoRisk':
        return this.formState.controls.searchValue.controls.NoRisk;
    }
  }
  checkClicked(event) {
    this.getState(event.source.id);
  }
}
