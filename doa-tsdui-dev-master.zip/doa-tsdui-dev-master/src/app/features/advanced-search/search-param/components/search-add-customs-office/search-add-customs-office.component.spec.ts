import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchAddCustomsOffice } from '@features/advanced-search/models/search-add-cus-office';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchAddCustomsOfficeComponent } from './search-add-customs-office.component';

describe('SearchAddCustomsOfficeComponent', () => {
  let component: SearchAddCustomsOfficeComponent;
  let fixture: ComponentFixture<SearchAddCustomsOfficeComponent>;
  let rootElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchAddCustomsOfficeComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchAddCustomsOfficeComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchAddCustomsOffice>(
      'addCudOffice',
      {
        cusOffice: 'BE212001',
        supervCusOffice: true,
        cusOffOfPres: true
      }
    );
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngOnChanges and set optional menu item', () => {
    component.customsOfficelist = [
      {
        'id': 0,
        'value': 'BE212000',
        'definition': 'Zaventem D'
      }
    ];
    component.ngOnChanges(null);
    expect(component.customsOfficelist).toHaveLength(2);
  });
  it('should call validateAddressedCustomsOffice', () => {
    const spy = jest.spyOn(
      component.validateAddressedCustomsOfficeEvent,
      'emit'
    );
    component.customsOfficelist = [
      {
        'id': 0,
        'value': 'BE212000',
        'definition': 'Zaventem D1'
      }
    ];
    component.validateAddressedCustomsOffice('BE212000');
    fixture.detectChanges();
    expect(spy).toHaveBeenCalledWith({
      value: 'BE212000',
      codeList: ['BE212000 - Zaventem D1']
    });
  });

  it('should call filterAddressedCustomsOffice', () => {
    component.customsOfficelist = [
      {
        'id': 0,
        'value': 'BE212000',
        'definition': 'Zaventem D2'
      },
      {
        'id': 1,
        'value': 'BE212001',
        'definition': 'Zaventem D3'
      }
    ];
    const INITIAL_STATE = createFormGroupState<SearchAddCustomsOffice>(
      'addCudOffice',
      {
        cusOffice: 'BE212001',
        supervCusOffice: true,
        cusOffOfPres: true
      }
    );
    component.formState = INITIAL_STATE;
    component.filterAddressedCustomsOffice();
    fixture.detectChanges();
    expect(component.fieldOptionAddressedCustomsOffice).toHaveLength(1);
  });
});
