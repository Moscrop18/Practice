/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable sonarjs/no-duplicate-string */
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchParties } from '@features/advanced-search/models/search-parties';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchPartiesComponent } from './search-parties.component';

describe('SearchPartiesComponent', () => {
  let component: SearchPartiesComponent;
  let fixture: ComponentFixture<SearchPartiesComponent>;
  let rootElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchPartiesComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchPartiesComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchParties>('searchParties', {
      eori: '',
      name: '',
      declarant: true,
      representative: true,
      carrier: true,
      personPresGoods: true
    });
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should call eorionFocusout', () => {
    const INITIAL_STATE = createFormGroupState<SearchParties>('searchParties', {
      eori: '',
      name: '',
      declarant: true,
      representative: true,
      carrier: true,
      personPresGoods: true
    });
    component.formState = INITIAL_STATE;
    rootElement = fixture.debugElement;
    fixture.detectChanges();
    const input = rootElement.query(By.css('#ascaEori'));
    input.nativeElement.dispatchEvent(
      new FocusEvent('focusout', { detail: 0 })
    );
    fixture.detectChanges();
    fixture
      .whenStable()
      .then(() => expect(component.eoriOnFocusOut).toHaveBeenCalled());
  });
});
