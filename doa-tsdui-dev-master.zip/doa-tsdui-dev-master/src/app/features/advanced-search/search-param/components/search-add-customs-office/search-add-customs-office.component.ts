import {
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges
} from '@angular/core';
import { AddressedCustomsOfficeCode } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { SearchAddCustomsOffice } from '@features/advanced-search/models/search-add-cus-office';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-add-customs-office',
  templateUrl: './search-add-customs-office.component.html'
})
export class SearchAddCustomsOfficeComponent implements OnChanges {
  @Input() formState: FormState<SearchAddCustomsOffice>;
  @Input() customsOfficelist: AddressedCustomsOfficeCode[];
  @Output() validateAddressedCustomsOfficeEvent = new EventEmitter<{
    value: string;
    codeList: string[];
  }>();
  fieldOptionAddressedCustomsOffice: AddressedCustomsOfficeCode[];
  ngOnChanges(changes: SimpleChanges): void {
    if (this.customsOfficelist && this.customsOfficelist.length > 0) {
      const addressedCustomsOfficeCode: AddressedCustomsOfficeCode = {
        id: -1,
        value: null,
        definition: null
      };
      const index = this.customsOfficelist.findIndex(
        (x) =>
          x.definition === addressedCustomsOfficeCode.definition ||
          x.value === addressedCustomsOfficeCode.value
      );
      if (index === -1)
        this.customsOfficelist.unshift(addressedCustomsOfficeCode);
    }
  }
  validateAddressedCustomsOffice(selectedValue: string): void {
    const customsOfficeCodesList: string[] = [];
    this.customsOfficelist.forEach((code) => {
      customsOfficeCodesList.push(code.value + ' - ' + code.definition);
    });
    this.validateAddressedCustomsOfficeEvent.emit({
      value: selectedValue,
      codeList: customsOfficeCodesList
    });
  }

  filterAddressedCustomsOffice(): void {
    this.fieldOptionAddressedCustomsOffice = this.customsOfficelist.filter(
      (option) =>
        option?.value
          ?.toLowerCase()
          .includes(this.formState.controls.cusOffice.value.toLowerCase()) ||
        option?.definition
          ?.toLowerCase()
          .includes(this.formState.controls.cusOffice.value.toLowerCase())
    );
  }
}
