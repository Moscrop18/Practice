import { Component, Input, OnInit } from '@angular/core';
import { SearchContainerOrRecep } from '@features/advanced-search/models/search-container-rec';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-container-or-rec',
  templateUrl: './search-container-or-rec.component.html'
})
export class SearchContainerOrRecComponent {
  @Input() formState: FormState<SearchContainerOrRecep>;
}
