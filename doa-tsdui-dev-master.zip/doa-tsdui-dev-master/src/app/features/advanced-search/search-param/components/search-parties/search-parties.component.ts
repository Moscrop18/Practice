/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { SearchParties } from '@features/advanced-search/models/search-parties';
import { EORIChange } from '@features/edit-declaration/models';
import { FormGroupState, FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-parties',
  templateUrl: './search-parties.component.html'
})
export class SearchPartiesComponent implements OnInit {
  @Input() formState: FormGroupState<SearchParties>;
  @Output() eoriChangeAction = new EventEmitter<EORIChange>();
  checkList = ['declarant', 'representative', 'carrier', 'personPresGoods'];
  getState(status: string): any {
    switch (status) {
      case 'declarant':
        return this.formState.controls.declarant;
      case 'representative':
        return this.formState.controls.representative;
      case 'carrier':
        return this.formState.controls.carrier;
      case 'personPresGoods':
        return this.formState.controls.personPresGoods;
    }
  }
  checkClicked(event) {
    this.getState(event.source.id);
  }
  eoriOnFocusOut(eori): void {
    this.eoriChangeAction.emit({ eori: eori.value });
  }
  ngOnInit(): void {
    if (this?.formState?.controls?.eori.value) {
      this.eoriChangeAction.emit({
        eori: this?.formState?.controls?.eori.value
      });
    }
  }
}
