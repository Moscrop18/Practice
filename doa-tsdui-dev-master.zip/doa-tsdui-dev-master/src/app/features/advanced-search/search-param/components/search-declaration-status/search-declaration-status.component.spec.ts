import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchDeclarationStatus } from '@features/advanced-search/models/search-dec-status';
import { MaterialModule } from '@material/material.module';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState } from 'ngrx-forms';

import { SearchDeclarationStatusComponent } from './search-declaration-status.component';

describe('SearchDeclarationStatusComponent', () => {
  let component: SearchDeclarationStatusComponent;
  let fixture: ComponentFixture<SearchDeclarationStatusComponent>;
  let translate: TranslateService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchDeclarationStatusComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchDeclarationStatusComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchDeclarationStatus>(
      'searchDecStatus',
      {
        x: [],
        searchValue: {
          PreLodged: true,
          Accepted: true,
          IrregularityUnderInvestigation: true,
          Invalidated: true,
          UnderControl: true
        }
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
