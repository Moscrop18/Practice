import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchWarehouseIdentifier } from '@features/advanced-search/models/search-warehouse-identifier';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { createFormGroupState } from 'ngrx-forms';

import { SearchWarehouseIdentifierComponent } from './search-warehouse-identifier.component';

describe('SearchWarehouseIdentifierComponent', () => {
  let component: SearchWarehouseIdentifierComponent;
  let fixture: ComponentFixture<SearchWarehouseIdentifierComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [SearchWarehouseIdentifierComponent],
      imports: [MaterialModule, NoopAnimationsModule, TranslateModule.forRoot()]
    });
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchWarehouseIdentifierComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchWarehouseIdentifier>(
      'searchLocationOfGoods',
      {
        identifier: ''
      }
    );
    component.formState = INITIAL_STATE;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check if formState is available or not', () => {
    expect(component.formState).toBeTruthy();
  });
});
