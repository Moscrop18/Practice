import { Component, Input, OnInit } from '@angular/core';
import { SearchWarehouseIdentifier } from '@features/advanced-search/models/search-warehouse-identifier';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-warehouse-identifier',
  templateUrl: './search-warehouse-identifier.component.html'
})
export class SearchWarehouseIdentifierComponent {
  @Input() formState: FormState<SearchWarehouseIdentifier>;
}
