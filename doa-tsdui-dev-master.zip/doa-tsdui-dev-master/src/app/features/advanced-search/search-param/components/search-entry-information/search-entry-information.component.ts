import { Component, Input, OnInit } from '@angular/core';
import { SearchEntryInformation } from '@features/advanced-search/models/search-entry-info';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-entry-information',
  templateUrl: './search-entry-information.component.html'
})
export class SearchEntryInformationComponent {
  @Input() formState: FormState<SearchEntryInformation>;
}
