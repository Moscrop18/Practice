/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

import { Component, Input } from '@angular/core';
import { SearchDeclarationStatus } from '@features/advanced-search/models/search-dec-status';
import { FormState } from 'ngrx-forms';

@Component({
  selector: 'app-search-declaration-status',
  templateUrl: './search-declaration-status.component.html'
})
export class SearchDeclarationStatusComponent {
  @Input() formState: FormState<SearchDeclarationStatus>;
  statusList = [
    'PreLodged',
    'Accepted',
    'IrregularityUnderInvestigation',
    'Invalidated',
    'UnderControl'
  ];
  getState(status: string): any {
    switch (status) {
      case 'PreLodged':
        return this.formState.controls.searchValue.controls.PreLodged;
      case 'Accepted':
        return this.formState.controls.searchValue.controls.Accepted;
      case 'Invalidated':
        return this.formState.controls.searchValue.controls.Invalidated;
      case 'IrregularityUnderInvestigation':
        return this.formState.controls.searchValue.controls
          .IrregularityUnderInvestigation;
      case 'UnderControl':
        return this.formState.controls.searchValue.controls.UnderControl;
    }
  }
  checkClicked(event) {
    this.getState(event.source.id);
  }
}
