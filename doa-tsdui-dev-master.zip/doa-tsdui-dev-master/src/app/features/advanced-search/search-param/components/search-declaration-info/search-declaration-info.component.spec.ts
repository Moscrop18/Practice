/* eslint-disable @typescript-eslint/no-unsafe-call */
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { SearchDeclarationInformation } from '@features/advanced-search/models/search-dec-info';
import { MaterialModule } from '@material/material.module';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { createFormGroupState, NgrxFormsModule } from 'ngrx-forms';
import { Subject, Observable } from 'rxjs';

import { SearchDeclarationInfoComponent } from './search-declaration-info.component';

describe('SearchDeclarationInfoComponent', () => {
  let component: SearchDeclarationInfoComponent;
  let fixture: ComponentFixture<SearchDeclarationInfoComponent>;
  let translate: TranslateService;
  let rootElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchDeclarationInfoComponent],
      imports: [
        SharedModule,
        MaterialModule,
        NgrxFormsModule,
        NoopAnimationsModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    translate = TestBed.inject(TranslateService);
    fixture = TestBed.createComponent(SearchDeclarationInfoComponent);
    component = fixture.componentInstance;
    const INITIAL_STATE = createFormGroupState<SearchDeclarationInformation>(
      'searchDecInfo',
      {
        lrn: '',
        registrationDateBefore: '',
        registrationDateAfter: '',
        presentationDateBefore: '',
        presentationDateAfter: ''
      }
    );
    component.formState = INITIAL_STATE;
    component.searchClickedEvent = new Subject<any>();
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
