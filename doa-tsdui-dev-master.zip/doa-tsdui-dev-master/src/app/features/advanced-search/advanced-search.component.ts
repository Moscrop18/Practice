/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */

import { ChangeDetectionStrategy, Component } from '@angular/core';
import { AddressedCustomsOfficeCode } from '@core/gateways/codelist/model/addressed-customs-office-code';
import { PlaceOfUnloadingCode } from '@core/gateways/codelist/model/place-of-unloading-code';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { FormGroupState } from 'ngrx-forms';
import { Observable } from 'rxjs';

import { AdvancedSearchParamForm } from './models/adv-search-param-form';
import { AdvanceSearchParamService } from './services/adv-search-param.service';

@Component({
  selector: 'app-advanced-search',
  templateUrl: './advanced-search.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AdvancedSearchComponent {
  formState$: Observable<FormGroupState<AdvancedSearchParamForm>>;
  addressedCustomsOfficeCodes$: Observable<AddressedCustomsOfficeCode[]>;
  placeOfUnloadingCodes$: Observable<PlaceOfUnloadingCode[]>;
  constructor(
    private advanceSearchParamService: AdvanceSearchParamService,
    private moduleLoad: ModuleLoadService
  ) {
    this.formState$ = this.advanceSearchParamService.getFormState();
    this.advanceSearchParamService.dispatchFetchCodeListDataAction();
    this.addressedCustomsOfficeCodes$ = this.advanceSearchParamService.getAddressedCustomsOfficeCodes();
    this.placeOfUnloadingCodes$ = this.advanceSearchParamService.getPlaceOfUnloadingCodes();
  }

  ngOnInit() {
    this.moduleLoad.isErrorPage(false);
  }

  eoriChange(event) {
    this.advanceSearchParamService.getDeclarantForEori(event.event.eori);
  }
  clearAllForm() {
    this.advanceSearchParamService.clearForm();
  }

  clickAdvancedSearch(value: AdvancedSearchParamForm) {
    this.advanceSearchParamService.submitForm(value);
  }

  validateUnloCode(event: any) {
    this.advanceSearchParamService.validateUnloCode(
      event.value,
      event.codeList
    );
  }
  validateAddressedCustomsOffice(event: any) {
    this.advanceSearchParamService.validateAddressedCustomsOffice(
      event.value,
      event.codeList
    );
  }
}
