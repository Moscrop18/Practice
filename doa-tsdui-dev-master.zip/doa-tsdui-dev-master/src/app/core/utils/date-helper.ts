import { Injectable } from '@angular/core';

/**
 * This Service handles how the date is represented in scripts i.e. ngModel.
 */
@Injectable({ providedIn: 'root' })
export class CustomAdapter {
  readonly DELIMITER = '-';
}

/**
 * This Service handles how the date is rendered and parsed from keyboard i.e. in the bound input field.
 */
@Injectable({ providedIn: 'root' })
export class CustomDateParserFormatter {
  readonly DELIMITER = '/';
}
