/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClientModule } from '@angular/common/http';
import { inject, TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { OIDCTokenHandler } from '@core/components/auth/oidc-token-handler';
import * as fromAuth from '@core/components/auth/store/reducers/auth.reducer';
import { selectIsLoggedIn } from '@core/components/auth/store/selectors/auth.selectors';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { environment } from '@environments/environment';
import { StoreModule, MemoizedSelector } from '@ngrx/store';
import { provideMockStore, MockStore } from '@ngrx/store/testing';
import { cold } from 'jasmine-marbles';

import { AuthGuard } from './auth.guard';

describe('AuthGuard', () => {
  let guard: AuthGuard;
  let store: MockStore;
  let loggedIn: MemoizedSelector<fromAuth.AuthState, boolean>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AuthGuard,
        provideMockStore(),
        OIDCTokenHandler,
        ConfigService
      ],
      imports: [
        HttpClientModule,
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ]
    });
    store = TestBed.inject(MockStore);
    guard = TestBed.inject(AuthGuard);
    loggedIn = store.overrideSelector(selectIsLoggedIn, false);
  });

  it('AuthGuard should be created', inject([AuthGuard], (guard: AuthGuard) => {
    expect(guard).toBeTruthy();
  }));
  it('AuthGuard canActivate should be called', inject(
    [AuthGuard],
    (guard: AuthGuard) => {
      const state: RouterStateSnapshot = {
        url: '/edit-declaration',
        root: null
      };
      const route: ActivatedRouteSnapshot = null;
      expect(guard.canActivate(route, state)).toBeDefined();
    }
  ));
  it('AuthGuard canActivate should be called with demoMode true and URL', inject(
    [AuthGuard],
    (guard: AuthGuard) => {
      const expected = cold('(a)', { a: false });
      const state: RouterStateSnapshot = {
        url: '/',
        root: null
      };
      const configSpy = jest.spyOn(guard['configService'], 'getConfig');
      const configSettings = environment;
      configSpy.mockReturnValueOnce(configSettings);
      const route: ActivatedRouteSnapshot = null;
      loggedIn.setResult(false);
      expect(guard.canActivate(route, state)).toBeObservable(expected);
    }
  ));
  it('AuthGuard canActivate should be called with demoMode true and no URL', inject(
    [AuthGuard],
    (guard: AuthGuard) => {
      const expected = cold('(a)', { a: false });
      const state: RouterStateSnapshot = {
        url: null,
        root: null
      };
      const configSpy = jest.spyOn(guard['configService'], 'getConfig');
      const configSettings = environment;
      configSpy.mockReturnValueOnce(configSettings);
      const route: ActivatedRouteSnapshot = null;
      loggedIn.setResult(false);
      expect(guard.canActivate(route, state)).toBeObservable(expected);
    }
  ));
  it('AuthGuard canActivate should be called true', inject(
    [AuthGuard],
    (guard: AuthGuard) => {
      const expected = cold('(a)', { a: true });
      const state: RouterStateSnapshot = null;
      const route: ActivatedRouteSnapshot = null;
      loggedIn.setResult(true);
      expect(guard.canActivate(route, state)).toBeObservable(expected);
    }
  ));
  it('AuthGuard canActivate should be called with autoLogon', inject(
    [AuthGuard],
    (guard: AuthGuard) => {
      const state: RouterStateSnapshot = {
        url: null,
        root: null
      };
      const configSpy = jest.spyOn(guard['configService'], 'getConfig');
      const configSettings = { ...environment, demoMode: false };
      configSpy.mockReturnValueOnce(configSettings);
      const route: ActivatedRouteSnapshot = null;
      loggedIn.setResult(false);
      expect(guard.canActivate(route, state)).toBeDefined();
    }
  ));
});
