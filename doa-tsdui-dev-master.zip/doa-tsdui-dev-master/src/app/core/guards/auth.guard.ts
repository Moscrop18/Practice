/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  RouterStateSnapshot
} from '@angular/router';
import { OIDCTokenHandler } from '@core/components/auth/oidc-token-handler';
import { autoLogon } from '@core/components/auth/store/actions/auth.actions';
import { AuthState } from '@core/components/auth/store/reducers';
import { selectIsLoggedIn } from '@core/components/auth/store/selectors/auth.selectors';
import { ConfigService } from '@core/services/config/config.service';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(
    private store: Store<AuthState>,
    private tokenHandler: OIDCTokenHandler,
    private configService: ConfigService
  ) {}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<boolean> {
    return this.store.pipe(
      select(selectIsLoggedIn),
      map((isLoggedIn) => {
        if (isLoggedIn) {
          return true;
        } else {
          if (!this.configService.getConfig().demoMode) {
            this.store.dispatch(
              autoLogon({
                user: this.tokenHandler.getUserInfo(),
                returnUrl: state?.url ? state?.url : '/'
              })
            );
            return true;
          } else {
            this.store.dispatch(
              autoLogon({
                user: {},
                returnUrl: state?.url ? state?.url : '/'
              })
            );
            return false;
          }
        }
      })
    );
  }
}
