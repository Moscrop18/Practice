import { TestBed } from '@angular/core/testing';
import { CoreModule } from '@core/core.module';

import { EditDeclarationFacade } from '../features/edit-declaration/services/edit-declaration.facade';

describe(`CoreModule.forRoot()`, () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [CoreModule.forRoot()]
    });
  });

  it(`should not provide 'EditDeclarationFacade' service`, () => {
    expect(() => TestBed.inject(EditDeclarationFacade)).toBeTruthy();
  });
});
