/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { User, Credentials } from '@core/models/user';
import * as faker from 'faker/locale/en_US';

export const generateUser = (): User => {
  return {
    name: faker.name.firstName(),
    token: faker.random.alphaNumeric()
  };
};

export const generateValidCredential = (): Credentials => {
  return {
    username: 'admin',
    password: 'admin'
  };
};

export const generateInvalidCredential = (): Credentials => {
  return {
    username: 'InvalidUser',
    password: 'InvalidPassword'
  };
};
