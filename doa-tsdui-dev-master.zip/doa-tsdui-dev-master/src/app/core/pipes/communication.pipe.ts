import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'customCommunication'
})
export class CustomCommunication implements PipeTransform {
  public transform(value: string): string {
    let comm: string = null;
    if (value !== '' || value !== undefined || value !== null) {
      if (value === 'EM') {
        comm = 'E-mail address';
      } else if (value === 'TE') {
        comm = 'Phone number';
      }
    }
    return comm;
  }
}
