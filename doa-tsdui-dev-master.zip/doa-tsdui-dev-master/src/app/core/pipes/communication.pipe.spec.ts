import { CustomCommunication } from './communication.pipe';

describe('CustomCommunication', () => {
  it('create an instance', () => {
    const pipe = new CustomCommunication();
    expect(pipe).toBeTruthy();
  });

  it('call transform for EM', () => {
    const pipe = new CustomCommunication();
    const exp: string = pipe.transform('EM');
    expect(exp).toEqual('E-mail address');
  });

  it('call transform for TE', () => {
    const pipe = new CustomCommunication();
    const exp: string = pipe.transform('TE');
    expect(exp).toEqual('Phone number');
  });
});
