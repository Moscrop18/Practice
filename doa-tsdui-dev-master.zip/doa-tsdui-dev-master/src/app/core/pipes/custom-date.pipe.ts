import { DatePipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';

@Pipe({
  name: 'customDate'
})
export class CustomDatePipe implements PipeTransform {
  constructor(private translateService: TranslateService) {}

  public transform(value: string, pattern: string, locale: string): string {
    let localeString: string = null;
    if (locale === '' || locale === undefined)
      locale = this.translateService.currentLang;
    if (!localeString || localeString === null) {
      const datePipe = new DatePipe(locale);
      localeString = datePipe.transform(value, pattern);
    }
    return localeString;
  }
}
