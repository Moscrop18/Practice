import { NgModule } from '@angular/core';
import { FilterPipe } from '@core/pipes/filter.pipe';

import { CustomCommunication } from './communication.pipe';
import { CustomDatePipe } from './custom-date.pipe';
import { EllipsisPipe } from './ellipsis.pipe';
@NgModule({
  declarations: [FilterPipe, CustomDatePipe, CustomCommunication, EllipsisPipe],
  imports: [],
  exports: [FilterPipe, CustomDatePipe, CustomCommunication, EllipsisPipe]
})
export class PipesModule {}
