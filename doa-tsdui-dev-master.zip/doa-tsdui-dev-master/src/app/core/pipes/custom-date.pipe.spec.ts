/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { TestBed, waitForAsync } from '@angular/core/testing';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { CustomDatePipe } from './custom-date.pipe';

describe('CustomDatePipe', () => {
  let translate: TranslateService;

  const translations: any = {
    'menu.home': 'HOME'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(): Observable<any> {
      return of({ translations });
    }
  }

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: MockLoader }
          })
        ]
      });
    })
  );

  beforeEach(() => {
    translate = TestBed.inject(TranslateService);
    translate.currentLang = 'en';
  });
  it('create an instance', () => {
    const pipe = new CustomDatePipe(translate);
    expect(pipe).toBeTruthy();
  });

  it('call transform with valid items', () => {
    const pipe = new CustomDatePipe(translate);
    const exp: string = pipe.transform('2021-04-01T16:50:42.999Z', 'MMM dd, y');
    expect(exp).toEqual('Apr 01, 2021');
  });
});
