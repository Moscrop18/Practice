import { FilterPipe } from './filter.pipe';

describe('FilterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPipe();
    expect(pipe).toBeTruthy();
  });

  it('call transform with undefined items', () => {
    const pipe = new FilterPipe();
    const exp: Array<any> = pipe.transform(undefined, 'value', 'prop');
    expect(exp.length).toEqual(0);
  });

  it('call transform with valid items', () => {
    const pipe = new FilterPipe();
    const fruits = ['Apple', 'Orange', 'Banana'];
    const exp: Array<any> = pipe.transform(fruits, 'a', '1');
    expect(exp.length).toEqual(1);
  });
});
