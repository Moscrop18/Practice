import { EllipsisPipe } from './ellipsis.pipe';

describe('EllipsisPipe', () => {
  it('create an instance', () => {
    const pipe = new EllipsisPipe();
    expect(pipe).toBeTruthy();
  });
  it('call transform with undefined value', () => {
    const truncate = new EllipsisPipe();
    const exp: string = truncate.transform(undefined, 10);
    expect(exp.length).toEqual(0);
  });
  it('call transform with valid value', () => {
    const truncate = new EllipsisPipe();
    const text = 'This is a long text';
    const exp: string = truncate.transform(text, 10);
    expect(exp.length).toEqual(13); // 3 extra for the ellipsis
  });
});
