/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {
  transform(items: any[], value: any, prop: string): any[] {
    if (!items) {
      return [];
    }
    if (!value) {
      return items;
    }
    return items.filter(
      (singleItem) =>
        singleItem[prop] !== null &&
        singleItem[prop]
          .toString()
          .toLowerCase()
          .startsWith(value.toString().toLowerCase())
    );
  }
}
