/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Action } from '@core/enums/action.enum';
import { Resource } from '@core/enums/resource.enum';

import { MenuItem } from './menuitem';

export class AngularMinfinMenu implements MenuItem {
  public label: string;
  public routerLink?: any;
  public action?: Action;
  public resource?: Resource;
  public items?: AngularMinfinMenu[];
  public routerLinkActiveOptions?: any;
}
