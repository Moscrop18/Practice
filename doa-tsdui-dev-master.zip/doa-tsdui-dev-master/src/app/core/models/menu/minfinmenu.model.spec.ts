/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Action } from '@core/enums/action.enum';
import { Resource } from '@core/enums/resource.enum';

import { AngularMinfinMenu } from './angularnminfinmenu.model';

describe('AngularMinfinMenu', () => {
  it('create an instance', () => {
    const angularMinfinMenu = new AngularMinfinMenu();
    expect(angularMinfinMenu).toBeTruthy();
  });
});
