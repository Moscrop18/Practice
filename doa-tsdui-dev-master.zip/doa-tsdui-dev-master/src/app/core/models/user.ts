import { AuthorizationModel } from './authorization.model';

export interface Credentials {
  username: string;
  password: string;
}

export interface User {
  name?: string;
  preferredLanguage?: string;
  mail?: string;
  ssoUid?: string;
  userType?: string;
  permissions?: any;
  shortName?: string;
  allowedApps?: string[];
  authorizations?: AuthorizationModel[];
}
