export class Pageable {
  static DEFAULT_PAGE_SIZE = 10;
  static FIRST_PAGE_NUMBER = 1;

  pageSize: number;
  pageNumber: number;
  offset: number;

  public constructor() {
    this.pageSize = Pageable.DEFAULT_PAGE_SIZE;
    this.pageNumber = Pageable.FIRST_PAGE_NUMBER;
  }
}
