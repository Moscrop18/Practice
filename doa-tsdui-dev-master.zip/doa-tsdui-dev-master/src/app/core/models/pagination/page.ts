import { Sort } from '../sorting/sort';

import { Pageable } from './pageable';

export class Page {
  pageable: Pageable;
  sort: Sort;
  totalElements: number;
  totalPages: number;

  public constructor() {
    this.pageable = new Pageable();
    this.sort = {
      column: '',
      direction: 'asc'
    };
  }
}
