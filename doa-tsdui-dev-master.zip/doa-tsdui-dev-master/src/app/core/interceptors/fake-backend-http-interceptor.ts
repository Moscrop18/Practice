/* eslint-disable sonarjs/no-duplicate-string */
/* eslint-disable @typescript-eslint/prefer-regexp-exec */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable sonarjs/cognitive-complexity */
/* eslint-disable sonarjs/cognitive-complexity */

import {
  HttpHeaders,
  HttpClient,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@core/services/config/config.service';
import { ErrorResponse } from '@features/edit-declaration/models/error-response';
import { Observable, of, throwError } from 'rxjs';
import { advsearchResult } from 'src/assets/mocks/adv-search-result.mock';
import { advsearchResultNextpage } from 'src/assets/mocks/adv-search-result.mock-pagination';
import { advsearchResult2 } from 'src/assets/mocks/adv-search-result.mock2';
import { itemsListInformation } from 'src/assets/mocks/cons-info-items-list';
import { masConsInformation } from 'src/assets/mocks/cons-info.mock';
import { errorMock } from 'src/assets/mocks/error-mock';
import { eventHistoryMockData } from 'src/assets/mocks/event-hist-mock';
import { genInfoAmendmentMockData } from 'src/assets/mocks/gen-info-amendment-mock';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';
import { genInfoSubmissionMockData } from 'src/assets/mocks/gen-info-submission-mock';
import { houseOverview } from 'src/assets/mocks/house-overview.mock';
import { itemsInformation } from 'src/assets/mocks/items-info.mock';
import { itemsInformation2 } from 'src/assets/mocks/items-info.mock2';
import { riskAndControlMockData } from 'src/assets/mocks/risk-analysis-request-mock';
import { riskAndControlStatusMockData } from 'src/assets/mocks/risk-and-control-status-history-mock';
import { statusHistoryMockData } from 'src/assets/mocks/status-history.mock';

declare const window: any;
import { houseConsInformation } from './../../../assets/mocks/cons-info.mock';

@Injectable()
export class FakeBackendHttpInterceptor implements HttpInterceptor {
  constructor(private http: HttpClient, private configService: ConfigService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return this.handleRequests(req, next);
  }

  handleRequests(req: HttpRequest<any>, next: HttpHandler): any {
    const { url, method } = req;
    if (method === 'GET' && url.includes('/assets/')) {
      return next.handle(req);
    }
    if (window.Cypress || !this.configService.getConfig().demoMode) {
      return next.handle(req);
    }
    console.log(method + ' ' + url);
    console.log(
      'using fake backend to return response. config',
      this.configService.getConfig()
    );
    //Other API calls to be added below this condition
    if (method === 'POST' && url.includes('/invalidate')) {
      return of(
        new HttpResponse({
          status: 200,
          body: { status: 200 }
        })
      );
    }
    if (
      !window.Cypress &&
      url.endsWith('/temporaryStorageDeclarations') &&
      method === 'POST'
    ) {
      const link = new HttpHeaders({
        location: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/1'
      });
      const response = new HttpResponse({
        status: 201,
        headers: link
      });
      return of(response);
    }
    if (!window.Cypress && url.includes(`validate`) && method === 'POST') {
      const response = new HttpResponse({
        status: 201
      });
      return of(response);
    }
    if (!window.Cypress && url.includes(`submit`) && method === 'POST') {
      // const response = new HttpResponse({
      //   status: 201
      // });
      // return of(response);
      const response = new HttpErrorResponse({
        status: 400,
        error: errorMock
      });

      return throwError(response);
    }
    if (!window.Cypress && url.endsWith('/amend') && method === 'POST') {
      const link = new HttpHeaders({
        location: 'http://localhost:8888/api/v1/temporaryStorageDeclarations/'
      });
      const response = new HttpResponse({
        status: 201,
        headers: link
      });
      return of(response);
      // const errors: ErrorResponse = {
      //   id: 1,
      //   violations: [{ code: 'XXR0328' }]
      // };
      // const errorResponse = new HttpErrorResponse({
      //   status: 401,
      //   error: errors
      // });
      // return throwError(errorResponse);
    }
    if (
      !window.Cypress &&
      url.endsWith('/temporaryStorageDeclarations/1') &&
      method === 'PATCH'
    ) {
      const response = new HttpResponse({
        status: 200
      });
      return of(response);
    }
    if (!window.Cypress && url.endsWith('/consignments') && method === 'POST') {
      const link = new HttpHeaders({
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/12'
      });
      const response = new HttpResponse({
        status: 200,
        headers: link
      });
      return of(response);
    }
    if (
      !window.Cypress &&
      url.includes('/consignments') &&
      !url.includes('/items') &&
      method === 'DELETE'
    ) {
      const response = new HttpResponse({
        status: 200
      });
      return of(response);
    }
    if (
      !window.Cypress &&
      url.includes('/consignments') &&
      !url.includes('/items') &&
      method === 'PATCH'
    ) {
      const response = new HttpResponse({
        status: 200
      });
      return of(response);
    }
    if (!window.Cypress && url.endsWith('/items') && method === 'POST') {
      const link = new HttpHeaders({
        location:
          'http://localhost:8888/api/v1/temporaryStorageDeclarations/1/consignments/12/items/3'
      });
      const response = new HttpResponse({
        status: 200,
        headers: link
      });
      return of(response);
    }
    if (!window.Cypress && url.includes('/items') && method === 'PATCH') {
      const response = new HttpResponse({
        status: 200
      });
      return of(response);
    }
    if (!window.Cypress && url.includes('/items') && method === 'DELETE') {
      const response = new HttpResponse({
        status: 200
      });
      return of(response);
    }
    if (method === 'GET') {
      let responseBody;
      if (url.endsWith('/statusHistory')) {
        responseBody = statusHistoryMockData;
      } else if (url.endsWith('/riskAnalysisRequests')) {
        responseBody = riskAndControlMockData;
      } else if (url.endsWith('/riskAndControlStatusHistory')) {
        responseBody = riskAndControlStatusMockData;
      } else if (
        url.endsWith('/temporaryStorageDeclarations/2313413') ||
        url.endsWith('/temporaryStorageDeclarations/2313443') ||
        url.endsWith('/temporaryStorageDeclarations/2313273')
      ) {
        responseBody = genInfoAmendmentMockData;
      } else if (url.endsWith('/temporaryStorageDeclarations/2313453')) {
        responseBody = genInfoSubmissionMockData;
      } else if (url.endsWith('/versions')) {
        responseBody = eventHistoryMockData;
      } else if (url.endsWith('/consignments/0')) {
        responseBody = masConsInformation;
      } else if (
        url.includes('/consignments') &&
        !url.includes('/consignments/')
      ) {
        responseBody = houseOverview;
      } else if (url.endsWith(`/items`)) {
        responseBody = itemsListInformation;
      } else if (url.includes(`/items/2`)) {
        responseBody = itemsInformation2;
      } else if (url.includes(`/items/`)) {
        responseBody = itemsInformation;
      } else if (
        // eslint-disable-next-line @typescript-eslint/prefer-regexp-exec
        url.search(`/temporaryStorageDeclarations/`) !== -1 &&
        url.search(`/consignments/`) !== -1 &&
        parseInt(url.substring(url.lastIndexOf('/') + 1)) > 0
      ) {
        responseBody = houseConsInformation;
      } else if (
        // eslint-disable-next-line @typescript-eslint/prefer-regexp-exec
        url.includes(
          `api/v1/temporaryStorageDeclarations?registrationDateAfter=`
        ) ||
        url.includes(`api/v1/temporaryStorageDeclarations?status=Draft`)
      ) {
        if (url.includes('pageSize=20')) {
          if (url.includes(`sort=registrationDate`)) {
            responseBody = {
              ...advsearchResult2,
              items: advsearchResult2.items
                .slice()
                .sort((a, b) =>
                  b.registrationDate.localeCompare(a.registrationDate)
                )
            };
          } else {
            responseBody = {
              ...advsearchResult2,
              items: advsearchResult2.items
                .slice()
                .sort((a, b) =>
                  a.registrationDate.localeCompare(b.registrationDate)
                )
            };
          }
        } else {
          if (url.includes(`sort=registrationDate`)) {
            responseBody = {
              ...advsearchResult,
              items: advsearchResult.items
                .slice()
                .sort((a, b) =>
                  b.registrationDate.localeCompare(a.registrationDate)
                )
            };
          } else if (url.includes(`status=`)) {
            const status = [];
            if (url.includes(`status=PreLodged`)) status.push('PreLodged');
            if (url.includes(`status=IrregularityUnderInvestigation`))
              status.push('IrregularityUnderInvestigation');
            if (url.includes(`status=Accepted`)) status.push('Accepted');
            if (url.includes(`status=Invalidated`)) status.push('Invalidated');
            if (url.includes(`status=UnderControl`))
              status.push('UnderControl');
            responseBody = {
              ...advsearchResult,
              items: advsearchResult.items
                .slice()
                .filter((a) => status.includes(a.status))
            };
          } else {
            responseBody = {
              ...advsearchResult,
              items: advsearchResult.items
                .slice()
                .sort((a, b) =>
                  a.registrationDate.localeCompare(b.registrationDate)
                )
            };
          }
        }
      } else if (
        url.includes(
          `api/v1/temporaryStorageDeclarations?after=qoVf3ERK1Mdsd3G5kMTosNTm=`
        )
      ) {
        responseBody = advsearchResultNextpage;
      } else if (
        url.includes('/temporaryStorageDeclarations/') &&
        (url
          .substring(url.lastIndexOf('/') + 1)
          .match(/((^[0-9]+[a-z]+)|(^[a-z]+[0-9]+))+[0-9a-z]+$/i) ||
          parseInt(url.substring(url.lastIndexOf('/') + 1)))
      ) {
        responseBody = genInfoMockData;
      }
      if (responseBody) {
        const etag = new HttpHeaders({
          etag: (Math.floor(Math.random() * 6) + 1).toString()
        });
        return of(
          new HttpResponse({
            status: 200,
            body: responseBody,
            headers: etag
          })
        );
      }
      return next.handle(req);
    }
  }
}
