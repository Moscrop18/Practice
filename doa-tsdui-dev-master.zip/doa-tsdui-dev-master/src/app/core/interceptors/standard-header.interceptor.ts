/* eslint-disable @typescript-eslint/no-unsafe-return */
import {
  HttpErrorResponse,
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OIDCTokenHandler } from '@core/components/auth/oidc-token-handler';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
@Injectable()
export class StandardHeaderInterceptor implements HttpInterceptor {
  constructor(private tokenHandler: OIDCTokenHandler) {}
  contentType = 'Content-Type';
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (!req.headers.has(this.contentType)) {
      req = req.clone({
        headers: req.headers.set(this.contentType, 'application/json')
      });
    }
    if (sessionStorage.getItem('Authorization') !== null) {
      req = req.clone({
        headers: req.headers.set(
          'Authorization',
          sessionStorage.getItem('Authorization')
        )
      });
    }
    req = req.clone({ headers: req.headers.set('Accept', 'application/json') });
    return next.handle(req).pipe(
      tap(
        (event) => {
          if (
            event instanceof HttpResponse &&
            event.headers.has(this.contentType) &&
            event.headers.get(this.contentType)?.includes('html')
          ) {
            this.tokenHandler.saveAvailableAuthenticationToken(event);
          }
        },
        (error) => {
          if (error instanceof HttpErrorResponse && error.status === 401) {
            this.tokenHandler.refreshTokens();
            return next.handle(req);
          }
        }
      )
    );
  }
}
