/* eslint-disable sonarjs/no-duplicate-string */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';

import { JsonDateInterceptor } from './JSON-date.interceptor';

describe('JsonDateInterceptor', () => {
  const API_URL = 'http://localhost:8888/';

  let jsonDateInterceptor: JsonDateInterceptor;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: JsonDateInterceptor,
          multi: true
        },
        JsonDateInterceptor
      ]
    });
    jsonDateInterceptor = TestBed.get(HTTP_INTERCEPTORS);
  });

  it('JsonDateInterceptor should be created', () => {
    expect(jsonDateInterceptor).toBeTruthy();
  });
  describe('intercept HTTP requests using json date interceptor', () => {
    it('should intercept request body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(API_URL)
          .subscribe((response) => expect(response).toBeTruthy());
        const httpRequest = mock.expectOne(API_URL);
        mock.verify();
      }
    ));

    afterEach(inject([HttpTestingController], (mock: HttpTestingController) => {
      mock.verify();
    }));
  });

  describe('intercept HTTP post request using json date interceptor', () => {
    it('should intercept request post body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .post(API_URL, {
            name: 'tester',
            age: new Date('05 October 2011 14:48 UTC').toISOString()
          })
          .subscribe((response) => expect(response).toBeTruthy());
        const httpRequest = mock.expectOne(API_URL);
        expect(httpRequest.request.body.age).toBeTruthy();
        mock.verify();
      }
    ));

    afterEach(inject([HttpTestingController], (mock: HttpTestingController) => {
      mock.verify();
    }));
  });
  it('should test isIsoDateString', () => {
    jsonDateInterceptor = TestBed.get(JsonDateInterceptor);
    const isIsoDate = jsonDateInterceptor.isIsoDateString(
      '2019-08-24T14:15:22Z'
    );
    expect(true).toEqual(isIsoDate);
  });
  it('should test convert when date is null', () => {
    jsonDateInterceptor = TestBed.get(JsonDateInterceptor);
    const isoDate = jsonDateInterceptor.convert(null);
    expect(isoDate).toEqual(null);
  });
  it('should test convert when date is null', () => {
    jsonDateInterceptor = TestBed.get(JsonDateInterceptor);
    const isoDate = jsonDateInterceptor.convert(
      new Date('2019-08-24T14:15:22Z').toISOString()
    );
    expect(isoDate).toEqual('2019-08-24T14:15:22.000Z');
  });
  it('should test convert when date is object', () => {
    const date = {
      a: new Date('2019-08-24T14:15:22Z').toISOString(),
      b: {
        c: new Date('2019-08-24T14:15:22Z').toISOString()
      }
    };
    jsonDateInterceptor = TestBed.get(JsonDateInterceptor);
    jsonDateInterceptor.convert(date);
    expect(date).toBeTruthy();
  });
});
