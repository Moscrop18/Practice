/* eslint-disable sonarjs/no-duplicate-string */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable sonarjs/no-identical-functions */

import {
  HttpClient,
  HttpRequest,
  HTTP_INTERCEPTORS
} from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { ConfigService } from '@core/services/config/config.service';

import { FakeBackendHttpInterceptor } from './fake-backend-http-interceptor';

describe('JsonDateInterceptor', () => {
  const API_URL = 'http://localhost:8888/';

  let fakeBackendHttpInterceptor: FakeBackendHttpInterceptor;

  beforeEach(async () => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: FakeBackendHttpInterceptor,
          multi: true
        },
        ConfigService
      ]
    });
    fakeBackendHttpInterceptor = await TestBed.get(HTTP_INTERCEPTORS);
  });

  describe('intercept HTTP get request', () => {
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(API_URL + '/temporaryStorageDeclarations/20BETP000000C3FLU4')
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items/1'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/statusHistory'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/versions'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?after=qoVf3ERK1Mdsd3G5kMTosNTm='
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(API_URL + 'api/v1/temporaryStorageDeclarations?status=Draft')
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(API_URL + 'api/v1/temporaryStorageDeclarations/2313413')
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              '/temporaryStorageDeclarations/20BETP000000C3FLU4/consignments/0/items/2'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?status=Draft?pageSize=20?sort=registrationDate'
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept status param', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?registrationDateAfter=*&status=Accepted'
          )
          .subscribe((response) => expect(response).toBeTruthy());
      }
    ));
    it('should intercept status param', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?registrationDateAfter=*&status=PreLodged'
          )
          .subscribe((response) => expect(response).toBeTruthy());
      }
    ));
    it('should intercept status param', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?registrationDateAfter=*&status=IrregularityUnderInvestigation'
          )
          .subscribe((response) => expect(response).toBeTruthy());
      }
    ));
    it('should intercept status param', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?registrationDateAfter=*&status=Invalidated'
          )
          .subscribe((response) => expect(response).toBeTruthy());
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get(
            API_URL +
              'api/v1/temporaryStorageDeclarations?after=qoVf3ERK1Mdsd3G5kMTosNTm='
          )
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .put('/temporaryStorageDeclarations/1', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for post', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .post('/temporaryStorageDeclarations/1/consignments', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for post items', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .post('/temporaryStorageDeclarations/1/consignments/1/items', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for put items', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .put('/temporaryStorageDeclarations/1/consignments/1/items', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for delete items', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .delete('/temporaryStorageDeclarations/1/consignments/1/items', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for put consignment', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .put('/temporaryStorageDeclarations/1/consignments/1', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for delete consignment', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .delete('/temporaryStorageDeclarations/1/consignments/1', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for temporaryStorageDeclarations/2313453', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get('/temporaryStorageDeclarations/2313453', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for specific consignment', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get('/temporaryStorageDeclarations/1/consignments/1', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for put', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .put('/temporaryStorageDeclarations/1/consignments', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for delete', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .delete('/temporaryStorageDeclarations/1/consignments/12', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    it('should intercept request get body for risk', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get('/temporaryStorageDeclarations/riskAnalysisRequests', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));
    it('should intercept request get body for status history', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        http
          .get('/temporaryStorageDeclarations/riskAndControlStatusHistory', {})
          .subscribe((response) => expect(response).toBeTruthy());
        // mock.verify();
      }
    ));

    afterEach(inject([HttpTestingController], (mock: HttpTestingController) => {
      mock.verify();
    }));
  });
});
