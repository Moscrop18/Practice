/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import {
  HttpClient,
  HttpHandler,
  HttpRequest,
  HTTP_INTERCEPTORS
} from '@angular/common/http';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { inject, TestBed } from '@angular/core/testing';
import { OIDCTokenHandler } from '@core/components/auth/oidc-token-handler';
import { Observable } from 'rxjs';

import { StandardHeaderInterceptor } from './standard-header.interceptor';

describe('StandardHeaderInterceptor', () => {
  const API_URL = 'http://localhost:8888/';
  let interceptor: StandardHeaderInterceptor;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        {
          provide: HTTP_INTERCEPTORS,
          useClass: StandardHeaderInterceptor,
          multi: true
        },
        OIDCTokenHandler,
        StandardHeaderInterceptor
      ]
    });
    interceptor = TestBed.get(StandardHeaderInterceptor);
  });

  describe('intercept HTTP requests', () => {
    it('should add Content-type and accept to Headers', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        sessionStorage.setItem('Authorization', 'abcd');
        http
          .get(API_URL)
          .subscribe((response) => expect(response).toBeTruthy());
        const httpRequest = mock.expectOne(API_URL);
        expect(httpRequest.request.headers.has('Content-Type')).toEqual(true);
        expect(httpRequest.request.headers.has('Authorization')).toEqual(true);
        expect(httpRequest.request.headers.has('Accept')).toEqual(true);
        mock.verify();
      }
    ));
    it('should skip adding Authorization header', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        sessionStorage.removeItem('Authorization');
        http
          .get(API_URL)
          .subscribe((response) => expect(response).toBeTruthy());
        const httpRequest = mock.expectOne(API_URL);
        expect(httpRequest.request.headers.has('Authorization')).toBeFalsy();
        mock.verify();
      }
    ));
    it('should call saveAvailableAuthenticationToken for content type html', inject(
      [HttpClient, HttpTestingController],
      (http: HttpClient, mock: HttpTestingController) => {
        const next: HttpHandler = {
          handle: () => {
            return Observable.create((subscriber) => {
              subscriber.complete();
            });
          }
        };
        const requestMock = new HttpRequest(
          'GET',
          'http://localhost:4200/assets/renew-tokens.html'
        );
        interceptor.intercept(requestMock, next).subscribe(() => {
          expect(
            interceptor['saveAvailableAuthenticationToken']
          ).toHaveBeenCalled();
        });
        mock.verify();
      }
    ));
    afterEach(inject([HttpTestingController], (mock: HttpTestingController) => {
      mock.verify();
    }));
  });
});
