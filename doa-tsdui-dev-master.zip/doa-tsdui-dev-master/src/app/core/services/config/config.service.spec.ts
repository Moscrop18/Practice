/* eslint-disable @typescript-eslint/unbound-method */
/* eslint-disable @typescript-eslint/no-floating-promises */
import { HttpClient } from '@angular/common/http';
import { TestBed, fakeAsync } from '@angular/core/testing';
import { cold } from 'jasmine-marbles';

import { ConfigService } from './config.service';

describe('ConfigService', () => {
  let service: ConfigService;
  let http: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        { provide: HttpClient, useValue: { get: jest.fn() } },
        ConfigService
      ]
    });
    service = TestBed.inject(ConfigService);
    http = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it("'loadConfig' should load configuration'", fakeAsync(() => {
    const result = { apiBaseUrl: 'http://domain-name.com/api/v1' };
    const expected = cold('-a|', { a: result });
    http.get = jest.fn(() => expected);
    service.loadConfig();
    expect(http.get).toHaveBeenCalledWith('../../../../../assets/config.json', {
      observe: 'response'
    });
  }));
  it("'loadConfig' should load configuration'", fakeAsync(() => {
    const response = { apiUrl: '/api/v1' };
    const expected = cold('-a|', { a: response });
    http.get = jest.fn(() => expected);
    service.loadConfig().subscribe((res) => {
      expect(res).toEqual(response);
    });
  }));
});
