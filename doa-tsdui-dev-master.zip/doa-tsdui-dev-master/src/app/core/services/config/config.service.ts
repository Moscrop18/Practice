/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
// eslint-disable @typescript-eslint/no-unsafe-return
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environments/environment';
import { forkJoin } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
/**
 * This service class loads configuration details.
 * class has load config method which is called thourgh configFacotry which futher being inovked at
 * application start up in app module.
 */
@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private configuration: ConfigSettings;
  constructor(private http: HttpClient) {
    if (window['Cypress']) {
      environment.showTableOverlays = false;
    }
    this.configuration = environment;
  }
  /**
   * method return configuration loaded fron env specific config and default to environment
   */
  public getConfig(): ConfigSettings {
    return this.configuration;
  }

  /**
   * This method loads config file from which loaded env specifc values.
   */
  loadConfig() {
    return forkJoin([this.retrieveConfig()]);
  }

  retrieveConfig() {
    //Making first html call to be intercepted by httpInterceptor and read tokens.
    this.http
      .get('../../../assets/renew-tokens.html', {
        observe: 'response',
        responseType: 'text'
      })
      .subscribe((response) => {
        return undefined;
      });
    return this.http
      .get<ConfigSettings>('../../../../../assets/config.json', {
        observe: 'response'
      })
      .pipe(
        map(
          (configuration) => {
            if (configuration) {
              this.configuration = { ...environment, ...configuration.body };
              if (!this.configuration.showLogs) {
                const methods = ['log', 'debug', 'warn', 'info'];
                methods.forEach(
                  (element) =>
                    (console[element] = function () {
                      //return undefined;
                    })
                );
              }
              console.log('config loaded', this.configuration);
              if (this.configuration?.pnUIUrl) {
                const regex = /^(?:https?:\/\/)?(?:[^@/\n]+@)?(?:www\.)?([^:/?\n]+)/;
                let url = window.location.host.match(regex)[1];
                const regExp = /\{([^)]+)\}/;
                const matches = regExp.exec(this.configuration?.pnUIUrl);
                matches[1].split('|').forEach((item) => {
                  const find = new RegExp(item.split('/')[1]);
                  const replace = item.split('/')[2];
                  if (find.test(url)) {
                    url = url.replace(find, replace);
                  }
                });
                this.configuration.pnUIUrl = this.configuration?.pnUIUrl.replace(
                  / *\{[^)]*\} */g,
                  url
                );
              }
            }
          },
          catchError((err, caught) => {
            console.error(err, caught);
            return null;
          })
        )
      );
  }
}

class ConfigSettings {
  apiUrl: string;
  pnUIUrl: string;
  minfinUrl: string;
  demoMode: boolean;
  showTableOverlays: boolean;
  env: string;
  headers?: HttpHeaders;
  showLogs: boolean;
}
