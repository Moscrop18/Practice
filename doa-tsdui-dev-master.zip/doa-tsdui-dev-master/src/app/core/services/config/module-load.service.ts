/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-return */

import { Injectable } from '@angular/core';
import { AuthState } from '@core/components/auth/store/reducers';
import { Store } from '@ngrx/store';

import * as actions from './../../components/auth/store/actions/auth.actions';

@Injectable()
export class ModuleLoadService {
  private configuration: any;

  constructor(private store: Store<AuthState>) {}

  isErrorPage(isError: boolean) {
    this.store.dispatch(actions.onErrorPage({ isError: isError }));
  }
}
