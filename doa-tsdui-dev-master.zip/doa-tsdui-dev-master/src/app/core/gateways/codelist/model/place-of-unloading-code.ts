export interface PlaceOfUnloadingCode {
  id: number;
  value: string;
  definition: string;
}
