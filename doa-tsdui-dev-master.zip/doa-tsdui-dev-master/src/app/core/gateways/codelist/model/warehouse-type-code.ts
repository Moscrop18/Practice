export interface WarehouseTypeCode {
  id: number;
  value: string;
  definition: string;
}
