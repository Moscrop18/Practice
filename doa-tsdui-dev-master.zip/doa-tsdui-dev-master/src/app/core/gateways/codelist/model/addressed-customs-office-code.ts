export interface AddressedCustomsOfficeCode {
  id: number;
  value: string;
  definition: string;
}

export interface Codelist {
  id: number;
  value: string;
  label?: string;
  definition?: string;
}
