export interface CountryDataLevelCode {
  id: number;
  value: string;
  definition: string;
}
