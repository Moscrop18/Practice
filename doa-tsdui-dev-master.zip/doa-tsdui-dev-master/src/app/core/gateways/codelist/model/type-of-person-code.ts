export interface TypeOfPersonCode {
  id: number;
  value: string;
  definition: string;
}
