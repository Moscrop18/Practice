export interface LocationTypeCode {
  id: number;
  value: string;
  definition: string;
}
