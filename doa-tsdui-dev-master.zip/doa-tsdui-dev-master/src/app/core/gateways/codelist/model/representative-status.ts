export interface RepresentativeStatusCodeList {
  id: number;
  value: string;
  definition: string;
}
