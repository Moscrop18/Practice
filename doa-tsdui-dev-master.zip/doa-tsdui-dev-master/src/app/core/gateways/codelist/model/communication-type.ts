export interface CommunicationTypeCodeList {
  id: number;
  value: string;
  definition: string;
}
