export interface ArrivalTransportTypeCode {
  id: number;
  value: string;
  definition: string;
}
