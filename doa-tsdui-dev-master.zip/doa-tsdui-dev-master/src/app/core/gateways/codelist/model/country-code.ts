export interface CountryCode {
  id: number;
  value: string;
  definition: string;
}
