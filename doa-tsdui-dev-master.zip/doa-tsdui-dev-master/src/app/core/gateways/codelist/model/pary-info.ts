import { Communication } from './communication';

export interface PartyInformation {
  id: string;
  name: string;
  communication: Communication[];
}
