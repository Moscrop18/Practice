export interface QualifierCode {
  id: number;
  value: string;
  definition: string;
}
