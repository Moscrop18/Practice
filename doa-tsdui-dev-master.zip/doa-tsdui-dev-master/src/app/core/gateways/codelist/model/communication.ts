export interface Communication {
  id: string;
  fullName: string;
  type: string;
  identifier: string;
}
