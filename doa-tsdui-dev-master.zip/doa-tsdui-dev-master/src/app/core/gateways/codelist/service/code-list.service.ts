/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { take } from 'rxjs/operators';

import {
  AddressedCustomsOfficeCode,
  Codelist
} from '../model/addressed-customs-office-code';
import { ArrivalTransportTypeCode } from '../model/arrival-transport-type-code';
import { CommunicationTypeCodeList } from '../model/communication-type';
import { CountryCode } from '../model/country-code';
import { LocationTypeCode } from '../model/location-type-code';
import { PartyInformation } from '../model/pary-info';
import { PlaceOfUnloadingCode } from '../model/place-of-unloading-code';
import { QualifierCode } from '../model/qualifier-code';
import { RepresentativeStatusCodeList } from '../model/representative-status';
import { WarehouseTypeCode } from '../model/warehouse-type-code';
import {
  fetchCodeListData,
  fetchEoriListAction
} from '../store/action/code-list-actions';
import { CodeListState } from '../store/reducer/code-list.reducer';
import {
  CL016CodeList,
  CL017CodeList,
  CL213CodeList,
  CL214CombinedCodeList,
  CL214PrelodgedCodeList,
  CL380CodeList,
  CL704CodeList,
  CL709CodeList,
  CL712Codelist,
  CL714Codelist,
  CL716Codelist,
  CL737Codelist,
  CL739Codelist,
  CL754CodeList,
  CL758Codelist,
  communicationTypeCodeList,
  countryCodeList,
  getCodeList,
  getCountryDataLevel,
  getPartyData,
  getQualifierList,
  locationTypeCombinedCodeList,
  locationTypePrelodgedCodeList,
  placeOfUnloadingCodelist,
  qualifierCodeList,
  representativeStatusCodeList,
  selectAddressCodeList,
  selectArrivalTransportCodeList,
  selectTypeOfPersonCodeList,
  warehouseTypeCodeList
} from '../store/selectors/code-list-selector';

import { TypeOfPersonCode } from './../model/type-of-person-code';

@Injectable({
  providedIn: 'root'
})
export class CodeListService {
  constructor(private codeListStore: Store<CodeListState>) {}

  public getCodeListState(): Observable<CodeListState> {
    return this.codeListStore.select(getCodeList);
  }
  public getAddressedCustomsOfficeCodes(): Observable<
    AddressedCustomsOfficeCode[]
  > {
    return this.codeListStore.select(selectAddressCodeList);
  }
  public getTypeOfPersonCodes(): Observable<TypeOfPersonCode[]> {
    return this.codeListStore.select(selectTypeOfPersonCodeList);
  }
  public getArrivalTransportTypeCodes(): Observable<
    ArrivalTransportTypeCode[]
  > {
    return this.codeListStore.select(selectArrivalTransportCodeList);
  }
  public getPlaceOfUnloadingCodes(): Observable<PlaceOfUnloadingCode[]> {
    return this.codeListStore.select(placeOfUnloadingCodelist);
  }
  public getLocationTypeCodes(): Observable<LocationTypeCode[]> {
    return this.codeListStore.select(locationTypePrelodgedCodeList);
  }
  public getLocationTypeCombinedCodes(): Observable<LocationTypeCode[]> {
    return this.codeListStore.select(locationTypeCombinedCodeList);
  }
  public getWarehouseTypeCodes(): Observable<WarehouseTypeCode[]> {
    return this.codeListStore.select(warehouseTypeCodeList);
  }
  public getCountryCodes(): Observable<CountryCode[]> {
    return this.codeListStore.select(countryCodeList);
  }
  public getQualifierCodes(locationType: string) {
    return this.codeListStore.select(getQualifierList(locationType));
  }
  public getQualifierCodeList(): Observable<QualifierCode[]> {
    return this.codeListStore.select(qualifierCodeList);
  }
  public getCL745CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL754CodeList);
  }
  public getCL214PrelodgedCodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL214PrelodgedCodeList);
  }
  public getCL214CombinedCodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL214CombinedCodeList);
  }
  public getCL709CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL709CodeList);
  }
  public getCL213CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL213CodeList);
  }
  public getCL704CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL704CodeList);
  }
  public getCL017CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL017CodeList);
  }
  public getCL016CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL016CodeList);
  }
  public getCL380CodeList(): Observable<Codelist[]> {
    return this.codeListStore.select(CL380CodeList);
  }
  public getPostCodeDataLevel(countryCode: string): Observable<string> {
    return this.codeListStore.pipe(
      take(1),
      select(getCountryDataLevel(countryCode))
    );
  }
  public dispatchFetchCodeListDataAction(): void {
    this.codeListStore.dispatch(fetchCodeListData());
  }
  public dispatchFetchEoriListAction(): void {
    this.codeListStore.dispatch(fetchEoriListAction());
  }
  public getParty(eoriNumber: string): Observable<PartyInformation> {
    return this.codeListStore.select(getPartyData(eoriNumber));
  }
  public getCommunicationTypeCodeList(): Observable<
    CommunicationTypeCodeList[]
  > {
    return this.codeListStore.select(communicationTypeCodeList);
  }
  public getRepresentativeStatusCodeList(): Observable<
    RepresentativeStatusCodeList[]
  > {
    return this.codeListStore.select(representativeStatusCodeList);
  }
  public getCL712Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL712Codelist);
  }
  public getCL714Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL714Codelist);
  }
  public getCL716Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL716Codelist);
  }
  public getCL737Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL737Codelist);
  }
  public getCL739Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL739Codelist);
  }
  public getCL758Codelist(): Observable<Codelist[]> {
    return this.codeListStore.select(CL758Codelist);
  }
}
