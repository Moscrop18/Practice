/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-empty-interface */

import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { createEntityAdapter, EntityState } from '@ngrx/entity';

import {
  AddressedCustomsOfficeCode,
  Codelist
} from '../../model/addressed-customs-office-code';
import { ArrivalTransportTypeCode } from '../../model/arrival-transport-type-code';
import { CountryCode } from '../../model/country-code';
import { CountryDataLevelCode } from '../../model/country-data-level-code';
import { LocationTypeCode } from '../../model/location-type-code';
import { PlaceOfUnloadingCode } from '../../model/place-of-unloading-code';
import { QualifierCode } from '../../model/qualifier-code';
import { TypeOfPersonCode } from '../../model/type-of-person-code';
import { WarehouseTypeCode } from '../../model/warehouse-type-code';
import * as codeListActions from '../action/code-list-actions';

import { PartyInformation } from './../../model/pary-info';
import { RepresentativeStatusCodeList } from './../../model/representative-status';

export interface CodeListState {
  addressedCustomsOfficeCodeState?: AddressedCustomsOfficeCodeState;
  arrivalTransportTypeCodeState?: ArrivalTransportCodeState;
  countryCodeState?: CountryCodeState;
  countryDataLevelCodeState?: CountryDataLevelCodeState;
  locationTypeCodeState?: LocationTypeCodeState;
  locationTypeCodeCombinedState?: LocationTypeCodeState;
  placeOfUnloadingCodeState?: PlaceOfUnloadingCodeState;
  qualifierCodeState?: QualifierCodeState;
  warehouseCodeState?: WarehouseCodeState;
  typeOfPersonCodeState?: TypeOfPersonCodeState;
  partyInformationState?: PartyInformationState;
  communicationTypeState?: CommunicationTypeState;
  representativeStatusState?: RepresentativeStatusState;
  CL754CodeListState?: CL754CodeListState;
  CL214PrelodgedCodeListState?: CL214PrelodgedCodeListState;
  CL214CombinedCodeListState?: CL214CombinedCodeListState;
  CL709CodeListState?: CL709CodeListState;
  CL213CodeListState?: CL213CodeListState;
  CL704CodeListState?: CL704CodeListState;
  CL017CodeListState?: CL017CodeListState;
  CL016CodeListState?: CL016CodeListState;
  CL380CodeListState?: CL380CodeListState;
  CL712CodeListState?: CL712CodelistState;
  CL714CodeListState?: CL714CodelistState;
  CL716CodeListState?: CL716CodelistState;
  CL737CodeListState?: CL737CodelistState;
  CL739CodeListState?: CL739CodelistState;
  CL758CodeListState?: CL758CodelistState;
}
interface AddressedCustomsOfficeCodeState
  extends EntityState<AddressedCustomsOfficeCode> {}
interface ArrivalTransportCodeState
  extends EntityState<ArrivalTransportTypeCode> {}
interface CountryCodeState extends EntityState<CountryCode> {}
interface CountryDataLevelCodeState extends EntityState<CountryDataLevelCode> {}
interface LocationTypeCodeState extends EntityState<LocationTypeCode> {}
interface PlaceOfUnloadingCodeState extends EntityState<PlaceOfUnloadingCode> {}
interface QualifierCodeState extends EntityState<QualifierCode> {}
interface WarehouseCodeState extends EntityState<WarehouseTypeCode> {}
interface CL754CodeListState extends EntityState<Codelist> {}
interface CL214PrelodgedCodeListState extends EntityState<Codelist> {}
interface CL214CombinedCodeListState extends EntityState<Codelist> {}
interface CL709CodeListState extends EntityState<Codelist> {}
interface CL213CodeListState extends EntityState<Codelist> {}
interface CL704CodeListState extends EntityState<Codelist> {}
interface CL017CodeListState extends EntityState<Codelist> {}
interface CL016CodeListState extends EntityState<Codelist> {}
interface CL380CodeListState extends EntityState<Codelist> {}
interface CL712CodelistState extends EntityState<Codelist> {}
interface CL714CodelistState extends EntityState<Codelist> {}
interface CL716CodelistState extends EntityState<Codelist> {}
interface CL737CodelistState extends EntityState<Codelist> {}
interface CL739CodelistState extends EntityState<Codelist> {}
interface CL758CodelistState extends EntityState<Codelist> {}

type TypeOfPersonCodeState = EntityState<TypeOfPersonCode>;
type PartyInformationState = EntityState<PartyInformation>;
type CommunicationTypeState = EntityState<CommunicationTypeCodeList>;
type RepresentativeStatusState = EntityState<RepresentativeStatusCodeList>;

const addressedCustomsOfficeCodeAdapter = createEntityAdapter<AddressedCustomsOfficeCode>();
const arrivalTransportTypeCodeAdapter = createEntityAdapter<ArrivalTransportTypeCode>();
const countryCodeAdapter = createEntityAdapter<CountryCode>();
const countryDataLevelCodeAdapter = createEntityAdapter<CountryDataLevelCode>();
const locationTypeCodeAdapter = createEntityAdapter<LocationTypeCode>();
const placeOfUnloadingCodeAdapter = createEntityAdapter<PlaceOfUnloadingCode>();
const qualifierCodeAdapter = createEntityAdapter<QualifierCode>();
const warehouseTypeCodeAdapter = createEntityAdapter<WarehouseTypeCode>();
const personTypeCodeAdapter = createEntityAdapter<TypeOfPersonCode>();
const communicationTypeAdapter = createEntityAdapter<CommunicationTypeCodeList>();
const partyInformationAdapter = createEntityAdapter<PartyInformation>();

const representativeStatusAdapter = createEntityAdapter<RepresentativeStatusCodeList>();
const CL754CodeListAdapter = createEntityAdapter<Codelist>();
const CL214PrelodgedCodeListAdapter = createEntityAdapter<Codelist>();
const CL214CombinedCodeListAdapter = createEntityAdapter<Codelist>();
const CL709CodeListAdapter = createEntityAdapter<Codelist>();
const CL213CodeListAdapter = createEntityAdapter<Codelist>();
const CL704CodeListAdapter = createEntityAdapter<Codelist>();
const CL017CodeListAdapter = createEntityAdapter<Codelist>();
const CL016CodeListAdapter = createEntityAdapter<Codelist>();
const CL380CodeListAdapter = createEntityAdapter<Codelist>();
const CL712CodeListAdapter = createEntityAdapter<Codelist>();
const CL714CodeListAdapter = createEntityAdapter<Codelist>();
const CL716CodeListAdapter = createEntityAdapter<Codelist>();
const CL737CodeListAdapter = createEntityAdapter<Codelist>();
const CL739CodeListAdapter = createEntityAdapter<Codelist>();
const CL758CodeListAdapter = createEntityAdapter<Codelist>();

export const initialState: CodeListState = {
  addressedCustomsOfficeCodeState: addressedCustomsOfficeCodeAdapter.getInitialState(),
  arrivalTransportTypeCodeState: arrivalTransportTypeCodeAdapter.getInitialState(),
  countryCodeState: countryCodeAdapter.getInitialState(),
  countryDataLevelCodeState: countryDataLevelCodeAdapter.getInitialState(),
  locationTypeCodeState: locationTypeCodeAdapter.getInitialState(),
  locationTypeCodeCombinedState: locationTypeCodeAdapter.getInitialState(),
  placeOfUnloadingCodeState: placeOfUnloadingCodeAdapter.getInitialState(),
  qualifierCodeState: qualifierCodeAdapter.getInitialState(),
  warehouseCodeState: warehouseTypeCodeAdapter.getInitialState(),
  typeOfPersonCodeState: personTypeCodeAdapter.getInitialState(),
  partyInformationState: partyInformationAdapter.getInitialState(),
  communicationTypeState: communicationTypeAdapter.getInitialState(),
  representativeStatusState: representativeStatusAdapter.getInitialState(),
  CL754CodeListState: CL754CodeListAdapter.getInitialState(),
  CL214PrelodgedCodeListState: CL214PrelodgedCodeListAdapter.getInitialState(),
  CL214CombinedCodeListState: CL214CombinedCodeListAdapter.getInitialState(),
  CL709CodeListState: CL709CodeListAdapter.getInitialState(),
  CL213CodeListState: CL213CodeListAdapter.getInitialState(),
  CL704CodeListState: CL704CodeListAdapter.getInitialState(),
  CL017CodeListState: CL017CodeListAdapter.getInitialState(),
  CL016CodeListState: CL016CodeListAdapter.getInitialState(),
  CL380CodeListState: CL380CodeListAdapter.getInitialState(),
  CL712CodeListState: CL712CodeListAdapter.getInitialState(),
  CL714CodeListState: CL714CodeListAdapter.getInitialState(),
  CL716CodeListState: CL716CodeListAdapter.getInitialState(),
  CL737CodeListState: CL737CodeListAdapter.getInitialState(),
  CL739CodeListState: CL739CodeListAdapter.getInitialState(),
  CL758CodeListState: CL758CodeListAdapter.getInitialState()
};

export function codeListReducer(
  state: CodeListState = initialState,
  codeListAction: any = {}
) {
  switch (codeListAction.type) {
    case codeListActions.fetchAddressedCustomsCodeListAction.type:
      return {
        ...state,
        addressedCustomsOfficeCodeState: addressedCustomsOfficeCodeAdapter.addMany(
          codeListAction.payload,
          state.addressedCustomsOfficeCodeState
        )
      };
    case codeListActions.fetchArrivalTransportTypeCodeListAction.type:
      return {
        ...state,
        arrivalTransportTypeCodeState: arrivalTransportTypeCodeAdapter.addMany(
          codeListAction.payload,
          state.arrivalTransportTypeCodeState
        )
      };
    case codeListActions.fetchCountryCodeListAction.type:
      return {
        ...state,
        countryCodeState: countryCodeAdapter.addMany(
          codeListAction.payload,
          state.countryCodeState
        )
      };
    case codeListActions.fetchCountryDataLevelCodeListAction.type:
      return {
        ...state,
        countryDataLevelCodeState: countryDataLevelCodeAdapter.addMany(
          codeListAction.payload,
          state.countryDataLevelCodeState
        )
      };
    case codeListActions.fetchLocationTypeCodeAction.type:
      return {
        ...state,
        locationTypeCodeState: locationTypeCodeAdapter.addMany(
          codeListAction.payload,
          state.locationTypeCodeState
        )
      };
    case codeListActions.fetchLocationTypeCombinedCodeAction.type:
      return {
        ...state,
        locationTypeCodeCombinedState: locationTypeCodeAdapter.addMany(
          codeListAction.payload,
          state.locationTypeCodeCombinedState
        )
      };
    case codeListActions.fetchPlaceOfUnloadingCodeAction.type:
      return {
        ...state,
        placeOfUnloadingCodeState: placeOfUnloadingCodeAdapter.addMany(
          codeListAction.payload,
          state.placeOfUnloadingCodeState
        )
      };
    case codeListActions.fetchQualifierCodeAction.type:
      return {
        ...state,
        qualifierCodeState: qualifierCodeAdapter.addMany(
          codeListAction.payload,
          state.qualifierCodeState
        )
      };
    case codeListActions.fetchWarehouseCodeAction.type:
      return {
        ...state,
        warehouseCodeState: warehouseTypeCodeAdapter.addMany(
          codeListAction.payload,
          state.warehouseCodeState
        )
      };
    case codeListActions.fetchTypeOfPersonCodeAction.type:
      return {
        ...state,
        typeOfPersonCodeState: personTypeCodeAdapter.addMany(
          codeListAction.payload,
          state.typeOfPersonCodeState
        )
      };

    case codeListActions.fetchPartyDataAction.type:
      return {
        ...state,
        partyInformationState: partyInformationAdapter.addMany(
          codeListAction.payload,
          state.partyInformationState
        )
      };
    case codeListActions.fetchCommunicationTypeCodeAction.type:
      return {
        ...state,
        communicationTypeState: communicationTypeAdapter.addMany(
          codeListAction.payload,
          state.communicationTypeState
        )
      };
    case codeListActions.fetchRepresentativeStatusCodeAction.type:
      return {
        ...state,
        representativeStatusState: representativeStatusAdapter.addMany(
          codeListAction.payload,
          state.representativeStatusState
        )
      };
    case codeListActions.fetchCL754CodeListAction.type:
      return {
        ...state,
        CL754CodeListState: CL754CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL754CodeListState
        )
      };
    case codeListActions.fetchCL214PrelodgedCodeListAction.type:
      return {
        ...state,
        CL214PrelodgedCodeListState: CL214PrelodgedCodeListAdapter.addMany(
          codeListAction.payload,
          state.CL214PrelodgedCodeListState
        )
      };
    case codeListActions.fetchCL214CombinedCodeListAction.type:
      return {
        ...state,
        CL214CombinedCodeListState: CL214CombinedCodeListAdapter.addMany(
          codeListAction.payload,
          state.CL214CombinedCodeListState
        )
      };
    case codeListActions.fetchCL704CodeListAction.type:
      return {
        ...state,
        CL704CodeListState: CL704CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL704CodeListState
        )
      };
    case codeListActions.fetchCL016CodeListAction.type:
      return {
        ...state,
        CL016CodeListState: CL016CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL016CodeListState
        )
      };
    case codeListActions.fetchCL709CodeListAction.type:
      return {
        ...state,
        CL709CodeListState: CL709CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL709CodeListState
        )
      };
    case codeListActions.fetchCL017CodeListAction.type:
      return {
        ...state,
        CL017CodeListState: CL017CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL017CodeListState
        )
      };
    case codeListActions.fetchCL213CodeListAction.type:
      return {
        ...state,
        CL213CodeListState: CL213CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL213CodeListState
        )
      };
    case codeListActions.fetchCL380CodeListAction.type:
      return {
        ...state,
        CL380CodeListState: CL380CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL380CodeListState
        )
      };
    case codeListActions.fetchCL712CodeListAction.type:
      return {
        ...state,
        CL712CodeListState: CL712CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL712CodeListState
        )
      };
    case codeListActions.fetchCL714CodeListAction.type:
      return {
        ...state,
        CL714CodeListState: CL714CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL714CodeListState
        )
      };
    case codeListActions.fetchCL716CodeListAction.type:
      return {
        ...state,
        CL716CodeListState: CL716CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL716CodeListState
        )
      };
    case codeListActions.fetchCL737CodeListAction.type:
      return {
        ...state,
        CL737CodeListState: CL737CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL737CodeListState
        )
      };
    case codeListActions.fetchCL739CodeListAction.type:
      return {
        ...state,
        CL739CodeListState: CL739CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL739CodeListState
        )
      };
    case codeListActions.fetchCL758CodeListAction.type:
      return {
        ...state,
        CL758CodeListState: CL758CodeListAdapter.addMany(
          codeListAction.payload,
          state.CL758CodeListState
        )
      };
    default:
      return state;
  }
}
