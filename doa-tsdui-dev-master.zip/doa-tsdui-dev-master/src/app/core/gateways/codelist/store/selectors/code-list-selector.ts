/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable sonarjs/no-duplicated-branches */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { LocationType, QualifierType } from '@features/edit-declaration/models';
import { createFeatureSelector, createSelector } from '@ngrx/store';

import { CountryDataLevelCode } from '../../model/country-data-level-code';
import { QualifierCode } from '../../model/qualifier-code';
import { CodeListState } from '../reducer/code-list.reducer';

import { PartyInformation } from './../../model/pary-info';

export const getCodeListFeature = createFeatureSelector<CodeListState>(
  'codeKey'
);

export const getCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return codeListState;
  }
);
export const getCountryDataLevel = (id: string) =>
  createSelector(getCodeListFeature, (state) => {
    let value = null;
    if (id !== '') id = id.substring(0, 2);
    const dataLevelList: CountryDataLevelCode[] = Object.values(
      state.countryDataLevelCodeState.entities
    );
    dataLevelList.forEach((codeNode) => {
      if (codeNode.value === id) {
        value = codeNode.definition;
      }
    });
    return value;
  });
export const getQualifierList = (id: string) =>
  createSelector(getCodeListFeature, (state) => {
    let qualifierList: QualifierCode[] = null;
    qualifierList = Object.values(state.qualifierCodeState.entities);
    let filteredQualifierList = null;
    switch (id) {
      case LocationType.A:
        filteredQualifierList = qualifierList.filter(
          (element) =>
            element.value === QualifierType.U ||
            element.value === QualifierType.V
        );
        return filteredQualifierList;
      case LocationType.B:
      case LocationType.C:
        filteredQualifierList = qualifierList.filter(
          (element) => element.value === QualifierType.U
        );
        return filteredQualifierList;
      case LocationType.D:
        filteredQualifierList = qualifierList.filter(
          (element) =>
            element.value === QualifierType.U ||
            element.value === QualifierType.V ||
            element.value === QualifierType.W ||
            element.value === QualifierType.X ||
            element.value === QualifierType.Y
        );
        return filteredQualifierList;
      default:
        return filteredQualifierList;
    }
  });
export const selectTypeOfPersonCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.typeOfPersonCodeState.entities);
  }
);
export const selectAddressCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(
      codeListState.addressedCustomsOfficeCodeState.entities
    );
  }
);
export const selectArrivalTransportCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.arrivalTransportTypeCodeState.entities);
  }
);
export const countryCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.countryCodeState.entities);
  }
);
export const countryDataLevelCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.countryDataLevelCodeState.entities);
  }
);
export const locationTypePrelodgedCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.locationTypeCodeState.entities);
  }
);
export const locationTypeCombinedCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.locationTypeCodeCombinedState.entities);
  }
);
export const placeOfUnloadingCodelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.placeOfUnloadingCodeState.entities);
  }
);
export const qualifierCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.qualifierCodeState.entities);
  }
);
export const warehouseTypeCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.warehouseCodeState.entities);
  }
);
export const getPartyData = (id: string) =>
  createSelector(getCodeListFeature, (state) => {
    let value = null;
    const dataLevelList: PartyInformation[] = Object.values(
      state.partyInformationState.entities
    );
    dataLevelList.forEach((codeNode) => {
      if (codeNode.id === id) {
        value = codeNode;
      }
    });
    return value;
  });
export const communicationTypeCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.communicationTypeState.entities);
  }
);
export const representativeStatusCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.representativeStatusState.entities);
  }
);

export const CL754CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL754CodeListState.entities);
  }
);
export const CL214PrelodgedCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL214PrelodgedCodeListState.entities);
  }
);
export const CL214CombinedCodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL214CombinedCodeListState.entities);
  }
);
export const CL709CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL709CodeListState.entities);
  }
);
export const CL213CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL213CodeListState.entities);
  }
);
export const CL704CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL704CodeListState.entities);
  }
);
export const CL017CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL017CodeListState.entities);
  }
);
export const CL016CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL016CodeListState.entities);
  }
);
export const CL380CodeList = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL380CodeListState.entities);
  }
);

export const CL712Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL712CodeListState.entities);
  }
);
export const CL714Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL714CodeListState.entities);
  }
);
export const CL716Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL716CodeListState.entities);
  }
);
export const CL737Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL737CodeListState.entities);
  }
);
export const CL739Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL739CodeListState.entities);
  }
);
export const CL758Codelist = createSelector(
  getCodeListFeature,
  (codeListState) => {
    return Object.values(codeListState.CL758CodeListState.entities);
  }
);
