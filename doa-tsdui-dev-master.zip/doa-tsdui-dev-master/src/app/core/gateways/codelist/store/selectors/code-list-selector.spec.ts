/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { Store, StoreModule } from '@ngrx/store';

import { LocationType } from './../../../../../features/edit-declaration/models/enums/location-type';
import { codeListReducer, CodeListState } from './../reducer/code-list.reducer';
import * as selectors from './code-list-selector';

describe('Store > Data > Selectors', () => {
  let store: Store<any>;
  const initState: CodeListState = {
    addressedCustomsOfficeCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    arrivalTransportTypeCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    countryCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    countryDataLevelCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    locationTypeCodeCombinedState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    locationTypeCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    placeOfUnloadingCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    qualifierCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    warehouseCodeState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL712CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL714CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL716CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL737CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL739CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    },
    CL758CodeListState: {
      ids: [0],
      entities: {
        0: {
          id: 0,
          definition: '',
          value: ''
        }
      }
    }
  };
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        StoreModule.forRoot({}),
        StoreModule.forFeature('codeKey', codeListReducer)
      ]
    });
    store = TestBed.inject(Store);
  });

  it('select Country Codelist', () => {
    const state = initState;
    const data = selectors.countryCodeList.projector(state);
    expect(data[0]).toBe(state.countryCodeState.entities[0]);
  });
  it('select addressedCustomsOfficeCodeState Codelist', () => {
    const state = initState;
    const data = selectors.selectAddressCodeList.projector(state);
    expect(data[0]).toBe(state.addressedCustomsOfficeCodeState.entities[0]);
  });
  it('select arrivalTransportTypeCodeState Codelist', () => {
    const state = initState;
    const data = selectors.selectArrivalTransportCodeList.projector(state);
    expect(data[0]).toBe(state.arrivalTransportTypeCodeState.entities[0]);
  });
  it('select countryDataLevelCodeState Codelist', () => {
    const state = initState;
    const data = selectors.countryDataLevelCodeList.projector(state);
    expect(data[0]).toBe(state.countryDataLevelCodeState.entities[0]);
  });
  it('select locationTypeCodeCombinedState Codelist', () => {
    const state = initState;
    const data = selectors.locationTypeCombinedCodeList.projector(state);
    expect(data[0]).toBe(state.locationTypeCodeCombinedState.entities[0]);
  });
  it('select locationTypeCodeState Codelist', () => {
    const state = initState;
    const data = selectors.locationTypePrelodgedCodeList.projector(state);
    expect(data[0]).toBe(state.locationTypeCodeState.entities[0]);
  });
  it('select placeOfUnloadingCodeState Codelist', () => {
    const state = initState;
    const data = selectors.placeOfUnloadingCodelist.projector(state);
    expect(data[0]).toBe(state.placeOfUnloadingCodeState.entities[0]);
  });
  it('select qualifierCodeState Codelist', () => {
    const state = initState;
    const data = selectors.qualifierCodeList.projector(state);
    expect(data[0]).toBe(state.qualifierCodeState.entities[0]);
  });
  it('select warehouseCodeState Codelist', () => {
    const state = initState;
    const data = selectors.warehouseTypeCodeList.projector(state);
    expect(data[0]).toBe(state.warehouseCodeState.entities[0]);
  });
  it('select Codelist', () => {
    const state = initState;
    const data = selectors.getCodeList.projector(state);
    expect(data).toBe(state);
  });
  it('select countryDataLevel', () => {
    const state = initState;
    const data = selectors.getCountryDataLevel('AD').projector(state);
    expect(data).toBeNull();
  });
  it('select QualifierList A', () => {
    const state = initState;
    const data = selectors.getQualifierList(LocationType.A).projector(state);
    expect(data).toBeDefined();
  });
  it('select QualifierList B', () => {
    const state = initState;
    const data = selectors.getQualifierList(LocationType.B).projector(state);
    expect(data).toBeDefined();
  });
  it('select QualifierList C', () => {
    const state = initState;
    const data = selectors.getQualifierList(LocationType.C).projector(state);
    expect(data).toBeDefined();
  });
  it('select QualifierList D', () => {
    const state = initState;
    const data = selectors.getQualifierList(LocationType.D).projector(state);
    expect(data).toBeDefined();
  });
  it('select CL712Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL712Codelist.projector(state);
    expect(data[0]).toBe(state.CL712CodeListState.entities[0]);
  });
  it('select CL714Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL714Codelist.projector(state);
    expect(data[0]).toBe(state.CL714CodeListState.entities[0]);
  });
  it('select CL716Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL716Codelist.projector(state);
    expect(data[0]).toBe(state.CL716CodeListState.entities[0]);
  });
  it('select CL737Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL737Codelist.projector(state);
    expect(data[0]).toBe(state.CL737CodeListState.entities[0]);
  });
  it('select CL739Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL739Codelist.projector(state);
    expect(data[0]).toBe(state.CL739CodeListState.entities[0]);
  });
  it('select CL758Codelist  Codelist', () => {
    const state = initState;
    const data = selectors.CL758Codelist.projector(state);
    expect(data[0]).toBe(state.CL758CodeListState.entities[0]);
  });
});
