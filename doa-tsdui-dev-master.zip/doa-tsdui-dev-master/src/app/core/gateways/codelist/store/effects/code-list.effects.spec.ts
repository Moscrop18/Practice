/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/require-await */
import {
  HttpClient,
  HttpClientModule,
  HttpHandler
} from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { provideMockActions } from '@ngrx/effects/testing';
import { ReplaySubject } from 'rxjs';

import {
  fetchCodeListData,
  fetchEoriListAction
} from '../action/code-list-actions';

import { CodeListEffects } from './code-list.effects';

describe('CodeListEffects', () => {
  let actions: ReplaySubject<any>;
  let effects: CodeListEffects;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CodeListEffects,
        provideMockActions(() => actions),
        HttpClient,
        HttpHandler
      ],
      imports: [RouterTestingModule, HttpClientModule]
    });
    effects = TestBed.get(CodeListEffects);
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });
  it('should fetch code lists', () => {
    actions = new ReplaySubject(1);
    const fetchCRSAction = {
      type: fetchCodeListData.type
    };
    actions.next(fetchCRSAction);
    effects.fetchCodeListEffect.subscribe((validation) => {
      expect(validation).toBeDefined();
    });
  });
  it('should execute fetchEoriListAction', () => {
    actions = new ReplaySubject(1);
    const fetchEoriAction = {
      type: fetchEoriListAction.type
    };
    actions.next(fetchEoriAction);
    effects.fetchEoriListEffect.subscribe((name) => {
      expect(name).toBeDefined();
    });
  });
});
