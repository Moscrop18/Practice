/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import {
  catchError,
  exhaustMap,
  map,
  shareReplay,
  switchMap
} from 'rxjs/operators';

import * as codeListActions from '../action/code-list-actions';
@Injectable()
export class CodeListEffects {
  fetchCodeListEffect = createEffect(() =>
    this.actions$.pipe(
      ofType(codeListActions.fetchCodeListData),
      exhaustMap((action) => {
        let codeList: any = null;
        return this.httpService
          .get<any>('../../../../../../assets/codelist/codelist.json')
          .pipe(
            map((data) => {
              codeList = data;
              return codeList;
            }),
            shareReplay({ bufferSize: 1, refCount: true }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      }),
      switchMap((data) => {
        return [
          codeListActions.fetchAddressedCustomsCodeListAction({
            payload: data.CL141
          }),
          codeListActions.fetchArrivalTransportTypeCodeListAction({
            payload: data.CL750
          }),
          codeListActions.fetchCountryCodeListAction({
            payload: data.CL718
          }),
          codeListActions.fetchCountryDataLevelCodeListAction({
            payload: data.CL733
          }),
          codeListActions.fetchLocationTypeCodeAction({
            payload: data.CL347Prelodged
          }),
          codeListActions.fetchLocationTypeCombinedCodeAction({
            payload: data.CL347Combined
          }),
          codeListActions.fetchPlaceOfUnloadingCodeAction({
            payload: data.CL144
          }),
          codeListActions.fetchQualifierCodeAction({
            payload: data.CL326
          }),
          codeListActions.fetchWarehouseCodeAction({
            payload: data.CL099
          }),
          codeListActions.fetchTypeOfPersonCodeAction({
            payload: data.CL729
          }),
          codeListActions.fetchCommunicationTypeCodeAction({
            payload: data.CL707
          }),
          codeListActions.fetchRepresentativeStatusCodeAction({
            payload: data.CL094
          }),
          codeListActions.fetchCL754CodeListAction({
            payload: data.CL754
          }),
          codeListActions.fetchCL214PrelodgedCodeListAction({
            payload: data.CL214Prelodged
          }),
          codeListActions.fetchCL214CombinedCodeListAction({
            payload: data.CL214Combined
          }),
          codeListActions.fetchCL709CodeListAction({
            payload: data.CL709
          }),
          codeListActions.fetchCL213CodeListAction({
            payload: data.CL213
          }),
          codeListActions.fetchCL704CodeListAction({
            payload: data.CL704
          }),
          codeListActions.fetchCL017CodeListAction({
            payload: data.CL017
          }),
          codeListActions.fetchCL016CodeListAction({
            payload: data.CL016
          }),
          codeListActions.fetchCL380CodeListAction({
            payload: data.CL380
          }),
          codeListActions.fetchCL712CodeListAction({
            payload: data.CL712
          }),
          codeListActions.fetchCL714CodeListAction({
            payload: data.CL714
          }),
          codeListActions.fetchCL716CodeListAction({
            payload: data.CL716
          }),
          codeListActions.fetchCL737CodeListAction({
            payload: data.CL737
          }),
          codeListActions.fetchCL739CodeListAction({
            payload: data.CL739
          }),
          codeListActions.fetchCL758CodeListAction({
            payload: data.CL758
          })
        ];
      })
    )
  );
  fetchEoriListEffect = createEffect(() =>
    this.actions$.pipe(
      ofType(codeListActions.fetchEoriListAction),
      switchMap((action) => {
        let eoriList: any = null;
        return this.httpService
          .get<any>('../../../assets/crs-mock/partyData.json')
          .pipe(
            map((data) => {
              eoriList = data;
              return eoriList;
            }),
            catchError((error) => {
              console.error(error);
              return of();
            })
          );
      }),
      switchMap((data) => [
        codeListActions.fetchPartyDataAction({
          payload: data.partyList
        })
      ])
    )
  );
  constructor(private actions$: Actions, private httpService: HttpClient) {}
}
