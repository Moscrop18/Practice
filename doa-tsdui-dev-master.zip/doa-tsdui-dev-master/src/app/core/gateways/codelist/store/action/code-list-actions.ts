import { CommunicationTypeCodeList } from '@core/gateways/codelist/model/communication-type';
import { createAction, props } from '@ngrx/store';

import {
  AddressedCustomsOfficeCode,
  Codelist
} from '../../model/addressed-customs-office-code';
import { ArrivalTransportTypeCode } from '../../model/arrival-transport-type-code';
import { CountryCode } from '../../model/country-code';
import { CountryDataLevelCode } from '../../model/country-data-level-code';
import { LocationTypeCode } from '../../model/location-type-code';
import { QualifierCode } from '../../model/qualifier-code';
import { WarehouseTypeCode } from '../../model/warehouse-type-code';

import { PartyInformation } from './../../model/pary-info';
import { PlaceOfUnloadingCode } from './../../model/place-of-unloading-code';
import { RepresentativeStatusCodeList } from './../../model/representative-status';
import { TypeOfPersonCode } from './../../model/type-of-person-code';

export const fetchCodeList = createAction(
  'codeList/ADD_FETCH_CODE_LIST_ACTION'
);
export const fetchCodeListSuccess = createAction(
  'codeList/ADD_FETCH_CODE_LIST_SUCCESS_ACTION',
  props<{ payload: { codeListData: string } }>()
);
export const fetchCodeListData = createAction(
  'codeList/ADD_FETCH_CODE_LIST_DATA_ACTION'
);
export const fetchAddressedCustomsCodeListAction = createAction(
  'codeList/ADD_FETCH_ADDRESSED_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: AddressedCustomsOfficeCode[] }>()
);
export const fetchArrivalTransportTypeCodeListAction = createAction(
  'codeList/ADD_FETCH_ARRIVAL_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: ArrivalTransportTypeCode[] }>()
);
export const fetchCountryCodeListAction = createAction(
  'codeList/ADD_FETCH_COUNTRY_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: CountryCode[] }>()
);
export const fetchCountryDataLevelCodeListAction = createAction(
  'codeList/ADD_FETCH_COUNTRY_DATA_LEVEL_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: CountryDataLevelCode[] }>()
);
export const fetchLocationTypeCodeAction = createAction(
  'codeList/ADD_FETCH_LOCATION_TYPE_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: LocationTypeCode[] }>()
);
export const fetchLocationTypeCombinedCodeAction = createAction(
  'codeList/ADD_FETCH_LOCATION_TYPE_COMBINED_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: LocationTypeCode[] }>()
);
export const fetchPlaceOfUnloadingCodeAction = createAction(
  'codeList/ADD_FETCH_PLACE_OF_UNLOADING_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: PlaceOfUnloadingCode[] }>()
);
export const fetchQualifierCodeAction = createAction(
  'codeList/ADD_FETCH_QUALIFIER_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: QualifierCode[] }>()
);
export const fetchWarehouseCodeAction = createAction(
  'codeList/ADD_FETCH_WAREHOUSE_TYPE_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: WarehouseTypeCode[] }>()
);
export const fetchTypeOfPersonCodeAction = createAction(
  'codeList/ADD_FETCH_PERSON_TYPE_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: TypeOfPersonCode[] }>()
);
export const fetchEoriListAction = createAction(
  'codeList/ADD_FETCH_EORI_LIST_ACTION'
);
export const fetchPartyDataAction = createAction(
  'codeList/ADD_FETCH_EORI_LIST_ACTION_SUCCESS',
  props<{ payload: PartyInformation[] }>()
);
export const fetchCommunicationTypeCodeAction = createAction(
  'codeList/ADD_FETCH_COMMUNICATION_TYPE_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: CommunicationTypeCodeList[] }>()
);
export const fetchRepresentativeStatusCodeAction = createAction(
  'codeList/ADD_FETCH_REPRESENTATIVE_STATUS_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: RepresentativeStatusCodeList[] }>()
);

export const fetchCL754CodeListAction = createAction(
  'codeList/ADD_FETCH_CL754_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);

export const fetchCL214PrelodgedCodeListAction = createAction(
  'codeList/ADD_FETCH_CL214_PRE_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL214CombinedCodeListAction = createAction(
  'codeList/ADD_FETCH_CL214_COM_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL709CodeListAction = createAction(
  'codeList/ADD_FETCH_CL709_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL213CodeListAction = createAction(
  'codeList/ADD_FETCH_CL213_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL704CodeListAction = createAction(
  'codeList/ADD_FETCH_CL704_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL017CodeListAction = createAction(
  'codeList/ADD_FETCH_CL017_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL016CodeListAction = createAction(
  'codeList/ADD_FETCH_CL016_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL380CodeListAction = createAction(
  'codeList/ADD_FETCH_CL380_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL712CodeListAction = createAction(
  'codeList/ADD_FETCH_CL712_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL714CodeListAction = createAction(
  'codeList/ADD_FETCH_CL714_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL716CodeListAction = createAction(
  'codeList/ADD_FETCH_CL716_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL737CodeListAction = createAction(
  'codeList/ADD_FETCH_CL737_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL739CodeListAction = createAction(
  'codeList/ADD_FETCH_CL739_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
export const fetchCL758CodeListAction = createAction(
  'codeList/ADD_FETCH_CL758_CODE_LIST_ACTION_SUCCESS',
  props<{ payload: Codelist[] }>()
);
