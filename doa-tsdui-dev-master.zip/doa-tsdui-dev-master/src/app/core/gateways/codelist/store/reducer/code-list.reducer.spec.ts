import {
  fetchAddressedCustomsCodeListAction,
  fetchArrivalTransportTypeCodeListAction,
  fetchCountryCodeListAction,
  fetchCountryDataLevelCodeListAction,
  fetchLocationTypeCodeAction,
  fetchLocationTypeCombinedCodeAction,
  fetchPlaceOfUnloadingCodeAction,
  fetchQualifierCodeAction,
  fetchCL380CodeListAction,
  fetchCL213CodeListAction,
  fetchCL017CodeListAction,
  fetchCL709CodeListAction,
  fetchWarehouseCodeAction,
  fetchCL016CodeListAction,
  fetchCL704CodeListAction,
  fetchCL754CodeListAction,
  fetchCL214CombinedCodeListAction,
  fetchCL214PrelodgedCodeListAction,
  fetchCL712CodeListAction,
  fetchCL714CodeListAction,
  fetchCL716CodeListAction,
  fetchCL737CodeListAction,
  fetchCL739CodeListAction,
  fetchCL758CodeListAction
} from '../action/code-list-actions';

import * as codeReducer from './code-list.reducer';

describe('codeListReducer', () => {
  it('should return the default state', () => {
    const action = { type: '' };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(state.addressedCustomsOfficeCodeState).toBeDefined();
  });
  it('should return the state with addressedCustomsOfficeCodeState', () => {
    const action = {
      type: fetchAddressedCustomsCodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(
      Object.keys(state.addressedCustomsOfficeCodeState.entities).length
    ).toBe(2);
  });
  it('should return the state with arrivalTransportTypeCodeState', () => {
    const action = {
      type: fetchArrivalTransportTypeCodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(
      Object.keys(state.arrivalTransportTypeCodeState.entities).length
    ).toBe(2);
  });
  it('should return the state with countryCodeState', () => {
    const action = {
      type: fetchCountryCodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.countryCodeState.entities).length).toBe(2);
  });
  it('should return the state with countryDataLevelCodeState', () => {
    const action = {
      type: fetchCountryDataLevelCodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.countryDataLevelCodeState.entities).length).toBe(
      2
    );
  });
  it('should return the state with locationTypeCodeState', () => {
    const action = {
      type: fetchLocationTypeCodeAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.locationTypeCodeState.entities).length).toBe(2);
  });
  it('should return the state with locationTypeCodeCombinedState', () => {
    const action = {
      type: fetchLocationTypeCombinedCodeAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(
      Object.keys(state.locationTypeCodeCombinedState.entities).length
    ).toBe(2);
  });
  it('should return the state with placeOfUnloadingCodeState', () => {
    const action = {
      type: fetchPlaceOfUnloadingCodeAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.placeOfUnloadingCodeState.entities).length).toBe(
      2
    );
  });
  it('should return the state with qualifierCodeState', () => {
    const action = {
      type: fetchQualifierCodeAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.qualifierCodeState.entities).length).toBe(2);
  });
  it('should return the state with warehouseCodeState', () => {
    const action = {
      type: fetchWarehouseCodeAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.warehouseCodeState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL380CodeListAction', () => {
    const action = {
      type: fetchCL380CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL380CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL712CodeListAction', () => {
    const action = {
      type: fetchCL712CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL712CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL714CodeListAction', () => {
    const action = {
      type: fetchCL714CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL714CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL716CodeListAction', () => {
    const action = {
      type: fetchCL716CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL716CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL737CodeListAction', () => {
    const action = {
      type: fetchCL737CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL737CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL739CodeListAction', () => {
    const action = {
      type: fetchCL739CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL739CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL758CodeListAction', () => {
    const action = {
      type: fetchCL758CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL758CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL213CodeListAction', () => {
    const action = {
      type: fetchCL213CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL213CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL709CodeListAction', () => {
    const action = {
      type: fetchCL709CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL709CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL017CodeListAction', () => {
    const action = {
      type: fetchCL017CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);

    expect(Object.keys(state.CL017CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL016CodeListAction', () => {
    const action = {
      type: fetchCL016CodeListAction.type,
      payload: [
        { id: 0, value: '', definition: '' },
        { id: 1, value: '', definition: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL016CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL704CodeListAction', () => {
    const action = {
      type: fetchCL704CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL704CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL754CodeListAction', () => {
    const action = {
      type: fetchCL754CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL754CodeListState.entities).length).toBe(2);
  });

  it('should return the state with fetchCL214CombinedCodeListAction', () => {
    const action = {
      type: fetchCL214CombinedCodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL214CombinedCodeListState.entities).length).toBe(
      2
    );
  });

  it('should return the state with fetchCL214PrelodgedCodeListAction', () => {
    const action = {
      type: fetchCL214PrelodgedCodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL214PrelodgedCodeListState.entities).length).toBe(
      2
    );
  });
  it('should return the state with fetchCL712CodeListAction', () => {
    const action = {
      type: fetchCL712CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL712CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL714CodeListAction', () => {
    const action = {
      type: fetchCL714CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL714CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL716CodeListAction', () => {
    const action = {
      type: fetchCL716CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL716CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL737CodeListAction', () => {
    const action = {
      type: fetchCL737CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL737CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL739CodeListAction', () => {
    const action = {
      type: fetchCL739CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL739CodeListState.entities).length).toBe(2);
  });
  it('should return the state with fetchCL758CodeListAction', () => {
    const action = {
      type: fetchCL758CodeListAction.type,
      payload: [
        { id: 0, value: '', label: '' },
        { id: 1, value: '', label: '' }
      ]
    };
    const state = codeReducer.codeListReducer(codeReducer.initialState, action);
    expect(Object.keys(state.CL758CodeListState.entities).length).toBe(2);
  });
});
