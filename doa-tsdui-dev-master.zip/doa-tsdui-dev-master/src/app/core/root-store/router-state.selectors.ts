import { RouterReducerState } from '@ngrx/router-store';
import { createFeatureSelector, createSelector } from '@ngrx/store';

import { MergedRoute } from './root.reducer';

export const getRouterReducerState = createFeatureSelector<
  RouterReducerState<MergedRoute>
>('router');

export const getMergedRoute = createSelector(
  getRouterReducerState,
  (routerReducerState) => routerReducerState?.state
);

export const getRouteParamSelector = createSelector(
  getMergedRoute,
  (s) => s.params
);
export const getRouteQueryParamSelector = createSelector(
  getMergedRoute,
  (s) => s.queryParams
);
