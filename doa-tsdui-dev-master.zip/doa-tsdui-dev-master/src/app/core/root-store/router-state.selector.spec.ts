import { TestBed } from '@angular/core/testing';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { RouterStateSerializer, RouterReducerState } from '@ngrx/router-store';
import { StoreModule } from '@ngrx/store';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';

import { MergedRoute, RootState } from './root.reducer';
import {
  getRouterReducerState,
  getMergedRoute
} from './router-state.selectors';
import { MergedRouterStateSerializer } from './utils';

describe('Root Selectors', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(ROOT_REDUCERS, {
          runtimeChecks: {
            strictStateImmutability: true,
            strictActionImmutability: true
          }
        })
      ],
      providers: [
        {
          provide: RouterStateSerializer,
          useClass: MergedRouterStateSerializer
        }
      ]
    });
  });

  it('getRouterReducerState', () => {
    const result = getRouterReducerState({
      router: {}
    });
    expect(result).toEqual({});
  });

  it('get merged route', () => {
    const mergedRoute: MergedRoute = {
      url: 'http://example.com',
      queryParams: {},
      params: {},
      data: {}
    };

    const routerReducerState: RouterReducerState<MergedRoute> = {
      state: mergedRoute,
      navigationId: 20
    };
    expect(getMergedRoute({ router: routerReducerState })).toEqual(mergedRoute);
  });
});
