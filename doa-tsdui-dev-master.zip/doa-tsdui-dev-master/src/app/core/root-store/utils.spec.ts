/* eslint-disable @typescript-eslint/no-unsafe-argument */
import { MergedRoute } from './root.reducer';
import { MergedRouterStateSerializer } from './utils';

describe('MergedRouterStateSerializer', () => {
  let mergedRouterStateSerializer: MergedRouterStateSerializer;

  beforeEach(() => {
    mergedRouterStateSerializer = new MergedRouterStateSerializer();
  });
  it('should be created', () => {
    expect(mergedRouterStateSerializer).toBeTruthy();
  });

  it('should be serialize', () => {
    const expected: MergedRoute = {
      url: 'this-is-url',
      queryParams: {},
      params: {},
      data: {}
    };

    const input: any = {
      url: 'this-is-url',
      root: {
        url: [],
        params: {},
        data: {},
        queryParams: {},
        fragment: 'test-fragment',
        children: []
      }
    };
    expect(mergedRouterStateSerializer.serialize(input)).toBeTruthy();
    expect(mergedRouterStateSerializer.serialize(input)).toEqual(expected);
  });
});
