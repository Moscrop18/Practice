import { InjectionToken } from '@angular/core';
import { Data, Params } from '@angular/router';
import * as fromAuth from '@core/components/auth/store/reducers/auth.reducer';
import * as fromSettings from '@core/components/settings/store/reducers/settings.reducer';
import { environment } from '@environments/environment';
import { routerReducer, RouterReducerState } from '@ngrx/router-store';
import {
  Action,
  ActionReducer,
  ActionReducerMap,
  MetaReducer
} from '@ngrx/store';
import { localStorageSync } from 'ngrx-store-localstorage';

export interface MergedRoute {
  url: string;
  queryParams: Params;
  params: Params;
  data: Data;
}

export interface RootState {
  [fromAuth.authFeatureKey]: fromAuth.AuthState;
  [fromSettings.settingsFeatureKey]: fromSettings.SettingsState;
  router: RouterReducerState<MergedRoute>;
}

export const ROOT_REDUCERS = new InjectionToken<
  ActionReducerMap<RootState, Action>
>('Root reducers token', {
  factory: () => ({
    [fromAuth.authFeatureKey]: fromAuth.reducers,
    [fromSettings.settingsFeatureKey]: fromSettings.reducers,
    router: routerReducer
  })
});

// console.log all actions
export function logger(
  reducer: ActionReducer<RootState>
): ActionReducer<RootState> {
  return (state, action) => {
    const result = reducer(state, action);
    console.groupCollapsed(action.type);
    console.log('prev state', state);
    console.log('action', action);
    console.log('next state', result);
    console.groupEnd();

    return result;
  };
}

// only store limited data
export function localStorageSyncReducer(
  reducer: ActionReducer<RootState>
): ActionReducer<RootState> {
  validateLocalStorageKeys([
    fromAuth.authFeatureKey,
    fromSettings.settingsFeatureKey
  ]);
  return localStorageSync({
    keys: [
      { [fromAuth.authFeatureKey]: ['user'] },
      fromSettings.settingsFeatureKey
    ],
    rehydrate: true
  })(reducer);
}
/**
 * Handle potential corruption of the local storage.
 * Check if the mentioned keys can be parsed as json, if not remove them
 */
function validateLocalStorageKeys(keys: string[]) {
  keys.forEach((key) => {
    try {
      JSON.parse(window.localStorage.getItem(key));
    } catch (e) {
      window.localStorage.removeItem(key);
    }
  });
}

/**
 * By default, @ngrx/store uses combineReducers with the reducer map to compose
 * the root meta-reducer. To add more meta-reducers, provide an array of meta-reducers
 * that will be composed to form the root meta-reducer.
 */
export const metaReducers: MetaReducer<RootState>[] = !environment.production
  ? [logger, localStorageSyncReducer]
  : [localStorageSyncReducer];
