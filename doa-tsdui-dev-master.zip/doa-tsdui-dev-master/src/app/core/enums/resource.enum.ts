/**
 * Resources accessible by an authorized user.
 */
export enum Resource {
  HOME = 'Home',
  Order = 'Order',
  HELLO = 'Hello',
  NORESOURCE = 'NoResource',
  PROPERTIES = 'Properties',
  FORMS = 'Forms',
  DATATABLES = 'Datatables',
  CHARTS = 'Charts',
  SCROLLTOTOP = 'Scrooltotop',
  CRUMBTRAIL = 'Crumbtrail',
  LABELS = 'Labels',
  ALERTS = 'Alerts',
  LOGGING = 'Logging',
  AUDITS = 'Audits',
  COOKIEPOLICY = 'Cookiespolicy',
  ANALYTICS = 'Analytics',
  CONTEXTUALHELPINAPPLICATION = 'Contextualhelpinapplication',
  CONTEXTUALHELPINLINE = 'Contextualhelpinline',
  CONTACT = 'Contact'
}
