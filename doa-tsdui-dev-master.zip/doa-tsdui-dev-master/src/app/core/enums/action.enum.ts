/**
 * Actions that can be performed on any given {@link Resource} by an authorized user.
 */

export enum Action {
  SEARCH = 'Search',
  CONSULT = 'Consult',
  CREATE = 'Create',
  UPDATE = 'Update',
  REMOVE = 'Remove',
  SAY = 'Say',
  NOACTION = 'NoAction',
  VIEW = 'View'
}
