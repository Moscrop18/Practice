import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { PipesModule } from '@core/pipes/pipes.module';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { MaterialModule } from '@material/material.module';
import { TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';

import { PageNotFoundRoutingModule } from './page-not-found-routing.module';
import { PageNotFoundComponent } from './page-not-found.component';

@NgModule({
  declarations: [PageNotFoundComponent],
  imports: [
    CommonModule,
    SharedModule,
    PageNotFoundRoutingModule,
    PipesModule,
    MaterialModule,
    TranslateModule
  ],
  providers: [ModuleLoadService]
})
export class PageNotFoundModule {}
