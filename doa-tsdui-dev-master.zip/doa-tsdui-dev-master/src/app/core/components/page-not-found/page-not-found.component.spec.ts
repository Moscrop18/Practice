import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { Store } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { PageNotFoundComponent } from './page-not-found.component';

describe('PageNotFoundComponent', () => {
  let component: PageNotFoundComponent;
  let fixture: ComponentFixture<PageNotFoundComponent>;
  let store: Store<any>;
  const translations: any = {
    'layout.search': 'search'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [PageNotFoundComponent],
        imports: [
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: FakeLoader }
          })
        ],
        providers: [
          ModuleLoadService,
          {
            provide: Store,
            useValue: {
              dispatch: jest.fn(),
              pipe: jest.fn()
            }
          }
        ]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(PageNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
