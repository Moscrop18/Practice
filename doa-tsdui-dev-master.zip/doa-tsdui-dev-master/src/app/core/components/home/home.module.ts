import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ManageDeclarationModule } from '@features/manage-declaration/manage-declaration.module';
import { StatusHistoryService } from '@features/manage-declaration/services/status-history.service';
import { StatusModule } from '@features/manage-declaration/status/status.module';
import { MaterialModule } from '@material/index';
import { SharedModule } from '@shared/shared.module';

import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    SharedModule,
    HomeRoutingModule,
    MaterialModule,
    ManageDeclarationModule
  ]
})
export class HomeModule {}
