import { Component } from '@angular/core';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent {
  bannerSubscription: Subscription;
  bannerType: string;
  bannerStatus: string;
  consultGenInfodata$: Observable<ConsultGeneralInformation>;
  constructor(
    private moduleLoad: ModuleLoadService,
    private manageDeclarationFacade: ManageDeclarationFacade
  ) {
    this.consultGenInfodata$ = this.manageDeclarationFacade.fetchGeneralInformationData();
  }
  ngOnInit() {
    this.bannerSubscription = this.manageDeclarationFacade
      .fetchBannerState()
      .subscribe((banner) => {
        if (banner) {
          this.bannerType = banner.bannerType;
          this.bannerStatus = banner.bannerStatus;
        }
      });
    this.moduleLoad.isErrorPage(false);
  }
}
