import { HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { metaReducers, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { GeneralInfoEffects } from '@features/edit-declaration/general-information/store/effects/general-info.effects';
import { ManageDeclarationModule } from '@features/manage-declaration/manage-declaration.module';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { Observable, of } from 'rxjs';

import { HomeComponent } from './home.component';

jest.useRealTimers();
describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let facade: ManageDeclarationFacade;
  const translations: any = {
    'layout.search': 'search'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [HomeComponent],
        imports: [
          SharedModule,
          ManageDeclarationModule,
          HttpClientModule,
          RouterTestingModule,
          StoreModule.forRoot(ROOT_REDUCERS, {
            metaReducers,
            runtimeChecks: {
              strictStateImmutability: true,
              strictActionImmutability: true,
              strictStateSerializability: true,
              strictActionSerializability: true
            }
          }),
          EffectsModule.forRoot([GeneralInfoEffects]),
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: FakeLoader }
          })
        ],
        providers: [ModuleLoadService, ConfigService, ManageDeclarationFacade]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    jest.setTimeout(30000);
    expect(component).toBeTruthy();
  });
});
