import { User, Credentials } from '@core/models/user';
import { createAction, props } from '@ngrx/store';

export const onErrorPage = createAction(
  '[Auth] Error Page',
  props<{ isError: boolean }>()
);
export const autoLogon = createAction(
  '[Auth] Auto Logon',
  props<{ user: User; returnUrl: string }>()
);
export const autoLogonSuccess = createAction(
  '[Auth] Auto Logon Success',
  props<{ user: User; returnUrl: string }>()
);
export const homeRedirect = createAction('[Auth] Home Redirect');
export const idleTimeout = createAction('[Auth] Idle Timeout');
export const logout = createAction('[Auth] Logout');
