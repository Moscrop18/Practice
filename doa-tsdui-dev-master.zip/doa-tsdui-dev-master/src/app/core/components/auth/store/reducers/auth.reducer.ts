/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { User } from '@core/models/user';
import { Action, createReducer, on } from '@ngrx/store';

import * as AuthActions from '../actions/auth.actions';

export const authFeatureKey = 'auth';

export interface AuthState {
  loading: boolean;
  loaded: boolean;
  error?: string;
  isErrorPage?: boolean;
  user: User | null;
}

export const initialState: AuthState = {
  loading: false,
  loaded: false,
  user: null
};

const authReducer = createReducer(
  initialState,
  on(AuthActions.autoLogonSuccess, (state, { user }) => ({
    ...state,
    loading: false,
    loaded: true,
    user
  })),
  on(AuthActions.logout, () => initialState),
  on(AuthActions.onErrorPage, (state, { isError }) => ({
    ...state,
    isErrorPage: isError
  }))
);

export function reducers(state: AuthState | undefined, action: Action) {
  return authReducer(state, action);
}

export const isLoggedIn = (state: AuthState) => state.user != null;
export const getLoginError = (state: AuthState) => state.error;
export const getLoginLoading = (state: AuthState) => state.loading;
export const getUser = (state: AuthState) => state.user;
export const isOnErrorPage = (state: AuthState) => state.isErrorPage;
