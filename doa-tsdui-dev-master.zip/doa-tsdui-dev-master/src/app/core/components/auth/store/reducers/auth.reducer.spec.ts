/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import * as AuthActions from '../actions/auth.actions';

import {
  AuthState,
  isLoggedIn,
  getLoginError,
  getLoginLoading,
  getUser,
  authFeatureKey,
  initialState,
  reducers
} from './auth.reducer';

describe('Auth Reducer', () => {
  describe('an unknown action', () => {
    it('should return the default state', () => {
      const action = { type: 'NOOP' } as any;

      const result = reducers(undefined, action);

      expect(result).toBe(initialState);
    });
  });

  describe('[Auth] logout', () => {
    it('should logout state', () => {
      const action = AuthActions.logout();
      const result = reducers(initialState, action);
      expect(result).toBe(initialState);
    });
  });

  describe('AuthReducers', () => {
    it('AuthState should have appropriate fields and types', () => {
      const authState: AuthState = {
        isLoggedIn: false,
        loading: false,
        loaded: false,
        error: 'some error',
        user: {
          name: 'my name'
        }
      } as AuthState;
      expect(authState).toBeTruthy();
    });

    it('should check All Constants values', () => {
      expect(isLoggedIn(initialState)).toBe(initialState.user != null);
      expect(getLoginError(initialState)).toBe(initialState.error);
      expect(getLoginLoading(initialState)).toBe(initialState.loading);
      expect(getUser(initialState)).toBe(initialState.user);
      expect(authFeatureKey).toBe('auth');
    });
  });
});
