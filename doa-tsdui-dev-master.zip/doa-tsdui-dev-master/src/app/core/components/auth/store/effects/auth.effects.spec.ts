/* eslint-disable @typescript-eslint/no-unsafe-call */
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import {
  generateUser,
  generateValidCredential,
  generateInvalidCredential
} from '@core/mocks/data/user.test.data';
import { ConfigService } from '@core/services/config/config.service';
import { provideMockActions } from '@ngrx/effects/testing';
import { hot, cold } from 'jasmine-marbles';
import { Observable } from 'rxjs';

import * as AuthActions from '../actions/auth.actions';

import { AuthEffects } from './auth.effects';

describe('AuthEffects', () => {
  let actions$: Observable<any>;
  let effects: AuthEffects;
  let httpClient: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      providers: [
        AuthEffects,
        HttpClient,
        HttpHandler,
        ConfigService,
        provideMockActions(() => actions$),
        {
          useValue: {
            login: jest.fn(),
            logout: jest.fn()
          }
        }
      ]
    });
    httpClient = TestBed.inject(HttpClient);
    effects = TestBed.inject<AuthEffects>(AuthEffects);
  });

  it('AuthEffects should be created', () => {
    expect(effects).toBeTruthy();
  });

  it('should return an autoLogon action, with the token, on success', () => {
    const action = AuthActions.autoLogon({
      user: { name: 'abc' },
      returnUrl: '/'
    });
    const outcome = AuthActions.autoLogonSuccess({
      user: { name: 'abc' },
      returnUrl: '/'
    });

    actions$ = hot('-a', { a: action });
    const expected = cold('-b', { b: outcome });
    expect(effects.autoLogon$).toBeObservable(expected);
  });
});
