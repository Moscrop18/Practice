/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigService } from '@core/services/config/config.service';
import { environment } from '@environments/environment';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { fromEvent, merge, timer } from 'rxjs';
import { map, switchMapTo, tap } from 'rxjs/operators';

import * as AuthActions from '../actions/auth.actions';
@Injectable()
export class AuthEffects {
  constructor(
    private router: Router,
    private actions$: Actions,
    private httpClient: HttpClient,
    private configService: ConfigService
  ) {
    this.apiUrl = this.configService.getConfig().apiUrl;
  }
  private apiUrl: string;
  clicks$ = fromEvent(document, 'click');
  keys$ = fromEvent(document, 'keydown');
  mouse$ = fromEvent(document, 'mousemove');

  idle$ = createEffect(() =>
    merge(this.clicks$, this.keys$, this.mouse$).pipe(
      switchMapTo(timer(environment.inactivityTimeout)),
      map(() => AuthActions.idleTimeout())
    )
  );

  logoutIdleUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(AuthActions.idleTimeout),
      map(() => AuthActions.logout())
    )
  );

  logout$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.logout),
        tap(() => {
          // reload the page which will allow the user to go back to the original page after login
          sessionStorage.clear();
          location.reload();
        })
      ),
    { dispatch: false }
  );

  homeRedirect$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.homeRedirect),
        tap((isLoggedIn) => {
          if (isLoggedIn) {
            this.router.navigate(['/']);
          }
        })
      ),
    { dispatch: false }
  );

  autoLogon$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.autoLogon),
        map((data) =>
          AuthActions.autoLogonSuccess({
            user: data.user,
            returnUrl: data.returnUrl
          })
        )
      ),
    { useEffectsErrorHandler: false }
  );

  autoLogonSuccess$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(AuthActions.autoLogonSuccess),
        tap((data) => {
          this.router.navigateByUrl(data.returnUrl);
        })
      ),
    { dispatch: false }
  );
}
