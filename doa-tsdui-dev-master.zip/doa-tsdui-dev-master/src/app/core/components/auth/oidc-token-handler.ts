import { HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';

export abstract class OIDCTokenHandler {
  public abstract saveAvailableAuthenticationToken(response: HttpResponse<any>);
  public abstract getAccessToken();
  public abstract getUserInfo();
  public abstract getPermissions();
  public abstract refreshTokens();
}
