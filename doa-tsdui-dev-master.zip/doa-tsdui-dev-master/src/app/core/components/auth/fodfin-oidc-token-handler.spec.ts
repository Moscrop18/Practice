/* eslint-disable @typescript-eslint/unbound-method */
import {
  HttpClient,
  HttpHandler,
  HttpHeaders,
  HttpResponse
} from '@angular/common/http';
import { fakeAsync, TestBed } from '@angular/core/testing';
import { cold } from 'jasmine-marbles';

import { FodFinOIDCTokenHandler } from './fodfin-oidc-token-handler';

describe('FodFinOIDCTokenHandler', () => {
  let fodFinOIDCTokenHandler: FodFinOIDCTokenHandler;
  let http: HttpClient;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HttpClient, HttpHandler]
    });
    fodFinOIDCTokenHandler = TestBed.inject<FodFinOIDCTokenHandler>(
      FodFinOIDCTokenHandler
    );
    http = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    const service: FodFinOIDCTokenHandler = TestBed.inject(
      FodFinOIDCTokenHandler
    );
    expect(service).toBeTruthy();
  });

  it('should test saveAvailableAuthenticationToken with minfin-iam_usertoken', () => {
    const headers: HttpHeaders = new HttpHeaders().set(
      'minfin-iam_usertoken',
      'eyJ0eXAiOiJKV1QiLCJraWQiOiJSUklpdWtxcGgzUGlJUDBvN0ZQT3l5NzBxaDQ9IiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJ0dHNkMDFhYSIsInByZWZlcnJlZExhbmd1YWdlIjoibmwiLCJtYWlsIjoidGVzdHVzZXIudHNkMDFAbWluZmluLmZlZC5iZSIsIm9mZmljZXMiOlsiTjZBMjAwMSJdLCJnaXZlbk5hbWUiOiJ0ZXN0dXNlciIsImlzcyI6Imh0dHBzOi8vYW0tYS5maW5iZWwuaW50cmEvc3NvL29hdXRoMiIsImNuIjoidHNkMDEgdGVzdHVzZXIiLCJzc28tdWlkIjoidHRzZDAxYWEiLCJjbGllbnRfaWQiOiJ0ZW1wc3RvcmFnZSIsImF1ZCI6InRlbXBzdG9yYWdlIiwidWlkIjoidGVzdHVzZXIudHNkMDEiLCJ1c2VyX3R5cGUiOiJpbnRlcm5hbCIsInBlcm1pc3Npb25zIjp7InRlbXBzdG9yYWdlIjp7IlJDUmFuZG9tU2VsZWN0aWVTdGFydCI6eyJDcmVhdGUiOiJ0cnVlIn0sIklycmVndWxhcml0eURlY2lzaW9uVFNEIjp7Ik1hbmFnZSI6InRydWUifSwiUkNNYW51YWxTZWxlY3QiOnsiTW9kaWZ5IjoidHJ1ZSJ9LCJEZWNsYXJhdGlvblRTRFN0YXR1c0NoYW5nZSI6eyJNb2RpZnkiOiJ0cnVlIn0sIkFtZW5kbWVudFRTRCI6eyJDcmVhdGUiOiJ0cnVlIn0sIlJDQ29uc3VsdCI6eyJBbGxvdyI6InRydWUifSwiRHJhZnREZWNsYXJhdGlvblRTRCI6eyJNYW5hZ2UiOiJ0cnVlIn0sIkRlY2xhcmF0aW9uUmVwb3J0Ijp7IkFsbG93IjoidHJ1ZSJ9LCJJbnZhbGlkYXRlVFNEIjp7IkNyZWF0ZSI6InRydWUifSwiRGVjbGFyYXRpb25UU0QiOnsiQ29uc3VsdCI6InRydWUifSwiUkNEZXNlbGVjdCI6eyJNb2RpZnkiOiJ0cnVlIn0sIlJlZ2lzdGVyTWVhc3VyZXMiOnsiTW9kaWZ5IjoidHJ1ZSJ9LCJBbGxEZWNsYXJhdGlvblRTRCI6eyJDb25zdWx0IjoidHJ1ZSJ9fX0sInNuIjoidHNkMDEiLCJleHAiOjE2NTU4Mzk0NDYsImFsbG93ZWRBcHBzIjpbInRlbXBzdG9yYWdlIl19.bfynHEJuaGcrQyKcPPq02GZojU7eFTs-njbAzEkv62dC1BmI6rktbIEboA0676FIRcwR-ou6syVnWoZP3a6Tv1j1b2FY7ymyGydiMz0vxVVX58DV67bF7UAGLDc6Rcm6fRKRtIgo3KLv0AGyxlyToy6tpNOu_esE9pCtDAXBkbU4vKpKrqoLbIPE-waURApl-hRE6xGPqcz-y6A2asBBNOhKpfttlMHbmH_sIk359WFIsNmzUzpRCCG64kP5m4rni_S1GbNxxUzTk0-cW26TCD8U5Q880C_dyJF-4ZMf1JS2QuSRLM_L7fh8s7MWwm2TAZajaDcBPm-0fSyFyg0B2w'
    );
    const response = new HttpResponse();
    const mockResponse = response.clone({
      headers: headers
    });
    fodFinOIDCTokenHandler.saveAvailableAuthenticationToken(mockResponse);
    expect(
      sessionStorage.getItem('userTokenExpirationTimestamp')
    ).toBeDefined();
    expect(fodFinOIDCTokenHandler.getPermissions()).toEqual({
      'tempstorage': {
        'RCRandomSelectieStart': {
          'Create': 'true'
        },
        'IrregularityDecisionTSD': {
          'Manage': 'true'
        },
        'RCManualSelect': {
          'Modify': 'true'
        },
        'DeclarationTSDStatusChange': {
          'Modify': 'true'
        },
        'AmendmentTSD': {
          'Create': 'true'
        },
        'RCConsult': {
          'Allow': 'true'
        },
        'DraftDeclarationTSD': {
          'Manage': 'true'
        },
        'DeclarationReport': {
          'Allow': 'true'
        },
        'InvalidateTSD': {
          'Create': 'true'
        },
        'DeclarationTSD': {
          'Consult': 'true'
        },
        'RCDeselect': {
          'Modify': 'true'
        },
        'RegisterMeasures': {
          'Modify': 'true'
        },
        'AllDeclarationTSD': {
          'Consult': 'true'
        }
      }
    });
    expect(fodFinOIDCTokenHandler.getUserInfo()).toEqual({
      'mail': 'testuser.tsd01@minfin.fed.be',
      'name': 'testuser',
      'preferredLanguage': 'nl',
      'shortName': 'tsd01',
      'ssoUid': 'ttsd01aa',
      'userType': 'internal',
      'allowedApps': ['tempstorage'],
      'permissions': {
        'tempstorage': {
          'RCRandomSelectieStart': {
            'Create': 'true'
          },
          'IrregularityDecisionTSD': {
            'Manage': 'true'
          },
          'RCManualSelect': {
            'Modify': 'true'
          },
          'DeclarationTSDStatusChange': {
            'Modify': 'true'
          },
          'AmendmentTSD': {
            'Create': 'true'
          },
          'RCConsult': {
            'Allow': 'true'
          },
          'DraftDeclarationTSD': {
            'Manage': 'true'
          },
          'DeclarationReport': {
            'Allow': 'true'
          },
          'InvalidateTSD': {
            'Create': 'true'
          },
          'DeclarationTSD': {
            'Consult': 'true'
          },
          'RCDeselect': {
            'Modify': 'true'
          },
          'RegisterMeasures': {
            'Modify': 'true'
          },
          'AllDeclarationTSD': {
            'Consult': 'true'
          }
        }
      }
    });
  });

  it('should test saveAvailableAuthenticationToken with minfin-iam_idtoken ', () => {
    const headers: HttpHeaders = new HttpHeaders().set(
      'minfin-iam-idtoken',
      'eyJ0eXAiOiJKV1QiLCJraWQiOiJSUklpdWtxcGgzUGlJUDBvN0ZQT3l5NzBxaDQ9IiwiYWxnIjoiUlMyNTYifQ.eyJhdF9oYXNoIjoiQmhmRmktTlR4QXVDRXFTd20yZXRMQSIsInN1YiI6InR0c2QwMWFhIiwiYXVkaXRUcmFja2luZ0lkIjoiYzdiNzFiODctYjA0NS00MzE5LWI0N2MtMmM0YzkyMzNmOTdkLTExNjA0NTMzNCIsInN1Ym5hbWUiOiJ0dHNkMDFhYSIsImlzcyI6Imh0dHBzOi8vYW0tYS5maW5iZWwuaW50cmEvc3NvL29hdXRoMiIsInRva2VuTmFtZSI6ImlkX3Rva2VuIiwibm9uY2UiOiI1ZWMxMjA1ZmU1MGM4NDdlMzgzYWZiNzQ2NmIwY2RkNCIsInNpZCI6Imcyelo1cGh1dGhFTUFxQXEyKzYvbTc3Y29UY0pHOVdtcUcxbE9WM0JsclU9IiwiYXVkIjoidGVtcHN0b3JhZ2UiLCJjX2hhc2giOiJuYjgwZUdwVU1IOFVTM1pMbEh3VG1nIiwiYWNyIjoiTERBUE1QIiwib3JnLmZvcmdlcm9jay5vcGVuaWRjb25uZWN0Lm9wcyI6InF4MHJDTDlsN2NrMm9OZkhSMllDMnJuUnZSTSIsInNfaGFzaCI6InA1c2laQ2ppeHVpYWpUNTYtNkI1MXciLCJhenAiOiJ0ZW1wc3RvcmFnZSIsImF1dGhfdGltZSI6MTY1NTgxNDQyNSwicmVhbG0iOiIvaW50ZXJuYWwiLCJleHAiOjE2NTU4Mzk0NDYsInRva2VuVHlwZSI6IkpXVFRva2VuIiwiaWF0IjoxNjU1ODM1ODQ2fQ.As1H0iOZPt_YsLjds0gkKrfo47lLUJB7cilHigGY9KWb395OQ4OuoFfX8P_I7CQbJgg4_Ws4glecW9JUi6mfTmt9zkIhchXmnM97FF13KoyeN63WUlBdTOr8lZAMcqg-HRSujFeDhA_0NuSPtKiP0aAtG5hBKLmAyOuh546vnKKNXf63vGKjfsR6B8CY-A4vN1qb4X5cRR8T_7LfFrboIf-iXgpIwrJFtfuRzBvazXgB4txK4ly2qktMYq02hNs6U78p7QUnKQgcU3GOLwwxv0QMUg_dTSoBgvCN7n0KkumQl_z5CzGwXXvTeDmkI8RYWcWnvySFPwgc-ypsY6hrzQ'
    );
    const response = new HttpResponse();
    const mockResponse = response.clone({
      headers: headers
    });
    fodFinOIDCTokenHandler.saveAvailableAuthenticationToken(mockResponse);
    expect(sessionStorage.getItem('iamTokenExpirationTimestamp')).toBeDefined();
  });
  it('should test saveAvailableAuthenticationToken with bearer token ', () => {
    const headers: HttpHeaders = new HttpHeaders().set(
      'authorization',
      'Bearer Cfxp2UqIrs2LOaTxvWq83wF7BPI'
    );
    const response = new HttpResponse();
    const mockResponse = response.clone({
      headers: headers
    });
    fodFinOIDCTokenHandler.saveAvailableAuthenticationToken(mockResponse);
    expect(sessionStorage.getItem('accessTokenExpirationTime')).toBeDefined();
    expect(sessionStorage.getItem('Authorization')).toEqual(
      'Bearer Cfxp2UqIrs2LOaTxvWq83wF7BPI'
    );
  });

  it('should test saveAvailableAuthenticationToken with no minfin-iam_usertoken', () => {
    sessionStorage.clear();
    const headers: HttpHeaders = new HttpHeaders().set(
      'minfin-iam_usertoken',
      ''
    );
    const response = new HttpResponse();
    const mockResponse = response.clone({
      headers: headers
    });
    fodFinOIDCTokenHandler.saveAvailableAuthenticationToken(mockResponse);
    expect(fodFinOIDCTokenHandler.getUserInfo()).toEqual(null);
  });

  it('should test setTimer with expirationDateTime', () => {
    const date = new Date();
    date.setSeconds(date.getSeconds() + 5);
    const spy = jest.spyOn(fodFinOIDCTokenHandler, 'refreshTokens');
    fodFinOIDCTokenHandler['expireBeforeSeconds'] = 0;
    fodFinOIDCTokenHandler.setTimer(date);
    setTimeout(() => {
      expect(spy).toHaveBeenCalled();
    }, 5000);
  });

  it("'refreshTokens' should load html'", fakeAsync(() => {
    const result = { apiBaseUrl: 'http://domain-name.com/api/v1' };
    const expected = cold('-a|', { a: result });
    http.get = jest.fn(() => expected);
    fodFinOIDCTokenHandler.refreshTokens();
    expect(http.get).toHaveBeenCalledWith('../../../assets/renew-tokens.html', {
      observe: 'response',
      responseType: 'text'
    });
  }));
});
