/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { HttpClient, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { TOKEN } from '@shared/constant/http-constant';
import { timer, takeWhile, Subscription } from 'rxjs';

import { User } from '../../models/user';

import { OIDCTokenHandler } from './oidc-token-handler';
@Injectable({
  providedIn: 'root'
})
export class FodFinOIDCTokenHandler implements OIDCTokenHandler {
  private isRefreshing = false;
  private jwtHelper;
  private timerSubscription: Subscription;
  private expireBeforeSeconds = 0;
  constructor(private http: HttpClient) {
    this.jwtHelper = new JwtHelperService();
  }

  saveAvailableAuthenticationToken(response: HttpResponse<any>) {
    this.timerSubscription?.unsubscribe();
    const IAM_TOKEN = response?.headers.get(TOKEN.IAM_TOKEN)
      ? response?.headers.get(TOKEN.IAM_TOKEN)
      : null;
    const USER_TOKEN = response?.headers.get(TOKEN.USER_TOKEN)
      ? response?.headers.get(TOKEN.USER_TOKEN)
      : null;
    const ACCESS_TOKEN = response?.headers.get(TOKEN.ACCESS_TOKEN)
      ? response?.headers.get(TOKEN.ACCESS_TOKEN)
      : null;
    if (IAM_TOKEN) {
      sessionStorage.setItem(
        'iamTokenExpirationTimestamp',
        this.jwtHelper.getTokenExpirationDate(IAM_TOKEN)
      );
      this.setTimer(new Date(this.jwtHelper.getTokenExpirationDate(IAM_TOKEN)));
      sessionStorage.setItem(TOKEN.IAM_TOKEN, IAM_TOKEN);
    }
    if (USER_TOKEN) {
      sessionStorage.setItem(
        'userTokenExpirationTimestamp',
        this.jwtHelper.getTokenExpirationDate(USER_TOKEN)
      );
      sessionStorage.setItem(TOKEN.USER_TOKEN, USER_TOKEN);
      this.setTimer(
        new Date(this.jwtHelper.getTokenExpirationDate(USER_TOKEN))
      );
    }
    if (ACCESS_TOKEN) {
      sessionStorage.setItem('Authorization', ACCESS_TOKEN);
    }
  }
  getAccessToken() {
    return sessionStorage.getItem('Authorization');
  }
  getUserInfo() {
    const user: User = {};
    const decodedToken = this.jwtHelper.decodeToken(
      sessionStorage.getItem(TOKEN.USER_TOKEN)
    );
    if (decodedToken?.givenName) user.name = decodedToken?.givenName;
    if (decodedToken?.mail) user.mail = decodedToken?.mail;
    if (decodedToken?.preferredLanguage)
      user.preferredLanguage = decodedToken?.preferredLanguage;
    if (decodedToken?.['sso-uid']) user.ssoUid = decodedToken?.['sso-uid'];
    if (decodedToken?.user_type) user.userType = decodedToken?.user_type;
    if (decodedToken?.sn) user.shortName = decodedToken?.sn;
    if (decodedToken?.allowedApps) user.allowedApps = decodedToken?.allowedApps;
    if (decodedToken?.permissions) user.permissions = decodedToken?.permissions;
    return Object.keys(user).length > 0 ? user : null;
  }
  getPermissions() {
    const decodedToken = this.jwtHelper.decodeToken(
      sessionStorage.getItem(TOKEN.USER_TOKEN)
    );
    return decodedToken?.permissions ? decodedToken?.permissions : null;
  }
  refreshTokens() {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.http
        .get('../../../assets/renew-tokens.html', {
          observe: 'response',
          responseType: 'text'
        })
        .subscribe((response) => {
          this.isRefreshing = false;
        });
    }
  }
  setTimer(expirationDate: Date) {
    const newExpirationDateTime = new Date(expirationDate);
    newExpirationDateTime.setSeconds(
      expirationDate.getSeconds() - this.expireBeforeSeconds
    );
    this.timerSubscription = timer(newExpirationDateTime)
      .pipe(takeWhile((n) => n < 1))
      .subscribe(() => {
        this.refreshTokens();
      });
  }
}
