/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MediaObserver } from '@angular/flex-layout';
import { FormsModule } from '@angular/forms';
import { MatIconTestingModule } from '@angular/material/icon/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { MiniSearchComponent } from '@features/mini-search/mini-search.component';
import { MiniSearchParamService } from '@features/mini-search/services/mini-search-param.service';
import { StoreModule } from '@ngrx/store';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { RightsService } from '@shared/services/rights.service';
import { SharedModule } from '@shared/shared.module';
import { cold } from 'jasmine-marbles';
import { NgrxFormsModule } from 'ngrx-forms';
import { Observable, of } from 'rxjs';
import { MaterialModule } from 'src/app/material';

import { AppRoutingModule } from '../../../../app-routing.module';
import { SidenavComponent } from '../sidenav/sidenav.component';

import { ScrollTopComponent } from './scroll-top.component';
describe('ScrollTopComponent', () => {
  let component: ScrollTopComponent;
  let fixture: ComponentFixture<ScrollTopComponent>;
  beforeAll(() => {
    Object.defineProperty(window, 'matchMedia', {
      writable: true,
      value: jest.fn().mockImplementation((query) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: jest.fn(), // Deprecated
        removeListener: jest.fn(), // Deprecated
        addEventListener: jest.fn(),
        removeEventListener: jest.fn(),
        dispatchEvent: jest.fn()
      }))
    });
  });
  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        imports: [
          NoopAnimationsModule,
          FormsModule,
          CommonModule,
          MatIconTestingModule,
          MaterialModule,
          AppRoutingModule,
          SharedModule,
          NgrxFormsModule,
          RouterTestingModule,
          HttpClientModule,
          StoreModule.forRoot(ROOT_REDUCERS, {
            runtimeChecks: {
              strictStateImmutability: true,
              strictActionImmutability: true
            }
          })
        ],
        declarations: [ScrollTopComponent],
        providers: []
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(ScrollTopComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should test window scroll', () => {
    const spy = jest.spyOn(component, 'onWindowScroll');
    const scrollEvent = document.createEvent('CustomEvent');
    scrollEvent.initCustomEvent('scroll', false, false, null);
    window.dispatchEvent(scrollEvent);
    expect(spy).toHaveBeenCalled();
  });
  it('should test window scrollToTop', () => {
    const scrollEvent = document.createEvent('CustomEvent');
    scrollEvent.initCustomEvent('scroll', false, false, {
      scrollX: 5,
      scrollY: 5
    });
    window.dispatchEvent(scrollEvent);
    component.scrollToTop();
    expect(window.scrollX).toEqual(0);
  });
});
