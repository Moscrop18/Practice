/* eslint-disable @typescript-eslint/no-unsafe-argument */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-unsafe-return */
import { NoopScrollStrategy } from '@angular/cdk/overlay';
import { HttpClient } from '@angular/common/http';
import {
  ChangeDetectorRef,
  Component,
  HostListener,
  OnDestroy,
  OnInit
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import * as fromAuth from '@core/components/auth/store/reducers/auth.reducer';
import {
  selectIsErrorPage,
  selectIsLoggedIn
} from '@core/components/auth/store/selectors/auth.selectors';
import { AngularMinfinMenu } from '@core/models/menu/angularnminfinmenu.model';
import { Message } from '@core/models/message';
import { MergedRoute } from '@core/root-store/root.reducer';
import { getMergedRoute } from '@core/root-store/router-state.selectors';
import { AdvancedSearchParamForm } from '@features/advanced-search/models/adv-search-param-form';
import { ClearSearchFormPage } from '@features/advanced-search/store/actions/adv-search-param.actions';
import { constants } from '@features/edit-declaration/edit-declaration.constants';
import { QuestionWizardFormValue } from '@features/edit-declaration/models';
import { ResetQuestionWizardAction } from '@features/edit-declaration/question-wizard/store/reducers/question-wizard.reducer';
import { ConsultTSD } from '@features/manage-declaration/manage-declaration.constants';
import { select, Store } from '@ngrx/store';
import { MessageDialogComponent } from '@shared/components/message-dialog/message-dialog.component';
import { navigateAction } from '@shared/feature-store/common-store/actions/common.actions';
import { isCurrentWizardPageDirty } from '@shared/feature-store/common-store/selectors/common.selectors';
import { RightsService } from '@shared/services/rights.service';
import { Observable, debounceTime, Subscription } from 'rxjs';
import { take } from 'rxjs/operators';

import menuList from '../../../../assets/menu/menu.json';

import { State } from './../../../features/mini-search/store/reducers/mini-search-param.reducer';
import { selectIsInProgress } from './../../../features/mini-search/store/selectors/mini-search-param.selectors';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent implements OnInit, OnDestroy {
  loaded = true;
  msgs: Message[] = [];
  isErrorPage: Observable<boolean>;
  isLoggedIn: Observable<boolean>;
  isShow: boolean;
  topPosToStartShowing = 100;
  showProgressBar: Observable<boolean>;
  items: AngularMinfinMenu[];
  routerSubscription: Subscription;
  constructor(
    public dialog: MatDialog,
    private store: Store<fromAuth.AuthState>,
    private searchStore: Store<State>,
    private ref: ChangeDetectorRef,
    private questionWizardStore: Store<QuestionWizardFormValue>,
    private searchParamStore: Store<AdvancedSearchParamForm>,
    private routerStore: Store<MergedRoute>,
    private commonStore: Store<any>,
    private httpService: HttpClient,
    private activatedRoute: ActivatedRoute,
    private securityHelper: RightsService
  ) {
    // TODO revisit this after integration with security
    // TODO should be plugable or independent from MinFin
    const menuitemss = menuList as AngularMinfinMenu[];
    if (menuitemss) {
      // adding check to skip unit test case failure
      this.items = menuitemss.filter((item) => this.isAllowed(item));
    }
  }

  ngOnInit(): void {
    this.isLoggedIn = this.store.pipe(
      select(selectIsLoggedIn),
      debounceTime(0)
    );
    this.showProgressBar = this.store.pipe(
      select(selectIsInProgress),
      debounceTime(0)
    );
    this.isErrorPage = this.store.pipe(
      select(selectIsErrorPage),
      debounceTime(0)
    );
    this.ref.detectChanges();
    this.checkIfRouteIsValid();
  }
  ngOnDestroy(): void {
    this.routerSubscription?.unsubscribe();
  }
  checkIfRouteIsValid(): void {
    this.routerSubscription = this.routerStore
      .select(getMergedRoute)
      .subscribe((data) => {
        let isInvalidUrl = false;
        const arr = data.url.split('/');
        const tsdIndex = arr.indexOf(constants.TSD);
        const tsdId = data.queryParams.tsdId;
        if (
          (!data.url.includes(constants.LOGIN) &&
            data.url.includes(constants.TSD) &&
            (arr[tsdIndex + 1] === undefined ||
              !arr[tsdIndex + 1] ||
              Object.keys(data.queryParams).length === 0 ||
              tsdId === undefined)) ||
          this.checkforValidTSDQueryParamBeforeCreation(tsdId, data) ||
          this.checkforValidTSDQueryParamAfterCreation(tsdId, data)
        ) {
          isInvalidUrl = true;
        }
        if (isInvalidUrl)
          this.routerStore.dispatch(
            navigateAction({ url: ConsultTSD.PAGE_NOT_FOUND })
          );
      });
  }
  checkforValidTSDQueryParamAfterCreation(
    tsdId: string,
    data: MergedRoute
  ): boolean {
    return (
      (tsdId !== '0' &&
        (data.url.includes(constants.MASTER_CON_GEN_INFO) ||
          data.url.includes(constants.HOUSE_CON_GEN_INFO) ||
          data.url.includes(constants.MASTER_CONSIGNMENT_PARTIES) ||
          data.url.includes(constants.HOUSE_CONSIGNMENT_PARTIES)) &&
        !data.queryParams.consNo) ||
      ((data.url.includes(constants.MASTER_CON_ITEM_INFO) ||
        data.url.includes(constants.HOUSE_CON_ITEM_INFO)) &&
        (!data.queryParams.consNo || !data.queryParams.itemNo)) ||
      ((data.url.includes(constants.MASTER_CON_GEN_INFO) ||
        data.url.includes(constants.HOUSE_CON_GEN_INFO) ||
        data.url.includes(constants.MASTER_CONSIGNMENT_PARTIES) ||
        data.url.includes(constants.HOUSE_CONSIGNMENT_PARTIES)) &&
        data.queryParams.itemNo)
    );
  }
  checkforValidTSDQueryParamBeforeCreation(
    tsdId: string,
    data: MergedRoute
  ): boolean {
    return (
      tsdId === '0' &&
      (!data.queryParams.tsdType ||
        (data.queryParams.tsdType &&
          data.queryParams.tsdType !== constants.PRELODGED &&
          data.queryParams.tsdType !== constants.COMBINED) ||
        !data.queryParams.ensReuse ||
        (data.queryParams.ensReuse &&
          data.queryParams.ensReuse !== constants.TRUE &&
          data.queryParams.ensReuse !== constants.FALSE) ||
        !data.queryParams.consignmentType ||
        (data.queryParams.consignmentType &&
          data.queryParams.consignmentType !== constants.MASTER &&
          data.queryParams.consignmentType !== constants.HOUSE &&
          data.queryParams.consignmentType !== constants.BOTH) ||
        (data.queryParams.consignmentType === constants.BOTH &&
          data.queryParams.ensReuse === constants.FALSE &&
          (!data.queryParams.consignmentItemAddedTo ||
            (data.queryParams.consignmentItemAddedTo &&
              data.queryParams.consignmentItemAddedTo !== constants.MASTER &&
              data.queryParams.consignmentItemAddedTo !== constants.HOUSE &&
              data.queryParams.consignmentItemAddedTo !== constants.BOTH))))
    );
  }

  @HostListener('window:scroll')
  checkScroll() {
    const scrollPosition =
      window.pageYOffset ||
      document.documentElement.scrollTop ||
      document.body.scrollTop ||
      0;

    if (scrollPosition >= this.topPosToStartShowing) {
      this.isShow = true;
    } else {
      this.isShow = false;
    }
  }

  // TODO: Cross browsing
  gotoTop() {
    window.scroll({
      top: 0,
      left: 0,
      behavior: 'smooth'
    });
  }

  menuClick(item: AngularMinfinMenu): void {
    this.store
      .select(
        isCurrentWizardPageDirty(
          this.activatedRoute.snapshot['_routerState'].url.split('/')[1]
        )
      )
      .pipe(take(1))
      .subscribe((dirty) => {
        if (dirty) {
          const dialogRef = this.dialog.open(MessageDialogComponent, {
            minWidth: '560px',
            minHeight: '182px',
            maxWidth: '560px',
            autoFocus: false,
            scrollStrategy: new NoopScrollStrategy(),
            data: {
              title: 'confirmNavigation.title',
              message: 'confirmNavigation.message',
              isErrorDialog: false,
              closeText: 'confirmNavigation.leavePage',
              newText: 'confirmNavigation.stayPage'
            }
          });
          dialogRef.componentInstance.closeCalled.subscribe(() =>
            this.navigateAndClearForm(item)
          );
        } else {
          this.navigateAndClearForm(item);
        }
      });
  }

  private navigateAndClearForm(item: AngularMinfinMenu) {
    this.commonStore.dispatch(navigateAction({ url: item['link'] }));
    if (item.label === 'menu.newDeclaration') {
      this.questionWizardStore.dispatch(ResetQuestionWizardAction());
    } else if (item.label === 'menu.advanceSearch') {
      this.searchParamStore.dispatch(ClearSearchFormPage());
    }
    this.items.forEach((i) => {
      if (i['link'] === item['link']) {
        i.routerLinkActiveOptions = true;
      } else {
        i.routerLinkActiveOptions = false;
      }
    });
  }

  public isAllowed(menu: AngularMinfinMenu): boolean {
    return (
      (!menu.action && !menu.resource) ||
      (this.securityHelper &&
        this.securityHelper.canAccess(menu.resource, menu.action))
    );
  }
}
