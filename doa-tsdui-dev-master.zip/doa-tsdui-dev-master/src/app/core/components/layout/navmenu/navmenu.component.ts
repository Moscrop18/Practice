/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable sonarjs/cognitive-complexity */
import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
  SimpleChanges
} from '@angular/core';
import { MediaObserver } from '@angular/flex-layout';
import { AngularMinfinMenu } from '@core/models/menu/angularnminfinmenu.model';

@Component({
  selector: 'app-navmenu',
  templateUrl: './navmenu.component.html',
  styleUrls: ['./navmenu.component.scss']
})
export class NavmenuComponent implements OnChanges {
  @Output() menuClick = new EventEmitter<AngularMinfinMenu>();
  searchFor = 'MRN';
  @Input() items: AngularMinfinMenu[];

  constructor(public media: MediaObserver, private ref: ChangeDetectorRef) {}
  ngOnChanges(changes: SimpleChanges): void {
    this.ref.detectChanges();
  }

  public Search(): void {
    // empty
  }

  menuClicked(item: AngularMinfinMenu): void {
    this.menuClick.emit(item);
  }
}
