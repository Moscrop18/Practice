/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-unused-vars */
import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MediaObserver } from '@angular/flex-layout';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MiniSearchComponent } from '@features/mini-search/mini-search.component';
import { MiniSearchParamService } from '@features/mini-search/services/mini-search-param.service';
import { Store } from '@ngrx/store';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { SharedModule } from '@shared/shared.module';
import { Observable, of } from 'rxjs';
import { MaterialModule } from 'src/app/material';

import { SidenavComponent } from '../sidenav/sidenav.component';

import { NavmenuComponent } from './navmenu.component';

describe('NavmenuComponent', () => {
  let component: NavmenuComponent;
  let fixture: ComponentFixture<NavmenuComponent>;
  let http: HttpClient;
  let translate: TranslateService;

  class RightServiceStub {
    canAccess = (resource: string, action: string) => true;
  }

  const translations: any = {
    'layout.search': 'search'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }
  class FakeMediaObserver extends MediaObserver {
    isActive(value: string | string[]): boolean {
      return true;
    }
  }
  const mock = () => {};
  Object.defineProperty(window, 'matchMedia', {
    writable: true,
    value: (query: any) => {
      return {
        matches: false,
        media: query,
        onchange: null,
        addListener: mock, // deprecated
        removeListener: mock, // deprecated
        addEventListener: mock,
        removeEventListener: mock,
        dispatchEvent: mock
      };
    }
  });
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NavmenuComponent, SidenavComponent, MiniSearchComponent],
      imports: [
        SharedModule,
        BrowserAnimationsModule,
        HttpClientTestingModule,
        MaterialModule,
        TranslateModule.forRoot({})
      ],
      providers: [
        MiniSearchParamService,
        {
          provide: Store,
          useValue: {
            dispatch: jest.fn(),
            pipe: jest.fn(),
            select: jest.fn()
          }
        }
      ]
    });
  });
  const callback: any = [
    {
      label: 'menu.home',
      link: '/',
      action: 'NoAction',
      resource: 'NoResource',
      routerLinkActiveOptions: true
    }
  ];

  beforeEach(() => {
    fixture = TestBed.createComponent(NavmenuComponent);
    component = fixture.componentInstance;
    TestBed.inject(HttpClient);
    TestBed.inject(TranslateService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
