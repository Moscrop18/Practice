import { Component, Input } from '@angular/core';
import { MenuItem } from '@core/models/menu/menuitem';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent {
  @Input() items: MenuItem[];

  constructor() {
    // empty
  }
}
