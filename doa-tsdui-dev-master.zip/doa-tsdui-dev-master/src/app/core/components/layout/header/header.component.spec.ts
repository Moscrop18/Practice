import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
  waitForAsync
} from '@angular/core/testing';
import { HeaderComponent } from './header.component';
import { RouterTestingModule } from '@angular/router/testing';
import {
  PreloadAllModules,
  Router,
  RouterModule,
  Routes
} from '@angular/router';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { LangChooserComponent } from '../lang-chooser/lang-chooser.component';
import { AccountComponent } from '../account/account.component';
import { MatIconModule } from '@angular/material/icon';
import { Component, DebugElement, NgModule } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { provideMockStore } from '@ngrx/store/testing';
import { Location } from '@angular/common';
import { CoreModule } from '@core/core.module';
import { Action } from '@core/enums/action.enum';
import { Resource } from '@core/enums/resource.enum';
import { MessageComponent } from '@shared/components/message/message.component';
import { HomeComponent } from '@core/components/home/home.component';
import { MaterialModule } from 'src/app/material';
import { SharedModule } from '@shared/shared.module';

@Component({
  selector: '<app-mock-header>',
  template: `<div class="header" (click)="GoToHome()"></div>`
})
class MockHeaderComponent {
  constructor(private router: Router) {}

  GoToHome() {
    this.router.navigate(['home']);
  }
}

@Component({
  template: `<div class="home"></div>`
})
class MockHomeComponent {}

@Component({
  template: ` <app-mock-header></app-mock-header>
    <router-outlet></router-outlet>`
})
class MockAppComponent {}

const mockAppRoutes: Routes = [
  { path: 'home', component: MockHomeComponent },
  { path: '**', redirectTo: 'home' }
];

@NgModule({
  declarations: [MockHeaderComponent, MockHomeComponent, MockAppComponent],
  imports: [
    RouterModule.forRoot(mockAppRoutes, {
      preloadingStrategy: PreloadAllModules,
      useHash: true
    }),
    CoreModule,
    SharedModule
  ],
  exports: [RouterModule]
})
export class MockAppModule {}

describe('HeaderComponent', () => {
  describe('Normal', () => {
    let component: HeaderComponent;
    let fixture: ComponentFixture<HeaderComponent>;
    let rootElement: DebugElement;

    let location: Location;
    let router: Router;

    let translate: TranslateService;
    let httpTestingController: HttpTestingController;

    const translations: any = {
      layout: {
        logo: 'assets/img/logo_customs_excise_en.png'
      },
      common: {
        otherInfo: {
          label: 'Other information and officials services',
          url: 'http://www.belgium.be/en'
        }
      }
    };

    class FakeLoader implements TranslateLoader {
      getTranslation(lang: string): Observable<any> {
        return of(translations);
      }
    }

    const initialState = {
      settings: { language: 'en' },
      auth: {
        user: {
          typeUser: 'iam',
          fullname: 'testuser angularcallcenter',
          email: 'testuser.angularcallcenter@minfin.fed.be',
          locale: 'fr',
          authorizations: [
            {
              action: Action.SAY,
              resource: Resource.HELLO
            }
          ]
        }
      }
    };

    beforeEach(
      waitForAsync(() => {
        TestBed.configureTestingModule({
          declarations: [
            HeaderComponent,
            HomeComponent,
            LangChooserComponent,
            AccountComponent
          ],
          imports: [
            MaterialModule,
            SharedModule,
            MockAppModule,
            MatIconModule,
            HttpClientTestingModule,
            RouterTestingModule.withRoutes(mockAppRoutes),
            TranslateModule.forRoot({
              loader: { provide: TranslateLoader, useClass: FakeLoader }
            })
          ],
          providers: [provideMockStore({ initialState })]
        });
      })
    );

    beforeEach(() => {
      fixture = TestBed.createComponent(HeaderComponent);
      component = fixture.componentInstance;
      router = TestBed.inject(Router);

      httpTestingController = TestBed.inject(HttpTestingController);
      fixture.detectChanges();

      router.initialNavigation();
    });

    it('should create', () => {
      expect(component).toBeTruthy();
    });
  });

  describe('Custom - click return', () => {
    let location: Location;
    let router: Router;
    let component: MockAppComponent;
    let fixture: ComponentFixture<MockAppComponent>;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [RouterTestingModule.withRoutes(mockAppRoutes)],
        declarations: [MockHomeComponent, MockAppComponent, MockHeaderComponent]
      });
    });

    beforeEach(() => {
      fixture = TestBed.createComponent(MockAppComponent);
      component = fixture.componentInstance;
      router = TestBed.inject(Router);
      location = TestBed.inject(Location);
      router.initialNavigation();
    });

    it('should return to home component if clicked on the header', fakeAsync(() => {
      router.navigate(['home']).then(() => {
        tick();
        expect(location.path()).toBe('/home');
      });

      tick();
      (document.querySelector('.header') as HTMLElement).click();

      tick();
      const home = document.querySelector('.home') as HTMLElement;
      expect(home).not.toBeNull();
    }));
  });
});
