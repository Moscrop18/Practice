/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthState } from '@core/components/auth/store/reducers';
import { selectIsLoggedIn } from '@core/components/auth/store/selectors/auth.selectors';
import { ConfigService } from '@core/services/config/config.service';
import { ConsultTSD } from '@features/manage-declaration/manage-declaration.constants';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  isLoggedIn: Observable<boolean>;
  env: string;
  constructor(
    private router: Router,
    private store: Store<AuthState>,
    private configService: ConfigService
  ) {
    this.env = String(this.configService.getConfig().env);
  }

  ngOnInit(): void {
    this.isLoggedIn = this.store.select(selectIsLoggedIn);
  }
  public get ConsultTSD() {
    return ConsultTSD;
  }
}
