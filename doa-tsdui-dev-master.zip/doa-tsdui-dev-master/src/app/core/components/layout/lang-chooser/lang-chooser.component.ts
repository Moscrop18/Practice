import { Component } from '@angular/core';
import { setLanguage } from '@core/components/settings/store/actions/settings.actions';
import { SettingsState } from '@core/components/settings/store/reducers/settings.reducer';
import { selectLanguage } from '@core/components/settings/store/selectors/settings.selectors';
import { ConfigService } from '@core/services/config/config.service';
import { UnsubscribeOnDestroyComponent } from '@core/utils/unsubscribe-on-destroy';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-lang-chooser',
  templateUrl: './lang-chooser.component.html',
  styleUrls: ['./lang-chooser.component.scss']
})
export class LangChooserComponent extends UnsubscribeOnDestroyComponent {
  language: string;
  suppLang: any;
  env: string;
  constructor(
    private translate: TranslateService,
    private store: Store<SettingsState>,
    private configService: ConfigService
  ) {
    super();
    this.subs.sink = this.store.select(selectLanguage).subscribe((language) => {
      this.language = language;
    });
    this.suppLang = this.translate.getLangs();
    this.env = String(this.configService.getConfig().env);
  }

  setLang(lang: string): void {
    this.store.dispatch(setLanguage({ language: lang }));
  }

  isCurrentLang(lang: string): boolean {
    return this.language === lang;
  }
}
