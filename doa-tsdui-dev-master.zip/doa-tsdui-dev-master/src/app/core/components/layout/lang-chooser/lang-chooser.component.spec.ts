/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { HttpClientModule } from '@angular/common/http';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { ConfigService } from '@core/services/config/config.service';
import { MaterialModule } from '@material/material.module';
import { StoreModule } from '@ngrx/store';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

import { LangChooserComponent } from './lang-chooser.component';

describe('lang-chooser.component', () => {
  let component: LangChooserComponent;
  let fixture: ComponentFixture<LangChooserComponent>;
  let rootElement: DebugElement;

  const TranslateServiceStub = {
    currentLang: 'nl',
    async use(language: string) {
      this.currentLang = language;
    },
    getLangs() {
      //Test
    }
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        StoreModule.forRoot(ROOT_REDUCERS),
        TranslateModule,
        MaterialModule,
        HttpClientModule
      ],
      declarations: [LangChooserComponent],
      providers: [
        ConfigService,
        { provide: TranslateService, useValue: TranslateServiceStub }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LangChooserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    rootElement = fixture.debugElement;
  });

  it('Should create', () => {
    expect(component).toBeTruthy();
  });
});
