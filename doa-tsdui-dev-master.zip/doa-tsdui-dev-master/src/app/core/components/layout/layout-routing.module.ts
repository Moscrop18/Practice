import { NgModule } from '@angular/core';
import { LoadChildren, RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '@core/guards/auth.guard';

import { LayoutComponent } from './layout.component';

const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    data: {
      breadcrumb: 'breadcrumb.home',
      isClickable: true,
      animationState: 'One'
    },
    children: [
      {
        path: '',
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('@core/components/home/home.module').then((m) => m.HomeModule)
      },
      {
        path: 'edit-declaration',
        data: {
          animationState: 'Two'
        },
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('@features/edit-declaration/edit-declaration.module').then(
            (m) => m.EditDeclarationModule
          )
      },
      {
        path: ':id/amendment',
        canActivate: [AuthGuard],
        // eslint-disable-next-line sonarjs/no-identical-functions
        loadChildren: () =>
          import('@features/edit-declaration/edit-declaration.module').then(
            (m) => m.EditDeclarationModule
          )
      },
      {
        path: 'advanced-search',
        data: {
          breadcrumb: 'breadcrumb.advancedSearch',
          path: '/advanced-search',
          isClickable: true,
          animationState: 'Four'
        },
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('@features/advanced-search/advanced-search.module').then(
            (m) => m.AdvancedSearchModule
          )
      },
      {
        path: 'saved-drafts',
        data: {
          breadcrumb: 'breadcrumb.saved-drafts',
          path: '/saved-drafts',
          isClickable: true,
          animationState: 'Three'
        },
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('@features/saved-drafts/saved-drafts.module').then(
            (m) => m.SavedDraftsModule
          )
      },
      {
        path: 'page-not-found',
        loadChildren: loadNotFoundModule()
      },
      {
        path: ':id',
        canActivate: [AuthGuard],
        loadChildren: () =>
          import('@features/manage-declaration/manage-declaration.module').then(
            (m) => m.ManageDeclarationModule
          )
      },
      // otherwise redirect to not found page
      {
        path: '**',
        loadChildren: loadNotFoundModule()
      }
    ]
  }
];
function loadNotFoundModule(): LoadChildren {
  return () =>
    import('@core/components/page-not-found/page-not-found.module').then(
      (m) => m.PageNotFoundModule
    );
}
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LayoutRoutingModule {}
