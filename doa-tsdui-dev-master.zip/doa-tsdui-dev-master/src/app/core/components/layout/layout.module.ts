import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ModuleLoadService } from '@core/services/config/module-load.service';
import { ConsultGenralInfoService } from '@features/manage-declaration/services/consult-genral-info.service';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { MiniSearchModule } from '@features/mini-search/mini-search.module';
import { MaterialModule } from '@material/index';
import { StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { commonReducer } from '@shared/feature-store/common-store/reducer/common.reducer';
import { SharedModule } from '@shared/shared.module';

import { AccountComponent } from './account/account.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { LangChooserComponent } from './lang-chooser/lang-chooser.component';
import { LayoutRoutingModule } from './layout-routing.module';
import { LayoutComponent } from './layout.component';
import { LogoutComponent } from './logout/logout.component';
import { NavmenuComponent } from './navmenu/navmenu.component';
import { ScrollTopComponent } from './scroll-top/scroll-top.component';
import { SidenavComponent } from './sidenav/sidenav.component';

@NgModule({
  declarations: [
    LayoutComponent,
    FooterComponent,
    HeaderComponent,
    LangChooserComponent,
    ScrollTopComponent,
    LogoutComponent,
    AccountComponent,
    NavmenuComponent,
    BreadcrumbComponent,
    SidenavComponent
  ],
  imports: [
    CommonModule,
    LayoutRoutingModule,
    SharedModule,
    TranslateModule,
    FlexLayoutModule,
    MaterialModule,
    MiniSearchModule,
    StoreModule.forFeature('commonStateKey', commonReducer)
  ],
  providers: [
    ModuleLoadService,
    ManageDeclarationFacade,
    ConsultGenralInfoService
  ]
})
export class LayoutModule {}
