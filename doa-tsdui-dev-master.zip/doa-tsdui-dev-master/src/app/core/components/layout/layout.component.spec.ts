/* eslint-disable @typescript-eslint/no-unsafe-return */
import { Overlay } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { RouterTestingModule } from '@angular/router/testing';
import { AngularMinfinMenu } from '@core/models/menu/angularnminfinmenu.model';
import { MergedRoute, ROOT_REDUCERS } from '@core/root-store/root.reducer';
import { invRequestParamReducer } from '@features/manage-declaration/invalidation-dialog/store/reducers/invalidation-request-param.reducer';
import { miniSearchParamReducer } from '@features/mini-search/store/reducers/mini-search-param.reducer';
import { Store, StoreModule } from '@ngrx/store';
import { TranslateModule } from '@ngx-translate/core';
import { of } from 'rxjs';

import { LayoutComponent } from './layout.component';
import { ScrollTopComponent } from './scroll-top/scroll-top.component';

describe('LayoutComponent', () => {
  let component: LayoutComponent;
  let fixture: ComponentFixture<LayoutComponent>;
  let routerStore: any;

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [LayoutComponent, ScrollTopComponent],
        providers: [Store, MatDialog, Overlay],
        imports: [
          HttpClientModule,
          MatDialogModule,
          RouterTestingModule,
          StoreModule.forRoot(ROOT_REDUCERS, {
            runtimeChecks: {
              strictStateImmutability: true,
              strictActionImmutability: true
            }
          }),
          StoreModule.forFeature('miniSearchParam', miniSearchParamReducer),
          StoreModule.forFeature(
            'invalidationRequestParam',
            invRequestParamReducer
          ),
          TranslateModule.forRoot()
        ],
        schemas: [NO_ERRORS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutComponent);
    component = fixture.componentInstance;
    routerStore = TestBed.inject(Store);
    const queryParams = {
      queryParams: {
        tsdId: '0',
        ensReuse: 'false',
        consignmentType: 'both',
        consignmentItemAddedTo: 'both'
      },
      url: 'http://localhost:4200/edit-declaration/tsd/general-info'
    };
    jest.spyOn(routerStore, 'select').mockImplementation(() => of(queryParams));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test checkScroll', () => {
    component.isShow = true;
    component.topPosToStartShowing = 100;
    component.checkScroll();
    expect(component.isShow).toEqual(false);

    component.topPosToStartShowing = -100;
    component.checkScroll();
    expect(component.isShow).toEqual(true);
  });
  it('test isAllowed function', () => {
    const angularMinfinMenu = new AngularMinfinMenu();
    expect(component.isAllowed(angularMinfinMenu)).toBeTruthy();
  });
});
