/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Location } from '@angular/common';
import { Component, NgModule } from '@angular/core';
import {
  ComponentFixture,
  fakeAsync,
  TestBed,
  tick,
  waitForAsync
} from '@angular/core/testing';
import {
  ActivatedRoute,
  PreloadAllModules,
  Router,
  RouterModule,
  Routes
} from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ConsultGenralInfoService } from '@features/manage-declaration/services/consult-genral-info.service';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { StoreModule } from '@ngrx/store';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { consultGeneralInfoReducer } from '@shared/feature-store/declaration/reducer/consult-general-info.reducer';
import { Observable, of } from 'rxjs';
import { genInfoMockData } from 'src/assets/mocks/gen-info-mock';
import { BreadcrumbComponent } from './breadcrumb.component';

@Component({
  selector: 'app-mock-adv-search',
  template: '<div>test</div>'
})
class MockAdvanceSearchComponent {}
@Component({
  selector: 'app-mock-header',
  template: '<div>test</div>'
})
class MockHeaderComponent {
  constructor(private router: Router) {}
}

@Component({
  template: '<div class="landing"></div>'
})
class MockLandingComponent {}

@Component({
  template: `<app-mock-header></app-mock-header>
    <router-outlet></router-outlet>`
})
class MockAppComponent {}

const mockAppRoutes: Routes = [
  { path: 'landing', component: MockLandingComponent },
  { path: 'search', component: MockAdvanceSearchComponent },
  { path: '**', redirectTo: 'landing' }
];

@NgModule({
  declarations: [
    MockHeaderComponent,
    MockLandingComponent,
    MockAppComponent,
    MockAdvanceSearchComponent
  ],
  imports: [
    RouterModule.forRoot(mockAppRoutes, {
      preloadingStrategy: PreloadAllModules,
      useHash: true
    })
  ],
  exports: [RouterModule],
  providers: [ManageDeclarationFacade, ConsultGenralInfoService]
})
export class MockAppModule {}

describe('BreadcrumbComponent', () => {
  let component: BreadcrumbComponent;
  let fixture: ComponentFixture<BreadcrumbComponent>;
  // let el: DebugElement;
  let translate: TranslateService;
  let router: Router;
  let facade: ManageDeclarationFacade;

  const translations: any = {
    'menu.home': 'HOME'
  };
  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of({ translations });
    }
  }

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [BreadcrumbComponent],
        imports: [
          MockAppModule,
          RouterTestingModule.withRoutes(mockAppRoutes),
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: MockLoader }
          }),
          StoreModule.forRoot(consultGeneralInfoReducer, {
            runtimeChecks: {
              strictStateImmutability: true,
              strictActionImmutability: true
            }
          }),

          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: MockLoader }
          })
        ]
      });
    })
  );

  beforeEach(() => {
    TestBed.inject(ActivatedRoute);
    facade = TestBed.inject(ManageDeclarationFacade);
    jest
      .spyOn(facade, 'fetchGeneralInformationData')
      .mockImplementation(() => of(genInfoMockData));
    translate = TestBed.inject(TranslateService);
    fixture = TestBed.createComponent(BreadcrumbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show breadcrum when on other page', fakeAsync(() => {
    const router = TestBed.inject(Router);
    const location = TestBed.inject(Location);
    router.initialNavigation();
    void router.navigate(['search']).then(() => {
      tick();
      expect(location.path()).toBe('/search');
    });
    fixture.detectChanges();
    component.ngOnInit();
    tick();
  }));

  it('should no show breadcrum when on home page', fakeAsync(() => {
    TestBed.inject(ActivatedRoute);
    const router = TestBed.inject(Router);
    const location = TestBed.inject(Location);
    router.initialNavigation();

    void router.navigate(['landing']).then(() => {
      tick();
      expect(location.path()).toBe('/landing');
    });
    fixture.detectChanges();
    component.ngOnInit();
  }));

  it('should check clickable', () => {
    const a = component.isClickable(true, false);
    expect(a).toEqual(true);
  });

  it('should check clickable false', () => {
    const a = component.isClickable(false, false);
    expect(a).toEqual(false);
  });

  it('should test result from manageDeclarationFacade', fakeAsync(() => {
    const router = TestBed.inject(Router);
    const location = TestBed.inject(Location);
    router.initialNavigation();
    void router.navigate(['search']).then(() => {
      tick();
      expect(location.path()).toBe('/search');
    });
    fixture.detectChanges();
    component.ngOnInit();
    tick();
    expect(component.tsd).toBeDefined();
    expect(component.tsd).toEqual(genInfoMockData);
  }));
});
