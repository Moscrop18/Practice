/* eslint-disable sonarjs/prefer-single-boolean-return */
/* eslint-disable @typescript-eslint/restrict-template-expressions */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable sonarjs/cognitive-complexity */

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { UnsubscribeOnDestroyComponent } from '@core/utils/unsubscribe-on-destroy';
import { ConsultGeneralInformation } from '@features/manage-declaration/models/consult-general-information';
import { ManageDeclarationFacade } from '@features/manage-declaration/services/manage-declaration.facade';
import { distinctUntilChanged, filter } from 'rxjs/operators';

import { IBreadCrumb } from './breadcrumb.interface';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent
  extends UnsubscribeOnDestroyComponent
  implements OnInit {
  public breadcrumbs: IBreadCrumb[];
  public tsd: ConsultGeneralInformation;
  isRouteFromDraft: boolean;
  constructor(
    public router: Router,
    private activatedRoute: ActivatedRoute,
    private manageDeclarationFacade: ManageDeclarationFacade
  ) {
    super();
    this.breadcrumbs = this.buildBreadCrumb(this.activatedRoute.root);
  }

  ngOnInit() {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        distinctUntilChanged()
      )
      .subscribe((result) => {
        this.isRouteFromDraft = this.router.getCurrentNavigation().extras?.state?.draftListRoute?.queryParams?.isRouteFromDraft;
        if (result) {
          this.breadcrumbs = this.buildBreadCrumb(this.activatedRoute.root);
        }
      });
    this.manageDeclarationFacade
      .fetchGeneralInformationData()
      .subscribe((result) => {
        if (result) {
          this.tsd = result;
          this.breadcrumbs = this.buildBreadCrumb(this.activatedRoute.root);
        }
      });
  }

  /**
   * Recursively build breadcrumb according to activated route.
   */
  buildBreadCrumb(
    route: ActivatedRoute,
    url = '',
    breadcrumbs: IBreadCrumb[] = []
  ): IBreadCrumb[] {
    // If no routeConfig is available we are on the root path
    let label =
      route.routeConfig && route.routeConfig.data
        ? route.routeConfig.data.breadcrumb
        : '';
    const isClickable =
      route.routeConfig &&
      route.routeConfig.data &&
      route.routeConfig.data.isClickable;
    let path =
      route.routeConfig && route.routeConfig.data
        ? route.routeConfig.data.path
        : '';

    // If the route is dynamic route such as ':id', remove it
    const lastRoutePart = path ? path.split('/').pop() : '';
    const isDynamicRoute = lastRoutePart.startsWith(':');
    if (isDynamicRoute && !!route.snapshot) {
      const paramName = lastRoutePart.split(':')[1];
      path = path.replace(lastRoutePart, route.snapshot.params[paramName]);
      label = route.snapshot.params[paramName];
    }
    if (path && path.includes(':id/')) {
      path = path.replace(':id', this.tsd?.mrn ? this.tsd?.mrn : this.tsd?.crn);
    }
    // In the routeConfig the complete path is not available,
    // so we rebuild it each time
    // const nextUrl = path ? `${url}/${path}` : url;
    const nextUrl = path ? `${path}` : url;

    const breadcrumb: IBreadCrumb = {
      label,
      url: nextUrl,
      isClickable
    };
    // Only adding route with non-empty label
    const newBreadcrumbs = breadcrumb.label
      ? [...breadcrumbs, breadcrumb]
      : [...breadcrumbs];
    if (
      newBreadcrumbs.length > 3 &&
      newBreadcrumbs[2]?.label === 'breadcrumb.searchResults' &&
      !this.tsd?.current
    ) {
      const id = this.tsd?.mrn ? this.tsd?.mrn : this.tsd?.crn;
      if (id !== undefined) {
        newBreadcrumbs[3].label = newBreadcrumbs[3]?.label.replace(
          newBreadcrumbs[3]?.label,
          id
        );
        newBreadcrumbs[3].url = newBreadcrumbs[3]?.url.replace(
          newBreadcrumbs[3]?.url,
          'advanced-search/search-results/' + id
        );
      }
    }
    if (route.firstChild) {
      // If we are not on our current path yet,
      // there will be more children to look after, to build our breadcrumb
      return this.buildBreadCrumb(route.firstChild, nextUrl, newBreadcrumbs);
    }
    if (
      route.snapshot['_routerState'].url.includes('amendment') &&
      this.tsd &&
      parseInt(this.tsd.version.toString()) > 1
    ) {
      newBreadcrumbs.pop();
      newBreadcrumbs.push({
        label: this.tsd.mrn,
        url: route.snapshot['_routerState'].url.includes('advanced-search')
          ? 'advanced-search/search-results/' + this.tsd.mrn
          : this.tsd.mrn,
        isClickable: true
      });
      newBreadcrumbs.push({
        label: 'amendment.label',
        url: '',
        isClickable: false
      });
    }
    if (this.isRouteFromDraft) {
      newBreadcrumbs.pop();
      newBreadcrumbs.push({
        label: 'breadcrumb.saved-drafts',
        url: '/saved-drafts',
        isClickable: true
      });
      newBreadcrumbs.push({
        label: 'breadcrumb.editDeclaration',
        url: '',
        isClickable: false
      });
    }
    return newBreadcrumbs;
  }

  public isClickable(isClickable: boolean, isLast: boolean): boolean {
    if (isClickable === true && isLast === false) {
      return true;
    } else {
      return false;
    }
  }
}
