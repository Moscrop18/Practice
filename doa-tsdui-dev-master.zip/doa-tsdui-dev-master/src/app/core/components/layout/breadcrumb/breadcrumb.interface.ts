export interface IBreadCrumb {
  label: string;
  url: string;
  isClickable: boolean;
}
