/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatIconModule } from '@angular/material/icon';
import { By } from '@angular/platform-browser';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { FooterComponent } from './footer.component';

describe('FootComponent', () => {
  let translate: TranslateService;

  let component: FooterComponent;
  let fixture: ComponentFixture<FooterComponent>;
  let rootElement: DebugElement;

  const translations: any = {
    'layout.footer.home': 'home',
    'layout.footer.serviceof': 'serviceof',
    'layout.footer.faq': 'faq',
    'layout.footer.contact': 'contact',
    'layout.links.disclaimer.label': 'disclaimer',
    'layout.links.privacy.label': 'privacy',
    'layout.links.accessibility.label': 'accessibility',
    'layout.copyright': 'copyright'
  };

  class MockLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [FooterComponent],
        imports: [
          MatIconModule,
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: MockLoader }
          })
        ],
        providers: [],
        schemas: [CUSTOM_ELEMENTS_SCHEMA]
      });
    })
  );

  beforeEach(() => {
    translate = TestBed.inject(TranslateService);

    fixture = TestBed.createComponent(FooterComponent);
    component = fixture.componentInstance;
    rootElement = fixture.debugElement;
  });

  it('Should create component', () => {
    expect(component).toBeTruthy();
  });

  it('Should create home link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.home'));

    translate.get('layout.footer.home').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create serviceof link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.serviceof'));

    translate.get('layout.footer.serviceof').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create faq link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.faq'));

    translate.get('layout.footer.faq').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create contact link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.contact'));

    translate.get('layout.footer.contact').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create disclaimer link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.disclaimer'));

    translate.get('layout.links.disclaimer.label').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create privacy link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.privacy'));

    translate.get('layout.links.privacy.label').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });

  it('Should create accessibility link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.accessibility'));

    translate
      .get('layout.links.accessibility.label')
      .subscribe((res: string) => {
        expect(res).toEqual(home.nativeElement.textContent);
      });
  });

  it('Should create copyright link', () => {
    translate.use('en');

    fixture.detectChanges();
    const home = rootElement.query(By.css('.copyright'));

    translate.get('layout.copyright').subscribe((res: string) => {
      expect(res).toEqual(home.nativeElement.textContent);
    });
  });
});
