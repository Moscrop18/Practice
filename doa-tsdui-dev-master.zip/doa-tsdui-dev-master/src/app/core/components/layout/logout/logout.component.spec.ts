/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { MatIconModule } from '@angular/material/icon';
import { Action } from '@core/enums/action.enum';
import { Resource } from '@core/enums/resource.enum';
import { provideMockStore } from '@ngrx/store/testing';
import {
  TranslateLoader,
  TranslateModule,
  TranslateService
} from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { LogoutComponent } from './logout.component';

describe('LogoutComponent', () => {
  let translate: TranslateService;
  let httpTestingController: HttpTestingController;

  let component: LogoutComponent;
  let fixture: ComponentFixture<LogoutComponent>;
  let rootElement: DebugElement;
  /* class LogoutServiceStub extends LogoutService {
    logout(): Observable<void> {
      return of();
    }
  } */

  const initialState = {
    auth: {
      loggedin: true,
      user: {
        typeUser: 'iam',
        fullname: 'testuser angularcallcenter',
        email: 'testuser.angularcallcenter@minfin.fed.be',
        locale: 'fr',
        authorizations: [
          {
            action: Action.SAY,
            resource: Resource.HELLO
          }
        ]
      }
    }
  };

  const translations: any = {
    'layout.logout.label': 'logout',
    'common.button.yes': 'YES',
    'common.button.no': 'NO',
    'layout.logout.modal': 'modal'
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translations);
    }
  }

  beforeEach(
    waitForAsync(() => {
      TestBed.configureTestingModule({
        declarations: [LogoutComponent],
        imports: [
          CommonModule,
          HttpClientTestingModule,
          MatIconModule,
          TranslateModule.forRoot({
            loader: { provide: TranslateLoader, useClass: FakeLoader }
          })
        ],
        providers: [provideMockStore({ initialState })]
      });
    })
  );

  beforeEach(() => {
    translate = TestBed.inject(TranslateService);
    httpTestingController = TestBed.inject(HttpTestingController);

    fixture = TestBed.createComponent(LogoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    rootElement = fixture.debugElement;
  });

  it('Should create component', () => {
    expect(component).toBeTruthy();
  });

  it('Should translate everything', () => {
    const btnfin01 = rootElement.nativeElement.querySelector('.btn-fin01');

    translate.get('layout.logout.label').subscribe((res: string) => {
      expect(res).toEqual(btnfin01.innerText);
    });
  });
});
