import { createFeatureSelector, createSelector } from '@ngrx/store';

import * as fromSettings from '../reducers/settings.reducer';

export const selectSettingsState = createFeatureSelector<fromSettings.SettingsState>(
  fromSettings.settingsFeatureKey
);

export const selectLanguage = createSelector(
  selectSettingsState,
  fromSettings.getLanguage
);
