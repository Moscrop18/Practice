import { createAction, props } from '@ngrx/store';

export const initLanguage = createAction('[Settings] Init Language');
export const setLanguage = createAction(
  '[Settings] Set Language',
  props<{ language: string }>()
);
