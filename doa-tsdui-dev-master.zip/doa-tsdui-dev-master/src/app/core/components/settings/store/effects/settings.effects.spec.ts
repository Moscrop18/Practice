/* eslint-disable @typescript-eslint/no-empty-function */
/* eslint-disable @typescript-eslint/require-await */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { HttpClient, HttpHandler } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { CoreModule } from '@angular/flex-layout';
import { provideMockActions } from '@ngrx/effects/testing';
import { Store } from '@ngrx/store';
import {
  DEFAULT_LANGUAGE,
  MissingTranslationHandler,
  TranslateCompiler,
  TranslateLoader,
  TranslateParser,
  TranslateService,
  TranslateStore,
  USE_DEFAULT_LANG,
  USE_EXTEND,
  USE_STORE
} from '@ngx-translate/core';
import { ReplaySubject } from 'rxjs';

import { SettingEffects } from './settings.effects';

describe('setingsEffect', () => {
  let actions: ReplaySubject<any>;
  let effects: SettingEffects;
  let store: Store<any>;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SettingEffects,
        TranslateStore,
        { provide: TranslateService, useValue: { getTranslation: jest.fn() } },
        TranslateCompiler,
        TranslateParser,
        MissingTranslationHandler,
        {
          provide: TranslateLoader,
          useValue: {
            getTranslation: jest.fn()
          }
        },
        {
          provide: Store,
          useValue: {
            dispatch: jest.fn(),
            pipe: jest.fn()
          }
        },
        { provide: USE_DEFAULT_LANG, useValue: {} },
        { provide: USE_STORE, useValue: {} },
        { provide: DEFAULT_LANGUAGE, useValue: {} },
        { provide: USE_EXTEND, useValue: {} },
        provideMockActions(() => actions),
        HttpClient,
        HttpHandler
      ],
      imports: [CoreModule]
    });
    store = TestBed.inject(Store);
    effects = TestBed.get(SettingEffects);
  });
  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  it('should be created', async () => {
    expect(effects).toBeTruthy();
  });
});
