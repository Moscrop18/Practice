/* eslint-disable @typescript-eslint/no-floating-promises */
/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Injectable } from '@angular/core';
import {
  Actions,
  createEffect,
  ofType,
  ROOT_EFFECTS_INIT
} from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';
import { of } from 'rxjs';
import { map, switchMap, tap, withLatestFrom } from 'rxjs/operators';

import * as SettingActions from '../actions/settings.actions';
import { SettingsState } from '../reducers';
import { selectLanguage } from '../selectors/settings.selectors';
@Injectable()
export class SettingEffects {
  constructor(
    private actions$: Actions,
    private translate: TranslateService,
    private store: Store<SettingsState>
  ) {}

  init$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ROOT_EFFECTS_INIT),
      switchMap((action) =>
        of(action).pipe(
          withLatestFrom(this.store.select(selectLanguage)),
          map(([, currentLanguage]) => {
            this.translate.addLangs(['nl', 'fr', 'en', 'de']); // todo get this list from the config
            const supportedLang = this.translate.getLangs();
            const requestedLang =
              currentLanguage || this.translate.getBrowserLang();
            const lang = supportedLang.includes(requestedLang)
              ? requestedLang
              : supportedLang[0];
            return SettingActions.setLanguage({ language: lang });
          })
        )
      )
    )
  );

  setLanguage$ = createEffect(
    () =>
      this.actions$.pipe(
        ofType(SettingActions.setLanguage),
        tap((data) => {
          this.translate.use(data.language);
        })
      ),
    { dispatch: false }
  );
}
