/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Action, createReducer, on } from '@ngrx/store';

import * as SettingActions from '../actions/settings.actions';

export const settingsFeatureKey = 'settings';

export interface SettingsState {
  language: string;
}

export const initialState: SettingsState = {
  language: null
};

const settingsReducer = createReducer(
  initialState,
  on(SettingActions.setLanguage, (state, action) => {
    return {
      ...state,
      language: action.language
    };
  })
);

/**
 * Angular ahead-of-time (AOT) compiler (the compiler used for producing production builds)
 * might not support function expressions. It's therefore necessary to wrap the createReducer
 * function in an exported function like so:
 */
export function reducers(state: SettingsState | undefined, action: Action) {
  return settingsReducer(state, action);
}

export const getLanguage = (state: SettingsState): string => state.language;
