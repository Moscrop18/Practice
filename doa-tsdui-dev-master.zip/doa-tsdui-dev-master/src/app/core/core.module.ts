/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { CommonModule } from '@angular/common';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import {
  ModuleWithProviders,
  NgModule,
  Optional,
  SkipSelf
} from '@angular/core';
import { OIDCTokenHandler } from '@core/components/auth/oidc-token-handler';

import { FodFinOIDCTokenHandler } from './components/auth/fodfin-oidc-token-handler';
import { StandardHeaderInterceptor } from './interceptors';
import { FakeBackendHttpInterceptor } from './interceptors/fake-backend-http-interceptor';
import { JsonDateInterceptor } from './interceptors/JSON-date.interceptor';
import { PipesModule } from './pipes/pipes.module';
export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: JsonDateInterceptor, multi: true },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: StandardHeaderInterceptor,
    multi: true
  },
  {
    provide: HTTP_INTERCEPTORS,
    useClass: FakeBackendHttpInterceptor,
    multi: true
  }
];

@NgModule({
  declarations: [],
  imports: [CommonModule, PipesModule],
  providers: [
    httpInterceptorProviders,
    { provide: OIDCTokenHandler, useClass: FodFinOIDCTokenHandler }
  ]
})
export class CoreModule {
  static forRoot(): ModuleWithProviders<CoreModule> {
    return {
      ngModule: CoreModule
    };
  }

  constructor(
    @Optional()
    @SkipSelf()
    parentModule?: CoreModule
  ) {
    if (parentModule) {
      throw new Error(
        'CoreModule is already loaded. Import it in the AppModule only'
      );
    }
  }
}
