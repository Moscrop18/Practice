/* eslint-disable @typescript-eslint/no-unsafe-return */
/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import { Component, Renderer2 } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { environment } from '@environments/environment.prod';
import { Store } from '@ngrx/store';
import { TranslateService } from '@ngx-translate/core';

declare const window: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(
    private translate: TranslateService,
    private store: Store,
    private titleService: Title,
    private meta: Meta,
    private renderer: Renderer2
  ) {
    this.renderer.appendChild(
      document.querySelector('html'),
      this.renderer.createComment(
        `version: "${environment.version}" hash: "${environment.hash}"`
      )
    );
    if (window.Cypress) {
      window.store = store;
    }
    translate.langs = ['nl', 'fr', 'en', 'de'];
  }

  ngOnInit() {
    this.translate.get('meta.description').subscribe((text) => {
      this.meta.addTag({
        name: 'description',
        content: text
      });
    });
    this.translate.get('meta.author').subscribe((text) => {
      this.meta.addTag({
        name: 'author',
        content: text
      });
    });
  }
}
