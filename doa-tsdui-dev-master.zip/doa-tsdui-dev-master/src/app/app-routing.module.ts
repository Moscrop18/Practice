import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Layout of the App is loaded lazily
const routes: Routes = [
  {
    path: '',
    loadChildren: () =>
      import('@core/components/layout/layout.module').then(
        (m) => m.LayoutModule
      )
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      scrollPositionRestoration: 'enabled' // Setting default bheaviour for auto scroll to the top of the page on route change
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
