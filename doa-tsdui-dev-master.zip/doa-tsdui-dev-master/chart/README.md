# TSDUI

This chart deploys the tsdui in a k8s cluster.

TODO:

- This is work in-progress so, subject to change.

## Chart Details

This chart will do the following:

- Deploy the tsdui
- Expose an ingress

## Pre-requisites

list all the pre-requisites here

## Installing the Chart

```shell
$ helm repo add harbor https://finvmharborp01.finbel.intra/chartrepo/masp
$ helm repo update
```

```shell
$ helm upgrade ${RELEASE_NAME} tsdui --version ${VERSION}
        --install --atomic --wait
        --kube-context $ENV_NAME
        --namespace $K8S_NAMESPACE
        --set image.repository="${IMAGE_REPO}/${REGISTRY_PROJECT}/${IMAGE_NAME}"
        --set image.tag="${VERSION}${IMAGE_SHA:+@}${IMAGE_SHA}"
        --set ingress.hosts[0].host="${ENV_HOST}"
        --username=$REGISTRY_USER
        --password=$REGISTRY_PASSWORD
$ helm repo update
```

## Secret Management

Two options are supported for configuring secrets, one is using kubernetes secrets the other is using HashiCorp Vault. Both options could be used together.

The most secure option and the FodFin Standard is to use HashiCorp vault.

### Kubernetes Secrets

All the configuration properties from the section below, prefixed with `config.` can be used in a kubernetes secret by using the prefix `secrets` instead.
The full set of settings starting with `secrets` will be converted in a single kubernetes secret which is then passed on as a secretRef to the container.

### Vault secrets

When specifying the variable `vault.enabled` as true, HashiCorp vault will be used to retrieve the secrets.
One or more Vault secrets can be specified. Those will be loaded using the vault sidecar agent mechanism as explained here.
https://learn.hashicorp.com/vault/getting-started-k8s/sidecar

It is assumed that the Kubernetes mutating admission webhook for the vault agent is configured correctly on the cluster to be used.

#### Configuration required in vault

You can store any configuration setting prefixed with `config` from the table below in vault. To do so you first need to create a key value store following the FodFin naming conventions `secret/apps/<pillar>/<project>/<environment>`.
Then you need to fill in the fields(key value pairs) for this secret. One secret can hold multiple key value pairs and it is recommended to group most passwords in a single secret.

The fields names should correspond to the configuration setting without the `config.` prefix from the table below and you should replace the `.` in variable names with an `_` underscore. So for instance `config.database.owner.user` will become `database_owner_user` in vault.

The vault secrets are loaded with an init containers and made available as environment variable to the container.
To do so each secret defined in `vault.secrets` like `vault.secrets.abc` will be written to an `abc.env` file and 'sourced' at the start of the container.
If multiple secrets have the same field the last one defined will win. The order in which the files are sourced is alphabetically.

If a config map or secret exists for the same variable, the vault configured values will take precedence.

Please make sure you used the `/data/` part of the path as for kv-v2 the path is secret/data/apps... not secret/apps like you might expect.

Finally add a kubernetes authentication role where you link the service account that will be used to run this application see `serviceAccount.name` and the namespace to the correct vault policy.

```shell
$ vault write auth/kubernetes/role/doa-tsdui-review \
        bound_service_account_names=sa-gitlab-doa-tsdui \
        bound_service_account_namespaces=doa-tsdui-dev \
        policies=doa-tsdui-dev \
        ttl=24h
```

## Configuration

The following table lists the configurable parameters of the TSD micro-service chart and their default values.

TODO: update this table

| Parameter               | Description                                                | Default                                       |
| ----------------------- | ---------------------------------------------------------- | --------------------------------------------- |
| `imagePullSecrets`      | Docker registry pull secret                                |                                               |
| `serviceAccount.name`   | The name of the ServiceAccount for running the application | `sa-gitlab-doa-tsdui`                         |
| `serviceAccount.create` | Specifies whether a ServiceAccount should be created       | `true`                                        |
| `nameOverride`          | The name of the chart                                      | Generated using the name template             |
| `fullname`              | The fully qualified app name                               | Generated using the fullname template         |
| `podSecurityContext`    | Specify pod security context                               |                                               |
| `securityContext`       | Specify container security context                         |                                               |
| `image.pullPolicy`      | Container pull policy                                      | `IfNotPresent`                                |
| `image.repository`      | Container image                                            | `finvmharborp01.finbel.intra/doa-tsdui/tsdui` |
| `image.tag`             | Container image tag                                        |                                               |
| `service.type`          | The service type to create                                 | `ClusterIP`                                   |
| `service.port`          | The port on which to expose the service                    | `80`                                          |

The following chart settings with prefix `config` are, when specified, used to create a config map.
These settings will be passed as environment variables to the `TSDUI` container. For this to work the config prefix will be stripped, and the `.` will be replaced by an `_` (underscore).

When using `secret` instead of config the variable will be stored in a kubernetes secret instead.

| Parameter                 | Description              | Default |
| ------------------------- | ------------------------ | ------- |
| `config.tsdui.apiBaseUrl` | Beck-end URL for TSD API |         |
